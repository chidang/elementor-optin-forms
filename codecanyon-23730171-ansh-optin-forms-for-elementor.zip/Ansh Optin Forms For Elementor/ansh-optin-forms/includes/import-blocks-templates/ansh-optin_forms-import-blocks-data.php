<?php
/**
 * Class for importing a Block template.
 *
 * @package 
 */

namespace Elementor\TemplateLibrary;
use Elementor\TemplateLibrary\Source_Remote;
use Elementor\TemplateLibrary\Classes\Images;
use Elementor\Api;
use Elementor\Plugin;

/**
 * Class for importing a Block template. 
 *
 */
 
class Ansh_Elements_Importer extends Source_Remote {
	
	public function __construct() {
		add_action( 'elementor/ajax/register_actions', array($this, 'ansh_optin_form_register_action' ) );
    }
	
	public function ansh_optin_forms_blocks_data(){
		
		$optin_forms_blocks_data['ansh-optin-form-01'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-01.json';
		$optin_forms_blocks_data['ansh-optin-form-02'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-02.json';
		$optin_forms_blocks_data['ansh-optin-form-03'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-03.json';
		$optin_forms_blocks_data['ansh-optin-form-04'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-04.json';
		$optin_forms_blocks_data['ansh-optin-form-05'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-05.json';
		$optin_forms_blocks_data['ansh-optin-form-06'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-06.json';
		$optin_forms_blocks_data['ansh-optin-form-07'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-07.json';
		$optin_forms_blocks_data['ansh-optin-form-08'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-08.json';
		$optin_forms_blocks_data['ansh-optin-form-09'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-09.json';
		$optin_forms_blocks_data['ansh-optin-form-10'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-10.json';
		$optin_forms_blocks_data['ansh-optin-form-11'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-11.json';
		$optin_forms_blocks_data['ansh-optin-form-12'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-12.json';
		$optin_forms_blocks_data['ansh-optin-form-13'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-13.json';
		$optin_forms_blocks_data['ansh-optin-form-14'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-14.json';
		$optin_forms_blocks_data['ansh-optin-form-15'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-15.json';
		$optin_forms_blocks_data['ansh-optin-form-16'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-16.json';
		$optin_forms_blocks_data['ansh-optin-form-17'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-17.json';
		$optin_forms_blocks_data['ansh-optin-form-18'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-18.json';
		$optin_forms_blocks_data['ansh-optin-form-19'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-19.json';
		$optin_forms_blocks_data['ansh-optin-form-20'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-20.json';
		$optin_forms_blocks_data['ansh-optin-form-21'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-21.json';
		$optin_forms_blocks_data['ansh-optin-form-22'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-22.json';
		$optin_forms_blocks_data['ansh-optin-form-23'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-23.json';
		$optin_forms_blocks_data['ansh-optin-form-24'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-24.json';
		$optin_forms_blocks_data['ansh-optin-form-25'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-25.json';
		$optin_forms_blocks_data['ansh-optin-form-26'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-26.json';
		$optin_forms_blocks_data['ansh-optin-form-27'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-27.json';
		$optin_forms_blocks_data['ansh-optin-form-28'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-28.json';
		$optin_forms_blocks_data['ansh-optin-form-29'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-29.json';
		$optin_forms_blocks_data['ansh-optin-form-30'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-30.json';
		$optin_forms_blocks_data['ansh-optin-form-31'] = ANSH_OPTIN_FORMS_URL . 'includes/import-blocks-templates/json-templates/ansh-optin-form-31.json';
		
		return apply_filters( 'ansh_optin_forms_blocks_data', $optin_forms_blocks_data );
	}
	
	/**
     * Import template ajax action
     */
    public function ansh_optin_form_register_action() {
		$this_requests = json_decode( stripslashes( $_REQUEST['actions'] ), true );	
		foreach ( $this_requests as $key=>$value) {
			if ( isset($value['action']) && $value['action'] == 'get_template_data' ) {
				$current_action_id = $key;
			
				$url = sprintf( 'https://my.elementor.com/api/v1/templates/%d', $key );		
				$response = wp_remote_get( $url );
				
				if ( is_wp_error( $response ) ) {
					return $response;
				}

				$template_content = json_decode( wp_remote_retrieve_body( $response ), true );
				
				if ( isset($template_content['code']) && $template_content['code'] == 'template_not_found' ) {
					
					$block_data = $this->ansh_optin_forms_blocks_data();
					
					
					$response = wp_remote_request( $block_data[$key] );
					if (is_wp_error($response)) {
						return $response;
					}
					$data = json_decode(wp_remote_retrieve_body($response), true);
					
					$data['content'] = $this->replace_elements_ids( $data['content'] );
					$data['content'] = $this->process_export_import_content( $data['content'], 'on_import' );					

					$post_id = $_REQUEST['editor_post_id'];
					$document = Plugin::$instance->documents->get( $post_id );
					if ( $document ) {
						$data['content'] = $document->get_elements_raw_data( $data['content'], true );
					}
					
					$response_data[ $current_action_id ] = [
						'success' => true,
						'code' => 200,
						'data' => $data,
					];

					
					
					$current_action_id = null;

					$response = [
						'success' => true,
						'data' => [
							'responses' => $response_data,
						],
					];

					echo wp_json_encode( $response );
					wp_die( '', '', [ 'response' => null ] );
			
					
				}	

			}			
	
		}
	}
}

new Ansh_Elements_Importer();