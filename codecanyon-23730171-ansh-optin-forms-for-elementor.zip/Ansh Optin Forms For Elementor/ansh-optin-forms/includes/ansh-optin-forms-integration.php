<?php

add_action( 'admin_menu', 'ansh_optin_forms_admin_menu', 205 );

function ansh_optin_forms_admin_menu() {
	add_menu_page(
			'Settings Admin',
			esc_html__( 'Ansh Optin Forms', 'ansh-optin-forms' ),
			'manage_options',
			'ansh_optin_forms_integration',
			'ansh_optin_forms_integration',
			'dashicons-eicon-mail',
			'59'
		);
	add_submenu_page(
			'ansh_optin_forms_integration',
			'',
			esc_html__( 'Integrations', 'ansh-optin-forms' ),
			'manage_options',
			'ansh_optin_forms_integration',
			'ansh_optin_forms_integration'			
		);
		
	$subscriber = add_submenu_page(
			'ansh_optin_forms_integration',
			'',
			esc_html__( 'Subscriber Lists', 'ansh-optin-forms' ),			
			'manage_options',
			'ansh_optin_subscriber_lists',
			'ansh_optin_subscriber_lists'
		);
		
	add_action( "load-$subscriber", 'ansh_optin_subscriber_screen_option'  );
	
}

function ansh_optin_forms_integration() {
	?>
	<div class="wrap ansh-optin-forms-wrap">
		<?php if ( isset($_GET['section']) && $_GET['section'] != '' ) :
				require_once ANSH_OPTIN_FORMS_PATH . 'includes/email_providers/' . $_GET['section'] . '.php';
				$email_provider = ansh_optin_form_provider_lists();
				echo '<h2>' . $email_provider[$_GET['section']]  . '</h2>';

				call_user_func('ansh_optin_forms_' . $_GET['section'] . '_setting');

			else:

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			?>
				<h2><?php esc_html_e( 'Optin Forms Integrations', 'ansh-optin-forms' );?></h2>
				<p><?php esc_html_e( 'here you can integrate to available Optin Forms for your favorite email marketing provider.', 'ansh-optin-forms' );?></p>


				<table class="ansh_optin_form_tbl widefat" cellspacing="0">
					<thead>
						<tr>
							<td><?php esc_html_e( 'Email Provider', 'ansh-optin-forms' );?></td>
							<td><?php esc_html_e( 'Enable', 'ansh-optin-forms' );?></td>
							<td><?php esc_html_e( 'Action', 'ansh-optin-forms' );?></td>
						</tr>
					</thead>

					<tbody>
						<?php foreach( ansh_optin_form_provider_lists() as $key=>$value ): ?>
							<tr>
								<td>
									<a href="<?php echo  esc_url( admin_url( 'admin.php?page=ansh_optin_forms_integration&section=' . strtolower( $key ) ) );?>"  class="ansh-email-provider-title" >
										<?php echo esc_html( $value);?>
									</a>
								</td>
								<td>
								<label for="ansh-optin-<?php echo  strtolower( $key )?>-enabled" class="ansh-optin-switch">
									<input type="checkbox" class="ansh-optin-form-enabled-lists" id="ansh-optin-<?php echo  strtolower( $key )?>-enabled" name="_ansh_optin_form_<?php echo  strtolower( $key )?>" value="1" <?php checked( @$optin_enabled_forms[$key], '1' );?> data-email-provider="<?php echo esc_attr($key);?>"/>
									<span class="slider round"></span>
								</label>
								</td>
								<td>
									<?php
									if ( isset($optin_enabled_forms[$key]) && $optin_enabled_forms[$key] != '' ) {
										echo '<a class="button alignright" href="' . esc_url( admin_url( 'admin.php?page=ansh_optin_forms_integration&section=' . strtolower( $key ) ) ) . '">' . esc_html__( 'Manage', 'ansh-optin-forms' ) . '</a>';
									} else {
										echo '<a class="button alignright" href="' . esc_url( admin_url( 'admin.php?page=ansh_optin_forms_integration&section=' . strtolower( $key ) ) ) . '">' . esc_html__( 'Set up', 'ansh-optin-forms' ) . '</a>';
									}

									?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
		<?php endif;?>
	</div>
	<?php
}

/*
 * Return Available email providers.
 *
 * @since 1.0.0
 */
function ansh_optin_form_provider_lists(){

	$email_marketing_lists = array(
								'acellemail'		=> 'Acelle Email',
								'activecampaign' 	=> 'Active Campaign',
								'acymailing' 		=> 'AcyMailing',
								'aweber' 			=> 'AWeber',
								'campaignmonitor' 	=> 'CampaignMonitor',
								'constantcontact'	=> 'Constant Contact',
								'convertkit'		=> 'ConvertKit',
								'emailoctopus'		=> 'EmailOctopus',
								'getresponse'		=> 'GetResponse',
								'hubspot'			=> 'HubSpot',
								'icontact'			=> 'iContact',
								'klaviyo'			=> 'Klaviyo',
								'mailchimp'			=> 'MailChimp',
								'mailerlite'		=> 'MailerLite',
								'mailpoet'			=> 'MailPoet',
								'mailster'			=> 'Mailster',
								'mailwizz'			=> 'Mailwizz',
								'sendgrid'			=> 'SendGrid',
								'sendinblue'		=> 'SendinBlue',
								'sendpulse'			=> 'SendPulse',
							);

	return $email_marketing_lists;
}

/*
 * Return active email providers  array only.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_active_email_provider() {
	$email_provider_lists = ansh_optin_form_provider_lists();
	$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );

	$active_email_provider = array( 'local_db' => esc_html__('Store Local Database', 'ansh-optin-forms') );


	foreach( $email_provider_lists as $key=>$value) {
		if ( isset($optin_enabled_forms[$key]) && $optin_enabled_forms[$key] == 1 ) {
			$active_email_provider[$key] = $value;
		}
	}
	return $active_email_provider;
}

/*
 * Return active email provider lists array.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_email_provider_lists( $provider = 'mailchimp' ) {

	$get_email_provider_lists = get_option( '_ansh_' . $provider . '_settings' );


	foreach ($get_email_provider_lists[ $provider . '_lists'] as $key=>$list ){
		$email_provider_lists[$list['id']] = $list['name'];
	}
	return $email_provider_lists;
}

/**
 * Enqueue scripts and styles.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_scripts() {

	wp_enqueue_style( 'ansh-optin-forms-css', ANSH_OPTIN_FORMS_URL . 'css/ansh-optin-forms.css');

	wp_enqueue_script( 'ansh-optin-forms-js', ANSH_OPTIN_FORMS_URL . 'js/ansh-optin-forms.js', array('jquery'), '', true );

	$locale_settings = [
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'elementor-pro-frontend' ),
		];


	$locale_settings = apply_filters( 'ansh_optin_forms_localize_settings', $locale_settings );

	wp_localize_script(
		'ansh-optin-forms-js',
		'AnshOptinFormsConfig',
		$locale_settings
	);
}

add_action( 'wp_enqueue_scripts', 'ansh_optin_forms_scripts', 20 );
add_action( 'admin_enqueue_scripts', 'ansh_optin_forms_scripts', 20 );


add_action('wp_ajax_ansh_optin_form_singup','ansh_optin_form_singup_action');
add_action('wp_ajax_nopriv_ansh_optin_form_singup','ansh_optin_form_singup_action');
function ansh_optin_form_singup_action() {

	

	if ( ! isset( $_POST['ansh_ontin_form'] ) || ! wp_verify_nonce( $_POST['ansh_ontin_form'], 'ansh_ontin_form' ) ) {

		$response = array(
			'error'     => esc_html__( 'Sorry, your nonce did not verify. Please try again latter.', 'ansh-optin-forms' ),
					);
	} else {
		
		
		$ansh_email_error_message =  json_decode(str_replace('\"','"',$_POST['ansh_email_error_message']), true);
		
		if ( isset($_POST['ansh_optin_form_first_name']) && $_POST['ansh_optin_form_first_name'] == '' ) {
			if ( isset($ansh_email_error_message['optin_form_first_name_error_message']) && $ansh_email_error_message['optin_form_first_name_error_message'] != '' ) {
				$response = array( 'error'	=> $ansh_email_error_message['optin_form_first_name_error_message'] );
			} else {
				$response = array( 'error'	=> esc_html__( 'Please, Enter your first Name.', 'ansh-optin-forms') );
			}

		} elseif ( isset($_POST['ansh_optin_form_last_name']) && $_POST['ansh_optin_form_last_name'] == '' ) {
			if ( isset($ansh_email_error_message['optin_form_first_error_message']) && $ansh_email_error_message['optin_form_first_error_message'] != '' ) {
				$response = array( 'error'	=> $ansh_email_error_message['optin_form_first_error_message'] );
			} else {
				$response = array( 'error'	=> esc_html__( 'Please, Enter your last name.', 'ansh-optin-forms') );
			}

		} elseif ( isset($_POST['ansh_optin_form_email']) && $_POST['ansh_optin_form_email'] == '' ) {
			if ( isset($ansh_email_error_message['optin_form_email_error_message']) && $ansh_email_error_message['optin_form_email_error_message'] != '' ) {
				$response = array( 'error'	=> $ansh_email_error_message['optin_form_email_error_message'] );
			} else {
				$response = array( 'error'	=> esc_html__( 'Please, Enter your email address.', 'ansh-optin-forms') );
			}

		} elseif (isset($_POST['ansh_email_provider']) && $_POST['ansh_email_provider'] == '') {
			if ( isset($ansh_email_error_message['optin_form_email_provider_message']) && $ansh_email_error_message['optin_form_email_provider_message'] != '' ) {
				$response = array( 'error'	=> $ansh_email_error_message['optin_form_email_provider_message'] );
			} else {
				$response = array( 'error'	=> esc_html__( 'Please, Select email service provider.', 'ansh-optin-forms') );
			}
			
		} elseif (isset($_POST['ansh_email_provider_list_id']) && $_POST['ansh_email_provider_list_id'] == '' && $_POST['ansh_email_provider'] != 'local_db' ) {
			
			if ( isset($ansh_email_error_message['optin_form_email_provider_list_message']) && $ansh_email_error_message['optin_form_email_provider_list_message'] != '' ) {
				$response = array( 'error'	=> $ansh_email_error_message['optin_form_email_provider_list_message'] );
			} else {
				$response = array( 'error'	=> esc_html__( 'Please, Select email list id.', 'ansh-optin-forms') );
			}
			
		}else {

			$signup_data = array(
								'email' 		=> $_POST['ansh_optin_form_email'],
								'first_name' 	=> $_POST['ansh_optin_form_first_name'],
								'last_name' 	=> $_POST['ansh_optin_form_last_name'],
								'list_id' 		=> $_POST['ansh_email_provider_list_id'],
								'email_provider'=> $_POST['ansh_email_provider'],
								);

			require_once ANSH_OPTIN_FORMS_PATH . 'includes/email_providers/' . $_POST['ansh_email_provider'] . '.php';
			$response = call_user_func_array( 'ansh_optin_forms_' . $_POST['ansh_email_provider'] . '_subscribe', array($signup_data) );
			
			if (isset($response['message'])){
				if ( isset($ansh_email_error_message['optin_form_success_message']) && $ansh_email_error_message['optin_form_success_message'] != '' ) {
					$response['message'] = $ansh_email_error_message['optin_form_success_message'];
				}
				
				if ( isset($ansh_email_error_message['optin_form_link']) && $ansh_email_error_message['optin_form_link']['url'] !='' ) {
					$response['redirect_link'] = $ansh_email_error_message['optin_form_link']['url'];
				}
			}
		}
	}

	wp_send_json( $response );
	wp_die();
}

add_action('wp_ajax_ansh_optin_forms_enabled_lists','ansh_optin_forms_enabled_lists');
function ansh_optin_forms_enabled_lists() {

	if ( isset($_POST['email_provider']) && $_POST['email_provider'] != '' ) {
		$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
		$optin_enabled_forms[$_POST['email_provider']] = (isset($_POST['email_provider_value'])) ? $_POST['email_provider_value'] : '';
		update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

		$email_provider_settings = get_option( '_ansh_'. $_POST['email_provider'] .'_settings' );
		$email_provider_settings[ $_POST['email_provider'].'_enabled'] = (isset($_POST['email_provider_value'])) ? $_POST['email_provider_value'] : '';

		update_option( '_ansh_'. $_POST['email_provider'] .'_settings', $email_provider_settings);
	}
	wp_die();
}

/*
 * Subscriber page screen option
 *
 * @since 1.4
 */
function ansh_optin_subscriber_screen_option(){
	$option = 'per_page';
	$args   = [
		'label'   => esc_html__( 'Number of subscribers per page', 'ansh-optin-forms' ),
		'default' => 20,
		'option'  => 'subscriber_per_page'
	];

	add_screen_option( $option, $args );
}
/*
 * Display Subscriber Lists from local database
 *
 * @since 1.4
 */
function ansh_optin_subscriber_lists() {
	global $wpbd;
	
	?>
	<div class="wrap ansh-optin-forms-wrap">
		<h2>
			<?php esc_html_e( 'Subscribers ', 'ansh-optin-forms' );?>
			<a id="ansh_optin_export_button" class="page-title-action" href="<?php echo plugins_url('ansh-optin-subscriber-lists.php?download_file=ansh-optin-subscriber-lists.csv',__FILE__); ?>"><?php esc_html_e('Export', 'ansh-optin-forms' );?></a>
		</h2>		
		<div id="poststuff">
			<div id="post-body" class="metabox-holder">
				<div id="post-body-content">
					<div class="meta-box-sortables ui-sortable">
						<form method="post" action="" id="posts-filter">
							<?php
							require_once ANSH_OPTIN_FORMS_PATH . 'includes/ansh-optin-subscriber-lists.php';
							$subscriber_list = new Ansh_Optin_Subscriber_List();
							$subscriber_list->prepare_items();
							$subscriber_list->search_box( 'search', 'search_id' );
							$subscriber_list->display(); ?>
						</form>
					</div>
				</div>
			</div>
			<br class="clear">
		</div>
		
	</div>
	<?php 
}