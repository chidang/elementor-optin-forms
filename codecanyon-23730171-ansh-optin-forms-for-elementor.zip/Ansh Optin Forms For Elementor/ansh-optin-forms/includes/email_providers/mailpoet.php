<?php

function ansh_optin_forms_mailpoet_setting() {

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'mailpoet-forms-settings' ) ) {

		$mailpoet_lists = array();
		if (  class_exists( '\MailPoet\API\API' ) ) {
			$mailpoet_lists = \MailPoet\API\API::MP( 'v1' )->getLists();
			foreach($mailpoet_lists as $list){
				if ( $list['id'] != '' && $list['name'] != '' ) {
					$mailpoet_lists[] = array( 'id'=> $list['id'], 'name' => $list['name'] );
				}
			}
		}

		$mailpoet_settings = array(
									'mailpoet_enabled'	=> (isset($_POST['_ansh_optin_form_mailpoet'])) ? $_POST['_ansh_optin_form_mailpoet'] : '',
									'mailpoet_lists'	=> $mailpoet_lists,
								);

		update_option( '_ansh_mailpoet_settings', $mailpoet_settings);

		$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
		$optin_enabled_forms['mailpoet'] = (isset($_POST['_ansh_optin_form_mailpoet'])) ? $_POST['_ansh_optin_form_mailpoet'] : '';
		update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

		$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
		echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
	}


	$plugin = 'mailpoet/mailpoet.php';
	$installed_plugins = get_plugins();
	if ( isset($installed_plugins[$plugin]) && !is_plugin_active($plugin)) {

		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

		$admin_message = '<p>' . esc_html__( 'Activate MailPoet plugin to use MailPoet Subscriber.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate MailPoet Now', 'ansh-optin-forms' ) ) . '</p>';

		echo $admin_message; // WPCS: XSS ok.

	} elseif ( ! class_exists( '\MailPoet\API\API' ) ) {

		$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=mailpoet' ), 'install-plugin_mailpoet' );
		$admin_message = '<p>' . esc_html__( 'Install MailPoet plugin to use MailPoet Subscriber.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__( 'Install MailPoet Now', 'ansh-optin-forms' ) ) . '</p>';

		echo $admin_message; // WPCS: XSS ok.
	} else {
		$mailpoet_settings = get_option( '_ansh_mailpoet_settings' );
		?>
		<form id="" action="" method="post">
			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th><label for="ansh-optin-mailpoet-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
						<td>
							<label for="ansh-optin-mailpoet-enabled" class="ansh-optin-switch">
								<input type="checkbox" id="ansh-optin-mailpoet-enabled" name="_ansh_optin_form_mailpoet" value="1" <?php checked( $mailpoet_settings['mailpoet_enabled'], '1' );?> />
								<span class="slider round"></span>
							</label>
							<label for="ansh-optin-mailpoet-enabled">&nbsp; <?php esc_html_e( 'Enable MailPoet', 'ansh-optin-forms' );?></label>
						</td>
					</tr>
				</tbody>
			</table>
			<p class="submit">

				<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
				<?php wp_nonce_field( 'mailpoet-forms-settings' ); ?>
			</p>
		</form>
		<?php
	}

}

/*
 * Subscribe MailPoet Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_mailpoet_subscribe( $signup_data ) {

	$mailpoet_settings = get_option( '_ansh_mailpoet_settings' );	
	$list_id = $signup_data['list_id'];
		
	if (  class_exists( '\MailPoet\API\API' ) ) {
		$subscriber_data = array( 
								'email' => $signup_data['email'], 
								'first_name' => $signup_data['first_name'],
								'last_name' => $signup_data['last_name'],
								'status' => 'subscribed' 
							);		
		$lists	= array( $list_id );

		try {
			\MailPoet\API\API::MP( 'v1' )->addSubscriber( $subscriber_data, $lists );
			$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
		} catch ( Exception $exception ) {			
			$response = array( 'error'	=> $exception->getMessage() );
		}
	}	
	
	return $response;
}