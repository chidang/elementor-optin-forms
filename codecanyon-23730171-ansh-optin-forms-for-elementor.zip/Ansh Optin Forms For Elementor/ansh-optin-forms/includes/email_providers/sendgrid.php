<?php

function ansh_optin_forms_sendgrid_setting() {
	global $wp_version;

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'sendgrid-forms-settings' ) ) {

		$headers = array(			
			'Authorization' => 'Bearer ' . sanitize_text_field( $_POST['_ansh_optin_form_sendgrid_api_key'] ),
		);
		$args = array(
			'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
			'headers'     => $headers,
		);

		$response = wp_remote_get('https://api.sendgrid.com/v3/marketing/lists?page_size=100', $args );

		$get_lists = json_decode( wp_remote_retrieve_body( $response ) );		

		if ( isset($get_lists->code) && $get_lists->code == 'failure' ) {
			$error = "<strong>sendgrid: </strong> " . $get_lists->message;
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';

		} else {
			$sendgrid_lists = array();
			foreach($get_lists->result as $list){
				if ( $list->id != '' && $list->name != '' ) {
				   $sendgrid_lists[] = array( 'id'=> $list->id, 'name' => $list->name );
				}
			}
			$sendgrid_settings = array(
										'sendgrid_enabled'	=> (isset($_POST['_ansh_optin_form_sendgrid'])) ? $_POST['_ansh_optin_form_sendgrid'] : '',
										'sendgrid_api_key' 	=> $_POST['_ansh_optin_form_sendgrid_api_key'],
										'sendgrid_lists'		=> $sendgrid_lists,
									);

			update_option( '_ansh_sendgrid_settings', $sendgrid_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['sendgrid'] = (isset($_POST['_ansh_optin_form_sendgrid'])) ? $_POST['_ansh_optin_form_sendgrid'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
		}

	}
	$sendgrid_settings = get_option( '_ansh_sendgrid_settings' );
	$sendgrid_settings['sendgrid_api_key'] = (isset($sendgrid_settings['sendgrid_api_key'])) ? $sendgrid_settings['sendgrid_api_key'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-sendgrid-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-sendgrid-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-sendgrid-enabled" name="_ansh_optin_form_sendgrid" value="1" <?php checked( $sendgrid_settings['sendgrid_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-sendgrid-enabled">&nbsp; <?php esc_html_e( 'Enable SendGrid', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-sendgrid-api-key">
							<?php esc_html_e( 'SendGrid API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_sendgrid_api_key" id="optin-sendgrid-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($sendgrid_settings['sendgrid_api_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://account.sendgrid.com/advanced/api" target="_blank">click Here</a> to find your sendgrid API Key.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'sendgrid-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($sendgrid_settings['sendgrid_enabled']) && $sendgrid_settings['sendgrid_enabled'] !='') : ?>
		<div class="sendgrid-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php
				if ( isset($sendgrid_settings['sendgrid_api_key']) && $sendgrid_settings['sendgrid_api_key'] !='') {					
					$headers = array(			
									'Authorization' => 'Bearer ' . sanitize_text_field( $sendgrid_settings['sendgrid_api_key'] ),
								);
					$args = array(
						'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
						'headers'     => $headers,
					);
					$response = wp_remote_get('https://api.sendgrid.com/v3/marketing/lists?page_size=100', $args );
					$get_lists = json_decode( wp_remote_retrieve_body( $response ) );					
					foreach($get_lists->result as $key=>$list){
						?>
						<tr>
							<td><?php echo esc_html($list->name);?></td>
							<td><code><?php echo esc_html($list->id);?></code></td>
							<td><?php  echo esc_html($list->contact_count);?></td>
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}


/*
 * Subscribe sendgrid Email Provider
 *
 * @since 1.5
 */
function ansh_optin_forms_sendgrid_subscribe( $signup_data ) {

	$sendgrid_settings = get_option( '_ansh_sendgrid_settings' );
	$api_key = $sendgrid_settings['sendgrid_api_key'];
	$list_id = $signup_data['list_id'];

	$post_data = array(			
			'list_ids' 		=> array( $list_id ),
			'contacts'		=> array(
									array(
										'email' 		=> sanitize_email( $signup_data['email'] ),
										'first_name'	=> $signup_data['first_name'],
										'last_name'		=> $signup_data['last_name'],
									)
							)
		);
	$headers = array(
		'Authorization' => 'Bearer ' . sanitize_text_field( $api_key ),
		'Content-Type'	=> 'application/json',

	);
	$args = array(
		'method' 		=> 'PUT',
		'timeout' 		=> 45,
		'redirection' 	=> 5,
		'httpversion' 	=> '1.0',
		'blocking' 		=> true,
		'user-agent'  	=> 'WordPress/' . $wp_version . '; ' . home_url(),
		'headers'     	=> $headers,
		'body'		  	=> wp_json_encode( $post_data ),
		'cookies' 		=> array(),
		'sslverify'		=> true,
	);
	$response = wp_remote_post('https://api.sendgrid.com/v3/marketing/contacts', $args );
	$api_response_body = json_decode( wp_remote_retrieve_body( $response ) );	
	
	if ( is_array($api_response_body->errors) && !empty($api_response_body->errors) ) {
		$response = array( 'error'	=> $api_response_body->errors[0]->message );
	} else {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}
	return $response;
}