<?php

function ansh_optin_forms_mailwizz_setting() {
	global $wp_version;
	require_once plugin_dir_path(__FILE__) . 'MailWizzApi/Autoloader.php';

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'mailwizz-forms-settings' ) ) {

		MailWizzApi_Autoloader::register();

		$config = new MailWizzApi_Config(array(
			'apiUrl'        => $_POST['_ansh_optin_form_mailwizz_api_url'],
			'publicKey'     => $_POST['_ansh_optin_form_mailwizz_public_key'],
			'privateKey'    => $_POST['_ansh_optin_form_mailwizz_private_key'],
		));

		// now inject the configuration and we are ready to make api calls
		MailWizzApi_Base::setConfig($config);

		$endpoint = new MailWizzApi_Endpoint_Lists();
		$response = $endpoint->getLists(1, 50);
		$response = $response->body->toArray();
		if ( is_wp_error( $response ) ) {
			$error_string = $response->get_error_message();
			echo '<div id="message" class="error inline"><p>' . $error_string . '</p></div>';
		} elseif ( isset($response['status']) && $response['status'] == 'error' ) {
			$error = "<strong>Mailwizz: </strong> " . $response['error'];
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		} else {

			$mailwizz_lists = array();
			foreach($response['data']['records'] as $list){
				if ( $list['general']['list_uid']!= '' && $list['general']['name'] != '' ) {
				   $mailwizz_lists[] = array( 'id'=> $list['general']['list_uid'], 'name' => $list['general']['name'] );
				}
			}

			$mailwizz_settings = array(
										'mailwizz_enabled'	=> (isset($_POST['_ansh_optin_form_mailwizz'])) ? $_POST['_ansh_optin_form_mailwizz'] : '',
										'mailwizz_api_url' 		=> $_POST['_ansh_optin_form_mailwizz_api_url'],
										'mailwizz_public_key' 	=> $_POST['_ansh_optin_form_mailwizz_public_key'],
										'mailwizz_private_key' 	=> $_POST['_ansh_optin_form_mailwizz_private_key'],
										'mailwizz_lists'		=> $mailwizz_lists,
									);

			update_option( '_ansh_mailwizz_settings', $mailwizz_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['mailwizz'] = (isset($_POST['_ansh_optin_form_mailwizz'])) ? $_POST['_ansh_optin_form_mailwizz'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';

		}
	}

	$mailwizz_settings = get_option( '_ansh_mailwizz_settings' );
	$mailwizz_settings['mailwizz_enabled'] = (isset($mailwizz_settings['mailwizz_enabled'])) ? $mailwizz_settings['mailwizz_enabled'] : '';
	$mailwizz_settings['mailwizz_api_url'] = (isset($mailwizz_settings['mailwizz_api_url'])) ? $mailwizz_settings['mailwizz_api_url'] : '';
	$mailwizz_settings['mailwizz_public_key'] = (isset($mailwizz_settings['mailwizz_public_key'])) ? $mailwizz_settings['mailwizz_public_key'] : '';
	$mailwizz_settings['mailwizz_private_key'] = (isset($mailwizz_settings['mailwizz_private_key'])) ? $mailwizz_settings['mailwizz_private_key'] : '';
	?>

	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-mailwizz-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-mailwizz-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-mailwizz-enabled" name="_ansh_optin_form_mailwizz" value="1" <?php checked( $mailwizz_settings['mailwizz_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-mailwizz-enabled">&nbsp; <?php esc_html_e( 'Enable MailWizz', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-mailwizz-api-url"><?php esc_html_e( 'Api url', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_mailwizz_api_url" id="ansh-optin-mailwizz-api-url" class="input-text regular-input" placeholder="Api url" value="<?php echo esc_attr($mailwizz_settings['mailwizz_api_url']);?>"/>
						<p class="description"><?php echo "your API Url: e.g. http://< your-mailwizz-url >/api/index.php"; ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-mailwizz-public-key"><?php esc_html_e( 'Public api key', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_mailwizz_public_key" id="ansh-optin-mailwizz-public-key" class="input-text regular-input" placeholder="Public api key" value="<?php echo esc_attr($mailwizz_settings['mailwizz_public_key']);?>"/>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-mailwizz-private-key"><?php esc_html_e( 'Private api key', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_mailwizz_private_key" id="ansh-optin-mailwizz-private-key" class="input-text regular-input" placeholder="Private api key" value="<?php echo esc_attr($mailwizz_settings['mailwizz_private_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://kb.mailwizz.com/articles/find-api-info/" target="_blank">click Here</a> to find mailwizz Public api key & Private api key.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'mailwizz-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($mailwizz_settings['mailwizz_enabled']) && $mailwizz_settings['mailwizz_enabled'] !='') : ?>
		<div class="mailwizz-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($mailwizz_settings['mailwizz_public_key']) && $mailwizz_settings['mailwizz_public_key'] !='') {

					MailWizzApi_Autoloader::register();

					$config = new MailWizzApi_Config(array(
						'apiUrl'        => $mailwizz_settings['mailwizz_api_url'],
						'publicKey'     => $mailwizz_settings['mailwizz_public_key'],
						'privateKey'    => $mailwizz_settings['mailwizz_private_key'],
					));

					// now inject the configuration and we are ready to make api calls
					MailWizzApi_Base::setConfig($config);

					$endpoint = new MailWizzApi_Endpoint_Lists();
					$response = $endpoint->getLists(1, 50);
					$response = $response->body->toArray();
					foreach($response['data']['records'] as $key=>$list){
							$endpoint = new MailWizzApi_Endpoint_ListSubscribers();
							$subscribers_response = $endpoint->getSubscribers($list['general']['list_uid'], $pageNumber = 1, $perPage = 50);
							$subscribers_response = $subscribers_response->body->toArray();

							$count = ($subscribers_response['data']['count'] != '') ? $subscribers_response['data']['count'] : 0;
						?>
						<tr>
							<td><?php echo esc_html($list['general']['name']);?></td>
							<td><code><?php echo esc_html($list['general']['list_uid']);?></code></td>
							<td><?php  echo esc_html($count); ?></td>
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}

/*
 * Subscribe mailwizz Email Provider
 *
 * @since 1.1
 */
function ansh_optin_forms_mailwizz_subscribe( $signup_data ) {
	$mailwizz_settings = get_option( '_ansh_mailwizz_settings' );
	$mailwizz_app_url = $mailwizz_settings['mailwizz_app_url'];
	$mailwizz_public_key = $mailwizz_settings['mailwizz_public_key'];
	$mailwizz_private_key = $mailwizz_settings['mailwizz_private_key'];
	$list_id = $signup_data['list_id'];
	require_once( ANSH_OPTIN_FORMS_PATH . 'includes/email_providers/MailWizzApi/Autoloader.php');

	MailWizzApi_Autoloader::register();

	$config = new MailWizzApi_Config(array(
		'apiUrl'        => $mailwizz_settings['mailwizz_api_url'],
		'publicKey'     => $mailwizz_settings['mailwizz_public_key'],
		'privateKey'    => $mailwizz_settings['mailwizz_private_key'],
	));

	// now inject the configuration and we are ready to make api calls
	MailWizzApi_Base::setConfig($config);

	$endpoint   = new MailWizzApi_Endpoint_ListSubscribers();
    $api_response  = $endpoint->create($list_id, array(
        'EMAIL' => $signup_data['email'],
        'FNAME' => $signup_data['first_name'],
        'LNAME' => $signup_data['last_name'],
		'NAME'  => trim($signup_data['first_name'] . ' ' . $signup_data['last_name']),
    ));
	$api_response_body = $api_response->body->toArray();		
	if ( isset($api_response_body['status']) && $api_response_body['status'] =='error' ) {
		$response = array( 'error'	=> $api_response_body['error'] );
	}
	if ( isset($api_response_body['status']) && $api_response_body['status'] =='success' ) {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}
	
	return $response;
}
