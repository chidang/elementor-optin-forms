<?php
/*
 * Subscribe to Local Database
 *
 * @since 1.4
 */
 
function ansh_optin_forms_local_db_subscribe( $signup_data ) {
	global$wpdb;
	
	
	$ansh_optin_contact_lists = $wpdb->prefix . 'ansh_optin_contact_lists';
	$check_existing = $wpdb->get_results( "SELECT * FROM `$ansh_optin_contact_lists` WHERE email = '" . $signup_data['email'] . "'" );
	
	if (empty($check_existing)) {
		$resultss = $wpdb->insert( 
			$ansh_optin_contact_lists, 
			array( 
					'first_name'=> $signup_data['first_name'],
					'last_name' => $signup_data['last_name'],
					'email' 	=> $signup_data['email'],
				) 
			);
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}else{		
		$response = array( 'message'  => esc_html__("Subscriber Already Exists.", 'ansh-optin-forms' ));
	}	
	return $response;
}