<?php

function ansh_optin_forms_mailchimp_setting() {
	
	require_once plugin_dir_path(__FILE__) . 'Mailchimp/Mailchimp.php';
	
	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'mailchimp-forms-settings' ) ) {
		global $wp_version;

		require_once plugin_dir_path(__FILE__) . 'Mailchimp/Mailchimp.php';
		try {
			$mailchimp = new Mailchimp( $_POST['_ansh_optin_form_mailchimp_api_key'] );
			$get_lists = $mailchimp->lists->getList();
			$mailchimp_lists = array();
			foreach ($get_lists['data'] as $list){
				if ( $list['id'] != '' && $list['name'] != '' ) {
				   $mailchimp_lists[] = array( 'id'=> $list['id'], 'name' => $list['name'] );
				}
			}
			$mailchimp_settings = array(
										'mailchimp_enabled'	=> (isset($_POST['_ansh_optin_form_mailchimp'])) ? $_POST['_ansh_optin_form_mailchimp'] : '',
										'mailchimp_api_key' => $_POST['_ansh_optin_form_mailchimp_api_key'],
										'mailchimp_lists'	=> $mailchimp_lists,
									);

			update_option( '_ansh_mailchimp_settings', $mailchimp_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['mailchimp'] = (isset($_POST['_ansh_optin_form_mailchimp'])) ? $_POST['_ansh_optin_form_mailchimp'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';


		} catch (Exception $e) {
			$error = "<strong>MailChimp: </strong> Invalid MailChimp API key. Please enter correct API Key.";
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		}


	}
	$mailchimp_settings = get_option( '_ansh_mailchimp_settings' );
	$mailchimp_settings['mailchimp_api_key'] = ( isset($mailchimp_settings['mailchimp_api_key'])) ? $mailchimp_settings['mailchimp_api_key'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-mailchimp-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-mailchimp-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-mailchimp-enabled" name="_ansh_optin_form_mailchimp" value="1" <?php checked( $mailchimp_settings['mailchimp_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-mailchimp-enabled">&nbsp; <?php esc_html_e( 'Enable MailChimp', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-mailchimp-api-key">
							<?php esc_html_e( 'MailChimp API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_mailchimp_api_key" id="optin-mailchimp-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($mailchimp_settings['mailchimp_api_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://mailchimp.com/help/about-api-keys/" target="_blank">click Here</a> to find your MailChimp API Key.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'mailchimp-forms-settings' ); ?>
		</p>
	</form>
	
	<?php if ( isset($mailchimp_settings['mailchimp_enabled']) && $mailchimp_settings['mailchimp_enabled'] !='') : ?>
		<div class="mailchimp-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php
				if ( isset($mailchimp_settings['mailchimp_api_key']) && $mailchimp_settings['mailchimp_api_key'] !='') {
					try {
						$mailchimp = new Mailchimp( $mailchimp_settings['mailchimp_api_key'] );
						$get_lists = $mailchimp->lists->getList();					
						if ( !empty($get_lists['data']) ) :
							foreach($get_lists['data'] as $list) :
								?>
								<tr>
									<td><?php echo esc_html($list['name']);?></td>
									<td><code><?php echo esc_html($list['id']);?></code></td>
									<td><?php echo esc_html($list['stats']['member_count']);?></td>
								</tr>
								<?php
							endforeach;
							
						endif;
						
					} catch (Exception $e) {
						
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}


/*
 * Subscribe MailChimp Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_mailchimp_subscribe( $signup_data ) {

	$mailchimp_settings = get_option( '_ansh_mailchimp_settings' );
	$api_key = $mailchimp_settings['mailchimp_api_key'];
	$list_id = $signup_data['list_id'];
	require_once( ANSH_OPTIN_FORMS_PATH . 'includes/email_providers/Mailchimp/Mailchimp.php');
	$double_optin = '';
	try {
		$mailchimp = new Mailchimp($api_key);
		$post_params = array(
			'email'  		=> $signup_data['email'],
			'FNAME' 		=> $signup_data['first_name'],
			'LNAME' 		=> $signup_data['last_name'],
			'status' 		=> 'subscribed',

		);
		$double_optin = ($double_optin != '') ? true : false;
		try {
			$response = $mailchimp->lists->subscribe($list_id, $post_params, $post_params , 'html' , $double_optin);
			if ( ! empty($response) && ( isset($response['email']) && $response['email'] != '' ) && ( isset($response['euid']) && $response['euid'] != '' ) && ( isset($response['leid']) && $response['leid'] != '' ) ) {

				$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
			}
		} catch (Exception $e) {
			$response = array( 'error'	=> $e->getMessage() );
		}
	} catch (Exception $e) {
		$response = array( 'error'	=> $e->getMessage() );
	}
	return $response;
}