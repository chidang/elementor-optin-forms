<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class AC_Subscriber extends AC_Contact {
}

?>