<?php

function ansh_optin_forms_acymailing_setting() {

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'acymailing-forms-settings' ) ) {

		$acymailing_lists = array();
		if (  class_exists( 'acymInit' ) ) {
			$listClass = acym_get('class.list');
			$lists = $listClass->getAll();			
			foreach($lists as $list){
				if ( $list->id != '' && $list->name != '' ) {
					$acymailing_lists[] = array( 'id'=> $list->id, 'name' => $list->name );
				}
			}
		}

		$acymailing_settings = array(
									'acymailing_enabled'	=> (isset($_POST['_ansh_optin_form_acymailing'])) ? $_POST['_ansh_optin_form_acymailing'] : '',
									'acymailing_lists'	=> $acymailing_lists,
								);

		update_option( '_ansh_acymailing_settings', $acymailing_settings);

		$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
		$optin_enabled_forms['acymailing'] = (isset($_POST['_ansh_optin_form_acymailing'])) ? $_POST['_ansh_optin_form_acymailing'] : '';
		update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

		$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
		echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
	}


	$plugin = 'acymailing/index.php';
	$installed_plugins = get_plugins();
	if ( isset($installed_plugins[$plugin]) && !is_plugin_active($plugin)) {

		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

		$admin_message = '<p>' . esc_html__( 'Activate acymailing plugin to use acymailing Subscriber.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate acymailing Now', 'ansh-optin-forms' ) ) . '</p>';

		echo $admin_message; // WPCS: XSS ok.

	} elseif ( ! class_exists( 'acymInit' ) ) {

		$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=acymailing' ), 'install-plugin_acymailing' );
		$admin_message = '<p>' . esc_html__( 'Install acymailing plugin to use acymailing Subscriber.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__( 'Install acymailing Now', 'ansh-optin-forms' ) ) . '</p>';

		echo $admin_message; // WPCS: XSS ok.
	} else {
		$acymailing_settings = get_option( '_ansh_acymailing_settings' );
		$acymailing_settings['acymailing_enabled'] = (isset($acymailing_settings['acymailing_enabled'])) ? $acymailing_settings['acymailing_enabled'] : '';
		?>
		<form id="" action="" method="post">
			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th><label for="ansh-optin-acymailing-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
						<td>
							<label for="ansh-optin-acymailing-enabled" class="ansh-optin-switch">
								<input type="checkbox" id="ansh-optin-acymailing-enabled" name="_ansh_optin_form_acymailing" value="1" <?php checked( $acymailing_settings['acymailing_enabled'], '1' );?> />
								<span class="slider round"></span>
							</label>
							<label for="ansh-optin-acymailing-enabled">&nbsp; <?php esc_html_e( 'Enable AcyMailing', 'ansh-optin-forms' );?></label>
						</td>
					</tr>
				</tbody>
			</table>
			<p class="submit">

				<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
				<?php wp_nonce_field( 'acymailing-forms-settings' ); ?>
			</p>
		</form>
		<?php
	}
	
	if ( isset($acymailing_settings['acymailing_enabled']) && $acymailing_settings['acymailing_enabled'] !='') : ?>
		<div class="mailwizz-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($acymailing_settings['acymailing_enabled']) && $acymailing_settings['acymailing_enabled'] !='') {

					$listClass = acym_get('class.list');
					$lists = $listClass->getAll();	
					foreach($lists as $key=>$list){
							$subscribers_count = $listClass->getSubscribersCountByListId($list->id);
							$count = ($subscribers_count != '') ? $subscribers_count : 0;
						?>
						<tr>
							<td><?php echo esc_html($list->name);?></td>
							<td><code><?php echo esc_html($list->id);?></code></td>
							<td><?php  echo esc_html($count); ?></td>
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;

}

/*
 * Subscribe acymailing Email Provider
 *
 * @since 1.2
 */
function ansh_optin_forms_acymailing_subscribe( $signup_data ) {

	$acymailing_settings = get_option( '_ansh_acymailing_settings' );	
	$list_id = $signup_data['list_id'];
		
	if (  class_exists( 'acymInit' ) ) {
		
		$userClass = acym_get('class.user');
		$user = new stdClass();
		$user->name = $signup_data['first_name'] . ' ' . $signup_data['last_name'];
		$user->email = $signup_data['email'];
		$user->active = true;
		$user->confirmed = true;
		$get_user = $userClass->getOneByEmail($user->email);
		
		if ( $get_user == '' ) {
			$user->creation_date = date("Y-m-d H:i:s");
			$userId = $userClass->save($user);
		} else {
			$userId = $get_user->id;
		}
		$subscribed = $userClass->subscribe($userId, $list_id);
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));		
	} else {
		$response = array( 'error'  => esc_html__("Please enable AcyMailing for your contact lists.", 'ansh-optin-forms' ));		
	}
	
	return $response;
}