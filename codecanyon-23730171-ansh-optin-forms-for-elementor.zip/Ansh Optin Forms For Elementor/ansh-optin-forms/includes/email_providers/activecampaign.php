<?php
/*
 *
 *
 */
function ansh_optin_forms_activecampaign_setting() {

	require_once plugin_dir_path(__FILE__) . "ActiveCampaignAPI/ActiveCampaign.class.php";

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'activecampaign-forms-settings' ) ) {
		$ac = new ActiveCampaign( $_POST['_ansh_optin_form_activecampaign_url'], $_POST['_ansh_optin_form_activecampaign_api_key'] );


		if (!(int)$ac->credentials_test()) {

			$error = "<strong>Active Campaign: </strong>".'Access denied: Invalid Active Campaign credentials (URL and/or API key).';
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';

		} else {
			$url = $_POST['_ansh_optin_form_activecampaign_url'].'/admin/api.php?api_key='.$_POST['_ansh_optin_form_activecampaign_api_key'].'&api_action=list_list&api_output=xml&ids=all&full=1';
			$get_lists = simplexml_load_file($url);
			$get_lists = json_decode( json_encode($get_lists) , 1);
			$activecampaign_lists = array();
			foreach($get_lists['row'] as $list){
				$activecampaign_lists[] = array( 'id'=> $list['id'], 'name' => $list['name'] );
			}

			$activecampaign_settings = array(
										'activecampaign_enabled'	=> (isset($_POST['_ansh_optin_form_activecampaign'])) ? $_POST['_ansh_optin_form_activecampaign'] : '',
										'activecampaign_url' 		=> $_POST['_ansh_optin_form_activecampaign_url'],
										'activecampaign_api_key' 	=> $_POST['_ansh_optin_form_activecampaign_api_key'],
										'activecampaign_lists'		=> $activecampaign_lists,
									);

			update_option( '_ansh_activecampaign_settings', $activecampaign_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['activecampaign'] = (isset($_POST['_ansh_optin_form_activecampaign'])) ? $_POST['_ansh_optin_form_activecampaign'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
		}
	}

	$activecampaign_settings = get_option( '_ansh_activecampaign_settings' );
	$activecampaign_settings['activecampaign_url'] = (isset($activecampaign_settings['activecampaign_url'])) ? $activecampaign_settings['activecampaign_url'] : '';
	$activecampaign_settings['activecampaign_api_key'] = (isset($activecampaign_settings['activecampaign_api_key'])) ? $activecampaign_settings['activecampaign_api_key'] : '';
	?>
	<form id="forms-activecampaign" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-activecampaign-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-activecampaign-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-activecampaign-enabled" name="_ansh_optin_form_activecampaign" value="1" <?php checked( $activecampaign_settings['activecampaign_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-activecampaign-enabled">&nbsp;<?php esc_html_e( 'Enable Active Campaign', 'ansh-optin-forms' );?></label>
					</td>
				</tr>

				<tr valign="top">
					<th>
						<label for="optin-activecampaign-url">
							<?php esc_html_e( 'Active Campaign URL', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_activecampaign_url"  id="optin-activecampaign-url" class="input-text regular-input" placeholder="https://<account-name>.api-us1.com" value="<?php echo esc_attr($activecampaign_settings['activecampaign_url'])?>"/>
					</td>
				</tr>

				<tr valign="top">
					<th>
						<label for="optin-activecampaign-api-key">
							<?php esc_html_e( 'Active Campaign API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_activecampaign_api_key" id="optin-activecampaign-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($activecampaign_settings['activecampaign_api_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="http://www.activecampaign.com/help/using-the-api/" target="_blank">click Here</a> to find your Active Campaig URL & API KEY.'; ?></p>
		<p class="submit">

			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'activecampaign-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($activecampaign_settings['activecampaign_enabled']) && $activecampaign_settings['activecampaign_enabled'] !=''): ?>
		<div class="activecampaign-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($activecampaign_settings['activecampaign_api_key']) && $activecampaign_settings['activecampaign_api_key'] !='') {
					$ac = new ActiveCampaign( $activecampaign_settings['activecampaign_url'], $activecampaign_settings['activecampaign_api_key'] );
					if ((int)$ac->credentials_test()) {
						$url = $activecampaign_settings['activecampaign_url'].'/admin/api.php?api_key='.$activecampaign_settings['activecampaign_api_key'].'&api_action=list_list&api_output=xml&ids=all&full=1';
						$get_lists = simplexml_load_file($url);
						$get_lists = json_decode( json_encode($get_lists) , 1);
						foreach($get_lists['row'] as $list){
							?>
							<tr>
								<td><?php echo esc_html($list['name']);?></td>
								<td><code><?php echo esc_html($list['id']);?></code></td>
								<td><?php echo esc_html($list['subscribers']);?></td>
							</tr>
							<?php
						}

					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}

/*
 * Subscribe GetResponse Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_activecampaign_subscribe ( $signup_data ) {


	require_once( ANSH_OPTIN_FORMS_PATH . "includes/email_providers/ActiveCampaignAPI/ActiveCampaign.class.php");

	$activecampaign_settings = get_option( '_ansh_activecampaign_settings' );

	$activecampaign = new ActiveCampaign( $activecampaign_settings['activecampaign_url'], $activecampaign_settings['activecampaign_api_key']);
	$list_id = $signup_data['list_id'];

	$contact = array(
				"email" 			=> sanitize_text_field($signup_data['email']),
				"first_name" 		=> sanitize_text_field($signup_data['first_name']),
				"last_name" 		=> sanitize_text_field($signup_data['last_name']),
				"p[$list_id]" 		=> $list_id,
				"status[$list_id]" 	=> 1,
			);
	$contact_sync = $activecampaign->api( "contact/sync", $contact );
	if (!(int)$contact_sync->success) {
		$response = array( 'error' => $contact_sync->error  );

	} else {
		$contact_id = (int)$contact_sync->subscriber_id;
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}

	return $response;
}