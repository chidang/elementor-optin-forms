<?php

function ansh_optin_forms_icontact_setting() {
	global $wp_version;

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'icontact-forms-settings' ) ) {

		$headers = array(
			'Accept' 		=> 'application/json',
			'Content-type'	=> 'application/json',
			'Api-Version' 	=> 2.2,
			'Api-AppId' 	=> $_POST['_ansh_optin_form_icontact_app_id'],
			'Api-Username' 	=> $_POST['_ansh_optin_form_icontact_api_username'],
			'Api-Password' 	=> $_POST['_ansh_optin_form_icontact_api_password']
		);
		$args = array(
			'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
			'headers'     => $headers,
		);
		$response = wp_remote_get($_POST['_ansh_optin_form_icontact_api_url'].'lists/', $args);
		$get_lists = json_decode( wp_remote_retrieve_body( $response ) );

		if ( is_wp_error( $response ) ) {
		   $error_string = $response->get_error_message();
		   echo '<div id="message" class="error inline"><p>' . $error_string . '</p></div>';

		} elseif ( isset($get_lists->errors[0]) && $get_lists->errors[0] != '' ) {
			$error = "<strong>iContact: </strong> " . $get_lists->errors[0];
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		} else {
			$icontact_lists = array();
			foreach($get_lists->lists as $list){
				if ( $list->listId != '' && $list->name != '' ) {
				   $icontact_lists[] = array( 'id'=> $list->listId, 'name' => $list->name );
				}
			}

			$icontact_settings = array(
										'icontact_enabled'		=> (isset($_POST['_ansh_optin_form_icontact'])) ? $_POST['_ansh_optin_form_icontact'] : '',
										'icontact_app_id' 		=> $_POST['_ansh_optin_form_icontact_app_id'],
										'icontact_api_username' => $_POST['_ansh_optin_form_icontact_api_username'],
										'icontact_api_password'	=> $_POST['_ansh_optin_form_icontact_api_password'],
										'icontact_app_url' 		=> $_POST['_ansh_optin_form_icontact_api_url'],
										'icontact_lists'		=> $icontact_lists,
									);

			update_option( '_ansh_icontact_settings', $icontact_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['icontact'] = (isset($_POST['_ansh_optin_form_icontact'])) ? $_POST['_ansh_optin_form_icontact'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
		}

	}

	$icontact_settings = get_option( '_ansh_icontact_settings' );
	$icontact_settings['icontact_app_id'] = (isset($icontact_settings['icontact_app_id'])) ? $icontact_settings['icontact_app_id'] : '';
	$icontact_settings['icontact_api_username'] = (isset($icontact_settings['icontact_api_username'])) ? $icontact_settings['icontact_api_username'] : '';
	$icontact_settings['icontact_api_password'] = (isset($icontact_settings['icontact_api_password'])) ? $icontact_settings['icontact_api_password'] : '';
	$icontact_settings['icontact_app_url'] = (isset($icontact_settings['icontact_app_url'])) ? $icontact_settings['icontact_app_url'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-icontact-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-icontact-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-icontact-enabled" name="_ansh_optin_form_icontact" value="1" <?php checked( $icontact_settings['icontact_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-icontact-enabled">&nbsp; <?php esc_html_e( 'Enable iContact', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-icontact-app-id"><?php esc_html_e( 'iContact App ID', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_icontact_app_id" id="ansh-optin-icontact-app-id" class="input-text regular-input" placeholder="App ID" value="<?php echo esc_attr($icontact_settings['icontact_app_id']);?>"/>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-icontact-api-username"><?php esc_html_e( 'iContact API Username', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_icontact_api_username" id="ansh-optin-icontact-api-username" class="input-text regular-input" placeholder="API Username" value="<?php echo esc_attr($icontact_settings['icontact_api_username']);?>"/>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-icontact-api-password"><?php esc_html_e( 'iContact API Password', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_icontact_api_password" id="ansh-optin-icontact-api-password" class="input-text regular-input" placeholder="API Password" value="<?php echo esc_attr($icontact_settings['icontact_api_password']);?>"/>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-icontact-api-url"><?php esc_html_e( 'iContact API URL', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_icontact_api_url" id="ansh-optin-icontact-api-url" class="input-text regular-input" placeholder="API URL" value="<?php echo esc_attr($icontact_settings['icontact_app_url']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://www.icontact.com/developerportal/pro/documentation/register-your-app" target="_blank">click Here</a> to find iContact APP ID, Username, Paddword & API URL.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'icontact-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($icontact_settings['icontact_enabled']) && $icontact_settings['icontact_enabled'] !='') : ?>
		<div class="icontact-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<!--td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td-->
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($icontact_settings['icontact_app_id']) && $icontact_settings['icontact_app_id'] !='') {

					$headers = array(
						'Accept' 		=> 'application/json',
						'Content-type'	=> 'application/json',
						'Api-Version' 	=> 2.2,
						'Api-AppId' 	=> $icontact_settings['icontact_app_id'],
						'Api-Username' 	=> $icontact_settings['icontact_api_username'],
						'Api-Password' 	=> $icontact_settings['icontact_api_password']
					);
					$args = array(
						'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
						'headers'     => $headers,
					);
					$response = wp_remote_get($icontact_settings['icontact_app_url'].'lists/', $args);
					$get_lists = json_decode( wp_remote_retrieve_body( $response ) );
					foreach($get_lists->lists as $key=>$list){
						?>
						<tr>
							<td><?php echo esc_html($list->name);?></td>
							<td><code><?php echo esc_html($list->listId);?></code></td>
							<!--td><?php  /* echo esc_html($list->metaData->size); */?></td-->
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;

}

/*
 * Subscribe iContact Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_icontact_subscribe( $signup_data ) {

	$icontact_settings = get_option( '_ansh_icontact_settings' );
	$icontact_app_url = $icontact_settings['icontact_app_url'];
	$list_id = $signup_data['list_id'];
	$headers = array(
		'Accept' => 'application/json',
		'Content-type'	=> 'application/json',
		'Api-Version' 	=> 2.2,
		'Api-AppId' 	=> $icontact_settings['icontact_app_id'],
		'Api-Username' 	=> $icontact_settings['icontact_api_username'],
		'Api-Password' 	=> $icontact_settings['icontact_api_password']
	);
	$args = array(
				'method' => 'POST',
				'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
				'headers'     => $headers,
				'body'		  => '[
									  {
										"email":"'.$signup_data['email'].'",
										"firstName": "'.$signup_data['first_name'].'",
										"lastName": "'.$signup_data['last_name'].'",
										"business":"iContact",
										"status":"normal"
									  }
								]',
			);
	$api_response = wp_remote_post($icontact_app_url.'contacts/', $args);
	$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ) );

	if ( isset($api_response_body->errors[0]) && $api_response_body->errors[0] !='' ) {
		$response = array( 'error'	=> $api_response_body->errors[0] );
	}else {

		$args = array(
				'method' => 'POST',
				'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
				'headers'     => $headers,
				'body'		  => '[
									  {
										"contactId":'.$api_response_body->contacts[0]->contactId.',
										"listId":'.$list_id.',
										"status":"normal"
									  }
									]',
			);
		$api_response = wp_remote_post('https://app.icontact.com/icp/a/1774625/c/6834/subscriptions/', $args);
		$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ) );

		if ( isset($api_response_body->warnings[0]) && $api_response_body->warnings[0] !=''  ) {
			$response = array( 'error'	=> $api_response_body->warnings[0] );
		} else {
			$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
		}
	}
	return $response;
}