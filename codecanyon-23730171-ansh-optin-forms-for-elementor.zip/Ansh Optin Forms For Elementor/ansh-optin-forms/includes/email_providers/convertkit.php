<?php

function ansh_optin_forms_convertkit_setting() {
	global $wp_version;
	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'convertkit-forms-settings' ) ) {

		$response = wp_remote_get('https://api.convertkit.com/v3/forms?api_key='. $_POST['_ansh_optin_form_convertkit_api_key']);

		$get_lists = json_decode( wp_remote_retrieve_body( $response ) );
		if ( isset($get_lists->error) && $get_lists->error != '' ) {
			$error = "<strong>Constant Contact: </strong>" . $get_lists->message;
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		} else {

			$convertkit_lists = array();
			foreach($get_lists->forms as $list){
				if ( $list->id != '' && $list->name != '' ) {
				   $convertkit_lists[] = array( 'id'=> $list->id, 'name' => $list->name );
				}
			}
			$convertkit_settings = array(
										'convertkit_enabled'	=> (isset($_POST['_ansh_optin_form_convertkit'])) ? $_POST['_ansh_optin_form_convertkit'] : '',
										'convertkit_api_key' 	=> $_POST['_ansh_optin_form_convertkit_api_key'],
										'convertkit_api_secret' 	=> $_POST['_ansh_optin_form_convertkit_api_secret'],
										'convertkit_lists'		=> $convertkit_lists,
									);

			update_option( '_ansh_convertkit_settings', $convertkit_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['convertkit'] = (isset($_POST['_ansh_optin_form_convertkit'])) ? $_POST['_ansh_optin_form_convertkit'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';

		}
	}
	$convertkit_settings = get_option( '_ansh_convertkit_settings' );
	$convertkit_settings['convertkit_api_key'] = (isset($convertkit_settings['convertkit_api_key'])) ? $convertkit_settings['convertkit_api_key'] : '';
	
	$convertkit_settings['convertkit_api_secret'] = (isset($convertkit_settings['convertkit_api_secret'])) ? $convertkit_settings['convertkit_api_secret'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-convertkit-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-convertkit-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-convertkit-enabled" name="_ansh_optin_form_convertkit" value="1" <?php checked( $convertkit_settings['convertkit_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-convertkit-enabled">&nbsp; <?php esc_html_e( 'Enable ConvertKit', 'ansh-optin-forms' );?></label>

					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-convertkit-api-key">
							<?php esc_html_e( 'ConvertKit API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_convertkit_api_key" id="optin-convertkit-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($convertkit_settings['convertkit_api_key']);?>"/>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-convertkit-api-secret">
							<?php esc_html_e( 'ConvertKit API Secret', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_convertkit_api_secret" id="optin-convertkit-api-secret" class="input-text regular-input" placeholder="API Secret" value="<?php echo esc_attr($convertkit_settings['convertkit_api_secret']);?>"/>
					</td>
				</tr>

			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://app.convertkit.com/account/edit#account_info" target="_blank">click Here</a> to find ConvertKit API Key.'; ?></p>
		<p class="submit">

			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'convertkit-forms-settings' ); ?>
		</p>
	</form>


	<?php if ( isset($convertkit_settings['convertkit_enabled']) && $convertkit_settings['convertkit_enabled'] !=''): ?>
	<div class="convertkit-lists-overview">
		<table class="ansh_optin_form_tbl widefat">
			<thead>
				<tr>
					<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
					<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
					<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
				</tr>
			</thead>
			<tbody>
			<?php

			if ( isset($convertkit_settings['convertkit_api_key']) && $convertkit_settings['convertkit_api_key'] !='') {

				$convertkit_api_key = $convertkit_settings['convertkit_api_key'];
				$convertkit_api_secret = $convertkit_settings['convertkit_api_secret'];
				$response = wp_remote_get('https://api.convertkit.com/v3/forms?api_key='. $convertkit_api_key);
				$get_lists = json_decode( wp_remote_retrieve_body( $response ) );
				foreach( $get_lists->forms as $list ){

					$response = wp_remote_get('https://api.convertkit.com/v3/forms/' . $list->id . '/subscriptions?api_secret='. $convertkit_api_secret);
					$get_subscriptions = json_decode( wp_remote_retrieve_body( $response ) );

					?>
					<tr>
						<td><?php echo esc_html($list->name);?></td>
						<td><code><?php echo esc_html($list->id);?></code></td>
						<td><?php echo esc_html($get_subscriptions->total_subscriptions);?></td>
					</tr>
					<?php
				}
			}
			?>
			</tbody>
		</table>
	</div>
	<?php
	endif;
}

/*
 * Subscribe ConvertKit Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_convertkit_subscribe( $signup_data ) {

	$convertkit_settings = get_option( '_ansh_convertkit_settings' );
	$api_key = $convertkit_settings['convertkit_api_key'];
	$access_token = $convertkit_settings['convertkit_access_token'];
	$list_id = $signup_data['list_id'];

	$args = array(
				'method' 		=> 'POST',
				'Content-Type'	=> 'application/json',
				'user-agent'  	=> 'WordPress/' . $wp_version . '; ' . home_url(),
				'body'        	=> array(
									'api_key' 		=> $api_key,
									'email'			=> $signup_data['email'],
									'first_name' 	=> $signup_data['first_name'],
									'last_name' 	=> $signup_data['last_name'],
								),

			);
	$api_response = wp_remote_post('https://api.convertkit.com/v3/forms/' . $list_id . '/subscribe', $args);
	$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ) );

	if ( $api_response_body->error !='' && $api_response_body->message !='' ) {
		$response = array( 'error'	=> $api_response_body->message );
	} else {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}

	return $response;
}