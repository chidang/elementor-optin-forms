<?php

function ansh_optin_forms_mailster_setting() {

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'mailster-forms-settings' ) ) {

		$mailster_lists = array();
		if ( function_exists( 'mailster' ) ) {
			$mailsterlists = mailster( 'lists' )->get( null, null, true );
			
		
			foreach($mailsterlists as $list ){				
				if ( $list->ID != '' && $list->name != '' ) {
					$mailster_lists[] = array( 'id'=> $list->ID, 'name' => $list->name );
				}
			}
		}

		$mailster_settings = array(
									'mailster_enabled'	=> (isset($_POST['_ansh_optin_form_mailster'])) ? $_POST['_ansh_optin_form_mailster'] : '',
									'mailster_lists'	=> $mailster_lists,
								);
			
		update_option( '_ansh_mailster_settings', $mailster_settings);

		$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
		$optin_enabled_forms['mailster'] = (isset($_POST['_ansh_optin_form_mailster'])) ? $_POST['_ansh_optin_form_mailster'] : '';
		update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

		$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
		echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
	}


	$plugin = 'mailster/mailster.php';
	$installed_plugins = get_plugins();
	if ( isset($installed_plugins[$plugin]) && !is_plugin_active($plugin)) {

		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

		$admin_message = '<p>' . esc_html__( 'Activate Mailster plugin to use Mailster Newsletter.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate Mailster Now', 'ansh-optin-forms' ) ) . '</p>';

		echo $admin_message; // WPCS: XSS ok.

	} elseif ( ! function_exists( 'mailster' ) ) {

		$install_url = "https://codecanyon.net/item/mailster-email-newsletter-plugin-for-wordpress/3078294?ref=theanshtheme";
		$admin_message = '<p>' . esc_html__( 'Install Mailster plugin to use Mailster Newsletter.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary" target="_blank">%s</a>', $install_url, esc_html__( 'Install Mailster Now', 'ansh-optin-forms' ) ) . '</p>';

		echo $admin_message; // WPCS: XSS ok.
		
	} else {
		$mailster_settings = get_option( '_ansh_mailster_settings' );
		?>
		<form id="" action="" method="post">
			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th><label for="ansh-optin-mailster-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
						<td>
							<label for="ansh-optin-mailster-enabled" class="ansh-optin-switch">
								<input type="checkbox" id="ansh-optin-mailster-enabled" name="_ansh_optin_form_mailster" value="1" <?php checked( $mailster_settings['mailster_enabled'], '1' );?> />
								<span class="slider round"></span>
							</label>
							<label for="ansh-optin-mailster-enabled">&nbsp; <?php esc_html_e( 'Enable MailSter', 'ansh-optin-forms' );?></label>
						</td>
					</tr>
				</tbody>
			</table>
			<p class="submit">

				<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
				<?php wp_nonce_field( 'mailster-forms-settings' ); ?>
			</p>
		</form>
		<?php
	}

}

/*
 * Subscribe Mailster Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_mailster_subscribe( $signup_data ) {

	$mailster_settings = get_option( '_ansh_mailster_settings' );	
	$list_id = $signup_data['list_id'];
		
	if (  function_exists( 'mailster' ) ) {
		$subscriber_data = array( 
								'email' 		=> $signup_data['email'], 
								'firstname' 	=> $signup_data['first_name'],
								'lastname' 		=> $signup_data['last_name'],
								'status' 		=> '1' 
							);
		$subscriber_id = mailster( 'subscribers' )->add( $subscriber_data, false );

		if ( is_wp_error( $subscriber_id ) ) {			
			$response = array( 'error'	=> $subscriber_id->get_error_message() );
		} else if ( mailster( 'subscribers' )->assign_lists( $subscriber_id, $list_id, false ) ) {			
			$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
		} else {
			$response = array( 'error'	=> esc_html__( 'An error occurred. Please try again later.', 'ansh-optin-forms' ) );
		}
	}	
	
	return $response;
}