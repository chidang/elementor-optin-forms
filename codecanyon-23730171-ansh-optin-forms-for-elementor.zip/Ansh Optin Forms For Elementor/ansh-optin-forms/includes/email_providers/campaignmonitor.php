<?php
function ansh_optin_forms_campaignmonitor_setting() {

	global $wp_version;


	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'campaignmonitor-forms-settings' ) ) {

		$headers = array(
			'Authorization' => 'Basic ' . base64_encode($_POST['_ansh_optin_form_campaignmonitor_api_key']),
			'Accept'		=> 'application/json',
		);
		$args = array(
			'method' 		=> 'GET',
			'timeout' 		=> 30,
			'blocking' 		=> true,
			'user-agent'  	=> 'WordPress/' . $wp_version . '; ' . home_url(),
			'headers'     	=> $headers,
			'cookies' 		=> array(),
			'sslverify'		=> true,
		);
		$response = wp_remote_get('https://api.createsend.com/api/v3.1/clients.json', $args);
		$get_response = json_decode( wp_remote_retrieve_body( $response ) );
		if ( isset($get_response->Message) && $get_response->Message != '' ) {
			$error = "<strong>CampaignMonitor: </strong> " . $get_response->Message;
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		} else {

			$ClientID = $get_response[0]->ClientID;

			$response = wp_remote_get('https://api.createsend.com/api/v3.1/clients/' . $ClientID . '/lists.json', $args);
			$get_lists = json_decode( wp_remote_retrieve_body( $response ) );


			$campaignmonitor_lists = array();
			foreach($get_lists as $list){
				if ( $list->ListID != '' && $list->Name != '' ) {
				   $campaignmonitor_lists[] = array( 'id'=> $list->ListID, 'name' => $list->Name );
				}
			}
			$campaignmonitor_settings = array(
										'campaignmonitor_enabled'	=> (isset($_POST['_ansh_optin_form_campaignmonitor'])) ? $_POST['_ansh_optin_form_campaignmonitor'] : '',
										'campaignmonitor_api_key' 	=> $_POST['_ansh_optin_form_campaignmonitor_api_key'],
										'ClientID' 					=> $ClientID,
										'campaignmonitor_lists'		=> $campaignmonitor_lists,
									);

			update_option( '_ansh_campaignmonitor_settings', $campaignmonitor_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['campaignmonitor'] = (isset($_POST['_ansh_optin_form_campaignmonitor'])) ? $_POST['_ansh_optin_form_campaignmonitor'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
		}

	}

	$campaignmonitor_settings = get_option( '_ansh_campaignmonitor_settings' );
	$campaignmonitor_settings['campaignmonitor_api_key'] = (isset($campaignmonitor_settings['campaignmonitor_api_key'])) ? $campaignmonitor_settings['campaignmonitor_api_key'] : '';

	$ClientID = isset($campaignmonitor_settings['ClientID']) ? $campaignmonitor_settings['ClientID'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-campaignmonitor-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-campaignmonitor-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-campaignmonitor-enabled" name="_ansh_optin_form_campaignmonitor" value="1" <?php checked( $campaignmonitor_settings['campaignmonitor_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-campaignmonitor-enabled">&nbsp; <?php esc_html_e( 'Enable CampaignMonitor', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-campaignmonitor-api-key">
							<?php esc_html_e( 'CampaignMonitor API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_campaignmonitor_api_key" id="optin-campaignmonitor-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($campaignmonitor_settings['campaignmonitor_api_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://help.campaignmonitor.com/api-keys" target="_blank">click Here</a> to find your CampaignMonitor API KEY.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'campaignmonitor-forms-settings' ); ?>
		</p>
	</form>


	<?php if ( isset($campaignmonitor_settings['campaignmonitor_enabled']) && $campaignmonitor_settings['campaignmonitor_enabled'] !='') : ?>
		<div class="campaignmonitor-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php
				if ( isset($campaignmonitor_settings['campaignmonitor_api_key']) && $campaignmonitor_settings['campaignmonitor_api_key'] !='') {

					$headers = array(
						'Authorization' => 'Basic ' . base64_encode($campaignmonitor_settings['campaignmonitor_api_key']),
						'Accept'		=> 'application/json',
					);
					$args = array(
						'method' 		=> 'GET',
						'timeout' 		=> 30,
						'blocking' 		=> true,
						'user-agent'  	=> 'WordPress/' . $wp_version . '; ' . home_url(),
						'headers'     	=> $headers,
						'cookies' 		=> array(),
						'sslverify'		=> true,
					);
					$response = wp_remote_get('https://api.createsend.com/api/v3.1/clients/' . $ClientID . '/lists.json', $args);
					$get_lists = json_decode( wp_remote_retrieve_body( $response ) );
					foreach($get_lists as $key=>$list){

						$response = wp_remote_get('https://api.createsend.com/api/v3.1/lists/' . $list->ListID . '/stats.json', $args);
						$get_list_stats = json_decode( wp_remote_retrieve_body( $response ) );						
						?>
						<tr>
							<td><?php echo esc_html($list->Name);?></td>
							<td><code><?php echo esc_html($list->ListID);?></code></td>
							<td><?php  echo esc_html($get_list_stats->TotalActiveSubscribers);?></td>
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}


/*
 * Subscribe CampaignMonitor Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_campaignmonitor_subscribe( $signup_data ) {

	$campaignmonitor_settings = get_option( '_ansh_campaignmonitor_settings' );
	$api_key = $campaignmonitor_settings['campaignmonitor_api_key'];
	$list_id = $signup_data['list_id'];

	$post_data = array(
			'EmailAddress'  => sanitize_email( $signup_data['email'] ),
			'Name'  		=> $signup_data['first_name']. ' ' . $signup_data['last_name'],			
		);
	
	$headers = array(
		'Authorization' => 'Basic ' . base64_encode($api_key),
		'Accept'		=> 'application/json',
		'Content-Type'	=> 'application/json',
	);
	$args = array(
		'method' 		=> 'POST',
		'timeout' 		=> 45,
		'redirection' 	=> 5,
		'httpversion' 	=> '1.0',
		'blocking' 		=> true,
		'user-agent'  	=> 'WordPress/' . $wp_version . '; ' . home_url(),
		'headers'     	=> $headers,
		'body'		  	=> wp_json_encode($post_data),
		'cookies' 		=> array(),
		'sslverify'		=> true,
	);
	$response = wp_remote_post('https://api.createsend.com/api/v3.1/subscribers/' . $list_id . '.json', $args );
	$api_response_body = json_decode( wp_remote_retrieve_body( $response ) );	
	
	if ( isset($api_response_body->Message) && $api_response_body->Message != '' ) {
		$response = array( 'error'	=> $api_response_body->Message );

	} else {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}
	return $response;
}