<?php

function ansh_optin_forms_hubspot_setting() {

	global $wp_version;
	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'hubspot-forms-settings' ) ) {
	
		if ( !isset($_POST['_ansh_optin_form_hubspot_crm']) ) {
			$hubspot_lists_url = add_query_arg( 'hapikey', $_POST['_ansh_optin_form_hubspot_api_key'], 'https://api.hubapi.com/contacts/v1/lists/static' );
			$max_lists = 1;
			$hubspot_lists_url = add_query_arg( 'count', $max_lists, $hubspot_lists_url );

			$response = wp_remote_get($hubspot_lists_url);
			$get_lists = json_decode( wp_remote_retrieve_body( $response ) );
		}

		if ( isset($get_lists->status) && $get_lists->status == 'error' ) {
			$error = "<strong>HubSpot: </strong>" . $get_lists->message;
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';

		} else {
			$hubspot_lists = array();
			if ( !isset($_POST['_ansh_optin_form_hubspot_crm']) ) {
				foreach($get_lists->lists as $list){
					if ( $list->listId != '' && $list->name != '' ) {
					   $hubspot_lists[] = array( 'id'=> $list->listId, 'name' => $list->name );
					}
				}
			}
			$hubspot_settings = array(
										'hubspot_enabled'	=> (isset($_POST['_ansh_optin_form_hubspot'])) ? $_POST['_ansh_optin_form_hubspot']: '',
										'hubspot_crm' 		=> (isset($_POST['_ansh_optin_form_hubspot_crm'])) ? $_POST['_ansh_optin_form_hubspot_crm'] : '',
										'hubspot_api_key' 	=> $_POST['_ansh_optin_form_hubspot_api_key'],
										'hubspot_lists'		=> $hubspot_lists,
									);

			update_option( '_ansh_hubspot_settings', $hubspot_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['hubspot'] = isset($_POST['_ansh_optin_form_hubspot']) ? $_POST['_ansh_optin_form_hubspot'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';

		}


	}
	$hubspot_settings = get_option( '_ansh_hubspot_settings' );
	$hubspot_settings['hubspot_crm'] = (isset($hubspot_settings['hubspot_crm'])) ? $hubspot_settings['hubspot_crm'] : '';
	$hubspot_settings['hubspot_api_key'] = (isset($hubspot_settings['hubspot_api_key'])) ? $hubspot_settings['hubspot_api_key'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-hubspot-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-hubspot-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-hubspot-enabled" name="_ansh_optin_form_hubspot" value="1" <?php checked( $hubspot_settings['hubspot_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-hubspot-enabled">&nbsp; <?php esc_html_e( 'Enable HubSpot', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-hubspot-crm"><?php esc_html_e( 'Use only HubSpot CRM', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-hubspot-crm" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-hubspot-crm" name="_ansh_optin_form_hubspot_crm" value="1" <?php checked( $hubspot_settings['hubspot_crm'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-hubspot-crm">&nbsp; <?php esc_html_e( 'Enable hubspot CRM', 'ansh-optin-forms' );?></label>
						<p class="description"><?php esc_html_e( 'All your subscribers will be added as contacts to your HubSpot CRM account if enable this option.', 'ansh-optin-forms' )?></p>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-hubspot-api-key">
							<?php esc_html_e( 'Hubspot API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_hubspot_api_key" id="optin-hubspot-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($hubspot_settings['hubspot_api_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://knowledge.hubspot.com/articles/kcs_article/integrations/how-do-i-get-my-hubspot-api-key" target="_blank">click Here</a> to find your Hubspot API KEY.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'hubspot-forms-settings' ); ?>
		</p>
	</form>
	
	<?php if ( isset($hubspot_settings['hubspot_enabled']) && $hubspot_settings['hubspot_enabled'] !='' && isset($hubspot_settings['hubspot_crm']) && $hubspot_settings['hubspot_crm'] == 1 ) : ?>
		<div class="hubspot-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($hubspot_settings['hubspot_api_key']) && $hubspot_settings['hubspot_api_key'] !='') {

					$hubspot_api_key = $hubspot_settings['hubspot_api_key'];
					
					$hubspot_lists_url = add_query_arg( 'hapikey', $hubspot_api_key, 'https://api.hubapi.com/contacts/v1/lists/static' );
					$max_lists = 200;
					$hubspot_lists_url = add_query_arg( 'count', $max_lists, $hubspot_lists_url );

					$response = wp_remote_get($hubspot_lists_url);
					$get_lists = json_decode( wp_remote_retrieve_body( $response ) );						
					foreach($get_lists->lists as $key=>$list){						
						?>
						<tr>
							<td><?php echo esc_html($list->name);?></td>
							<td><code><?php echo esc_html($list->listId);?></code></td>
							<td><?php  echo esc_html($list->metaData->size);?></td>
						</tr>
						<?php
					}
						
									
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}

/*
 * Subscribe HubSpot Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_hubspot_subscribe( $signup_data ) {

	$hubspot_settings = get_option( '_ansh_hubspot_settings' );
	$api_key = $hubspot_settings['hubspot_api_key'];
	$hubspot_crm = $hubspot_settings['hubspot_crm'];
	$list_id = $signup_data['list_id'];
	
	$hubspot_contact_url = add_query_arg( 'hapikey', $api_key, 'https://api.hubapi.com/contacts/v1/contact/createOrUpdate/email/'.$signup_data['email'] );

	$data = array(
		'properties' => array(
			array(
				'property' => 'email',
				'value'    => $signup_data['email'],
			),
			array(
				'property' => 'firstname',
				'value'    => $signup_data['first_name'],
			),
			array(
				'property' => 'lastname',
				'value'    => $signup_data['last_name'],
			),
		),
	);

	$args = array(
		'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
		'body'		  => wp_json_encode($data),

	);
	$api_response = wp_remote_post($hubspot_contact_url, $args);
	$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ) );	
	
	if ( $hubspot_crm == '' ) {		
		
		$url  = 'https://api.hubapi.com/contacts/v1/lists/' . $list_id . '/add';
		$url = add_query_arg( 'hapikey', $api_key, $url );
		
		$data = array(
			'vids'  => array($api_response_body->vid),
			'emails' => array( $signup_data['email'] ),
		);

		$headers = array(		
			'Accept' 		=> 'application/json',
			'Content-type'	=> 'application/json',				
		);
		$args = array(
			'method' 		=> 'POST',
			'user-agent'  	=> 'WordPress/' . $wp_version . '; ' . home_url(),				
			'headers'       => $headers,
			'body'		  	=> wp_json_encode($data),
			'sslverify'		=> true,
			
		); 
		$api_response = wp_remote_post($url, $args);
		$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ) );			
		
	}	

	if ( $api_response_body->status == 'error' && $api_response_body->message !='' ) {
		$response = array( 'error'	=> $api_response_body->message );
	} else {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}

	return $response;
}