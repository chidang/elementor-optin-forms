<?php
function ansh_optin_forms_aweber_setting() {	
	global $wp_version;	
	require_once plugin_dir_path(__FILE__) . 'aweber_api/aweber_api.php';
	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'aweber-forms-settings' ) ) {
		
		$oauth_id = $_POST['_ansh_optin_form_aweber_authorization_code'];
		
		try {
			list($consumer_key, $consumer_secret, $access_key, $access_secret) = AWeberAPI::getDataFromAweberID($oauth_id);
		} catch (AWeberAPIException $exc) {	
			list($consumer_key, $consumer_secret, $access_key, $access_secret) = null;		
			$descr = $exc->getMessage();
			$descr = preg_replace('/http.*$/i', '', $descr); # strip labs.aweber.com documentation url from error message
			
			$error = "<strong>AWeber: </strong> " . $descr;
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		}
		
		if ( $consumer_key != '' && $consumer_secret != '' && $access_key != '' && $access_secret !='' ) {
			try {		
				$aweber = new AWeberAPI($consumer_key, $consumer_secret);;
				$account = $aweber->getAccount($access_key, $access_secret);
			} catch (AWeberException $e) {
				$error_ = get_class($e);
				$account = null;
			}
		
			$get_lists = $account->lists;			
			$aweber_lists = array();
			foreach ($get_lists as $list){
				if ( $list->id != '' && $list->name != '' ) {
				   $aweber_lists[] = array( 'id'=> $list->id, 'name' => $list->name );
				}
			}
			
			
			if ( $consumer_key != '' && $consumer_secret != '' && $access_key != '' && $access_secret !='' ) {	
				$aweber_settings = array(
									'consumer_key' 				=> $consumer_key,
									'consumer_secret' 			=> $consumer_secret,
									'access_key' 				=> $access_key,
									'access_secret' 			=> $access_secret,
									'aweber_enabled'			=> (isset($_POST['_ansh_optin_form_aweber'])) ? $_POST['_ansh_optin_form_aweber'] : '',
									'aweber_authorization_code' => $oauth_id,
									'aweber_lists'				=> $aweber_lists,
									
								);
				
				update_option( '_ansh_aweber_settings', $aweber_settings);				
				
				$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
				$optin_enabled_forms['aweber'] = (isset($_POST['_ansh_optin_form_aweber'])) ? $_POST['_ansh_optin_form_aweber'] : '';
				update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );
				
				$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
				echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';
			}
		}
	}
	
	$aweber_settings = get_option( '_ansh_aweber_settings' );
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-aweber-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-aweber-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-aweber-enabled" name="_ansh_optin_form_aweber" value="1" <?php checked( $aweber_settings['aweber_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-aweber-enabled">&nbsp; <?php esc_html_e( 'Enable Aweber', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-aweber-authorization-code">
							<?php esc_html_e( 'AWeber Authorization Code', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_aweber_authorization_code" id="optin-aweber-authorization-code" class="input-text regular-input" placeholder="Authorization Code" value="<?php echo esc_attr($aweber_settings['aweber_authorization_code']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://auth.aweber.com/1.0/oauth/authorize_app/f49b1bcf" target="_blank">click Here</a> to find your AWeber Authorization Code.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'aweber-forms-settings' ); ?>
		</p>
	</form>
	
	
	<?php if ( isset($aweber_settings['aweber_enabled']) && $aweber_settings['aweber_enabled'] !='') : ?>
		<div class="aweber-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php
				if ( isset($aweber_settings['aweber_authorization_code']) && $aweber_settings['aweber_authorization_code'] !='') {
									
					$consumer_key 		= $aweber_settings['consumer_key'];
					$consumer_secret 	= $aweber_settings['consumer_secret'];
					$access_key 		= $aweber_settings['access_key'];
					$access_secret 		= $aweber_settings['access_secret'];
					try {
						
						$aweber = new AWeberAPI($consumer_key, $consumer_secret);;
						$account = $aweber->getAccount($access_key, $access_secret);						
						$get_lists = $account->lists;						
						if ( !empty($get_lists) ) :
							foreach($get_lists as $list) : ?>
								<tr>
									<td><?php echo esc_html($list->name);?></td>
									<td><code><?php echo esc_html($list->id);?></code></td>
									<td><?php echo esc_html($list->total_subscribers);?></td>
								</tr>
								<?php
							endforeach;
							
						endif;
						
					} catch (AWeberException $e ) {
						
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;	
	
}


/*
 * Subscribe AWeber Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_aweber_subscribe( $signup_data ) {
	
	$aweber_settings = get_option( '_ansh_aweber_settings' );	
	$list_id = $signup_data['list_id']; 
	$consumer_key 		= $aweber_settings['consumer_key'];
	$consumer_secret 	= $aweber_settings['consumer_secret'];
	$access_key 		= $aweber_settings['access_key'];
	$access_secret 		= $aweber_settings['access_secret'];
	
	require_once( ANSH_OPTIN_FORMS_PATH . 'includes/email_providers/aweber_api/aweber_api.php');	
	
	try {
		$ip = ( isset($_SERVER['X_FORWARDED_FOR'])) ? $_SERVER['X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
		
		$aweber = new AWeberAPI($consumer_key, $consumer_secret);
		$account = $aweber->getAccount($access_key, $access_secret);
		$subs = $account->loadFromUrl('/accounts/' . $account->id . '/lists/' . $list_id . '/subscribers');
		$sub = $subs->create(array(
								'email' 		=> $signup_data['email'],
								'ip_address' 	=> $ip,
								'name' 			=> $signup_data['first_name'] . " " . $signup_data['last_name'],
								'ad_tracking' 	=> get_bloginfo( 'name' ),
							));
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}
	catch (Exception $exc) {	
		#Authorization is invalid		
		$response = array( 'error'	=> str_replace( 'email: ','', $exc->message) );
	}
	
	return $response;
}