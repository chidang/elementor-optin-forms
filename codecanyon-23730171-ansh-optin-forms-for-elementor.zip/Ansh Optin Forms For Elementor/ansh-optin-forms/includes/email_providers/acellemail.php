<?php

function ansh_optin_forms_acellemail_setting() {
	global $wp_version;
	
	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'acellemail-forms-settings' ) ) {

		$headers = array();
		$body = array();
		$args = array(
			'method'	 => 'GET',	
			'user-agent' => 'WordPress/' . $wp_version . '; ' . home_url(),
			'headers'    => $headers,
			'body'    	 => $body,
		);

		$response = wp_remote_get( $_POST['_ansh_optin_form_acellemail_api_endpoint'] . '/lists?api_token=' . $_POST['_ansh_optin_form_acellemail_api_token'], $args);				
		$response = json_decode( wp_remote_retrieve_body( $response ) );	
		
		if ( is_wp_error( $response ) ) {
			$error_string = $response->get_error_message();
			echo '<div id="message" class="error inline"><p>' . $error_string . '</p></div>';
		} elseif ( !is_array($response) && trim($response) == '' ) {
			$error = "<strong>Acell Email: </strong> Please add correct API Endpoint & Token to access Acell Email.";
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		} elseif ( isset($response['status']) && $response['status'] == 'error' ) {
			$error = "<strong>Acell Email: </strong> " . $response['error'];
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		} else {

			$acellemail_lists = array();			
			foreach($response as $list){
				if ( $list->uid != '' && $list->name != '' ) {
				   $acellemail_lists[] = array( 'id'=> $list->uid, 'name' => $list->name );
				}
			}

			$acellemail_settings = array(
										'acellemail_enabled'	=> (isset($_POST['_ansh_optin_form_acellemail'])) ? $_POST['_ansh_optin_form_acellemail'] : '',
										'acellemail_api_endpoint' 	=> $_POST['_ansh_optin_form_acellemail_api_endpoint'],
										'acellemail_api_token' 		=> $_POST['_ansh_optin_form_acellemail_api_token'],			
										'acellemail_lists'			=> $acellemail_lists,
									);

			update_option( '_ansh_acellemail_settings', $acellemail_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['acellemail'] = (isset($_POST['_ansh_optin_form_acellemail'])) ? $_POST['_ansh_optin_form_acellemail'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';

		}
	}

	$acellemail_settings = get_option( '_ansh_acellemail_settings' );
	$acellemail_settings['acellemail_enabled'] = (isset($acellemail_settings['acellemail_enabled'])) ? $acellemail_settings['acellemail_enabled'] : '';
	$acellemail_settings['acellemail_api_url'] = (isset($acellemail_settings['acellemail_api_url'])) ? $acellemail_settings['acellemail_api_url'] : '';
	$acellemail_settings['acellemail_public_key'] = (isset($acellemail_settings['acellemail_public_key'])) ? $acellemail_settings['acellemail_public_key'] : '';
	$acellemail_settings['acellemail_private_key'] = (isset($acellemail_settings['acellemail_private_key'])) ? $acellemail_settings['acellemail_private_key'] : '';
	?>

	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-acellemail-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-acellemail-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-acellemail-enabled" name="_ansh_optin_form_acellemail" value="1" <?php checked( $acellemail_settings['acellemail_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-acellemail-enabled">&nbsp; <?php esc_html_e( 'Enable Acell Email', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-acellemail-api-endpoint"><?php esc_html_e( 'API Endpoint', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_acellemail_api_endpoint" id="ansh-optin-acellemail-api-endpoint" class="input-text regular-input" placeholder="API Endpoint" value="<?php echo esc_attr($acellemail_settings['acellemail_api_endpoint']);?>"/>
						<p class="description"><?php echo "your API Endpoint: e.g. http://< your-acellemail-url >/api/v1"; ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th><label for="ansh-optin-acellemail-api-token"><?php esc_html_e( 'API token', 'ansh-optin-forms' );?></label></th>
					<td>
						<input type="text" name="_ansh_optin_form_acellemail_api_token" id="ansh-optin-acellemail-api-token" class="input-text regular-input" placeholder="Your API token" value="<?php echo esc_attr($acellemail_settings['acellemail_api_token']);?>"/>
					</td>
				</tr>				
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://demo.acellemail.com/account/api" target="_blank">click Here</a> to find Acell Email API Endpoint & Token.'; ?></p>
		<p class="submit">
			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'acellemail-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($acellemail_settings['acellemail_enabled']) && $acellemail_settings['acellemail_enabled'] !='' ) : ?>
		<div class="acellemail-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($acellemail_settings['acellemail_api_token']) && $acellemail_settings['acellemail_api_token'] !='') {

					$headers = array();
					$body = array();
					$args = array(
						'method'	 => 'GET',	
						'user-agent' => 'WordPress/' . $wp_version . '; ' . home_url(),
						'headers'    => $headers,
						'body'    	 => $body,
					);

					$response = wp_remote_get( $acellemail_settings['acellemail_api_endpoint'] . '/lists?api_token=' . $acellemail_settings['acellemail_api_token'], $args);				
					$response = json_decode( wp_remote_retrieve_body( $response ) );
					foreach($response as $key=>$list){							
					
						$lists_response = wp_remote_get( $acellemail_settings['acellemail_api_endpoint'] . '/lists/' . $list->uid .'?api_token=' . $acellemail_settings['acellemail_api_token'], $args);				
						$lists_response = json_decode( wp_remote_retrieve_body( $lists_response ) );						
						?>
						<tr>
							<td><?php echo esc_html($list->name);?></td>
							<td><code><?php echo esc_html($list->uid);?></code></td>
							<td><?php  echo esc_html($lists_response->statistics->subscriber_count); ?></td>
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}

/*
 * Subscribe acellemail Email Provider
 *
 * @since 1.3
 */
function ansh_optin_forms_acellemail_subscribe( $signup_data ) {
	$acellemail_settings = get_option( '_ansh_acellemail_settings' );
	$acellemail_api_endpoint = $acellemail_settings['acellemail_api_endpoint'];
	$acellemail_api_token = $acellemail_settings['acellemail_api_token'];
	
	$list_id = $signup_data['list_id'];
	
	$headers = array();
	$body = array(
				'EMAIL' => $signup_data['email'],
				'FIRST_NAME' => $signup_data['first_name'],
				'LAST_NAME' => $signup_data['last_name'],
			);
	$args = array(
		'method'	 => 'POST',	
		'user-agent' => 'WordPress/' . $wp_version . '; ' . home_url(),
		'headers'    => $headers,
		'body'    	 => $body,
	);

	$api_response = wp_remote_get( $acellemail_api_endpoint . '/lists/' . $list_id . '/subscribers/store?api_token=' . $acellemail_api_token, $args);				
	$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ), true );	
	
	if ( isset($api_response_body['status']) && $api_response_body['status'] !='1' ) {
		$response = array( 'error'	=> esc_html__('Something went wrong adding subscriber', 'ansh-optin-forms') );
	}
	if ( isset($api_response_body['status']) && $api_response_body['status'] =='1' ) {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}
	
	return $response;
}
