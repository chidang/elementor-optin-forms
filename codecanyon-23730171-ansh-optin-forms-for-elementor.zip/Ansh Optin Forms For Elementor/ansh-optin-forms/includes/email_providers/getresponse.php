<?php

function ansh_optin_forms_getresponse_setting() {

	global $wp_version;
	require_once plugin_dir_path(__FILE__) . "GetResponse/jsonRPCClient.php";

	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'getresponse-forms-settings' ) ) {

		$api_url = 'http://api2.getresponse.com';
		# initialize JSON-RPC client
		$client = new jsonRPCClient($api_url);
		try{
			$get_lists = $client->get_campaigns( $_POST['_ansh_optin_form_getresponse_api_key'] );
			$getresponse_lists = array();
			foreach($get_lists as $key=>$list){
				if ( $key != '' && $list['name'] != '' ) {
				   $getresponse_lists[] = array( 'id'=> $key, 'name' => $list['name'] );
				}
			}
			$getresponse_settings = array(
										'getresponse_enabled'	=> (isset($_POST['_ansh_optin_form_getresponse'])) ? $_POST['_ansh_optin_form_getresponse'] : '',
										'getresponse_api_key' 	=> $_POST['_ansh_optin_form_getresponse_api_key'],
										'getresponse_lists'		=> $getresponse_lists,
									);

			update_option( '_ansh_getresponse_settings', $getresponse_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['getresponse'] = (isset($_POST['_ansh_optin_form_getresponse'])) ? $_POST['_ansh_optin_form_getresponse'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';

		} catch (Exception $e) {
			$error = "<strong>GetResponse: </strong> API key verification failed. Please enter correct API Key.";
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';
		}

	}
	$getresponse_settings = get_option( '_ansh_getresponse_settings' );
	$getresponse_settings['getresponse_api_key'] = (isset($getresponse_settings['getresponse_api_key'])) ? $getresponse_settings['getresponse_api_key'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-getresponse-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-getresponse-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-getresponse-enabled" name="_ansh_optin_form_getresponse" value="1" <?php checked( $getresponse_settings['getresponse_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-getresponse-enabled">&nbsp; <?php esc_html_e( 'Enable GetResponse', 'ansh-optin-forms' );?>
						</label>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-getresponse-api-key">
							<?php esc_html_e( 'GetResponse API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_getresponse_api_key" id="optin-getresponse-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($getresponse_settings['getresponse_api_key']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://support.getresponse.com/faq/where-i-find-api-key" target="_blank">click Here</a> to find your GetResponse API Key.'; ?></p>
		<p class="submit">

			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'getresponse-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($getresponse_settings['getresponse_enabled']) && $getresponse_settings['getresponse_enabled'] !=''): ?>
	<div class="getresponse-lists-overview">
		<table class="ansh_optin_form_tbl widefat">
			<thead>
				<tr>
					<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
					<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
					<!--td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td-->
				</tr>
			</thead>
			<tbody>
			<?php

			if ( isset($getresponse_settings['getresponse_api_key']) && $getresponse_settings['getresponse_api_key'] !='') {

				$getresponse_api_key = $getresponse_settings['getresponse_api_key'];

				$api_url = 'http://api2.getresponse.com';
				# initialize JSON-RPC client
				$client = new jsonRPCClient($api_url);
				try{
					$get_lists = $client->get_campaigns( $getresponse_api_key );
					foreach($get_lists as $key=>$list){
						?>
						<tr>
							<td><?php echo esc_html($list['name']);?></td>
							<td><code><?php echo esc_html($key);?></code></td>
							<!--td><?php /* echo esc_html($get_subscriptions->total_subscriptions) */;?></td-->
						</tr>
						<?php
					}

				} catch (Exception $e) {

				}
			}
			?>
			</tbody>
		</table>
	</div>
	<?php
	endif;
}

/*
 * Subscribe GetResponse Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_getresponse_subscribe ( $signup_data ) {

	require_once( ANSH_OPTIN_FORMS_PATH . 'includes/email_providers/GetResponse/jsonRPCClient.php');

	$getresponse_settings = get_option( '_ansh_getresponse_settings' );
	$api_key = $getresponse_settings['getresponse_api_key'];

	$api_url = 'http://api2.getresponse.com';
	$client = new jsonRPCClient($api_url);

	$list_id = $signup_data['list_id'];
	try {
		$result = $client->add_contact(
			$api_key,
			array(
				'campaign' 	=> $list_id,
				'name' 		=> $signup_data['first_name']. ' ' . $signup_data['last_name'],
				'email' 	=> $signup_data['email'],
			)
		);

		$response = array( 'message'  => esc_html__("Successfully Subscribed. Please check confirmation email.", 'ansh-optin-forms' ));

	} catch (Exception $e) {

		$response = array( 'error'     => $e->getMessage() );

	}
	return $response;
}