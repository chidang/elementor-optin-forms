<?php

function ansh_optin_forms_constantcontact_setting() {
	global $wp_version;
	if (  isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'constantcontact-forms-settings' ) ) {
		$constantcontact_access_token = $_POST['_ansh_optin_form_constantcontact_access_token'];
		$constantcontact_api_key = $_POST['_ansh_optin_form_constantcontact_api_key'];
		$args = array(
					'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
					'headers'     => array('Authorization' => 'Bearer ' . sanitize_text_field( $constantcontact_access_token ),),
				);

		$response = wp_remote_get('https://api.constantcontact.com/v2/lists?api_key='. $constantcontact_api_key, $args);
		$get_lists = json_decode( wp_remote_retrieve_body( $response ) );

		if ( isset($get_lists[0]->error_message) &&  $get_lists[0]->error_message !='' ) {
			$error = "<strong>Constant Contact: </strong>" . $get_lists[0]->error_message;
			echo '<div id="message" class="error inline"><p>' . $error . '</p></div>';

		} else {

			$constantcontact_lists = array();
			foreach($get_lists as $list){
				if ( $list->id != '' && $list->name != '' ) {
				   $constantcontact_lists[] = array( 'id'=> $list->id, 'name' => $list->name );
				}
			}
			$constantcontact_settings = array(
										'constantcontact_enabled'	=> (isset($_POST['_ansh_optin_form_constantcontact'])) ? $_POST['_ansh_optin_form_constantcontact'] : '',
										'constantcontact_access_token' 		=> $_POST['_ansh_optin_form_constantcontact_access_token'],
										'constantcontact_api_key' 	=> $_POST['_ansh_optin_form_constantcontact_api_key'],
										'constantcontact_lists'		=> $constantcontact_lists,
									);

			update_option( '_ansh_constantcontact_settings', $constantcontact_settings);

			$optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );
			$optin_enabled_forms['constantcontact'] = (isset($_POST['_ansh_optin_form_constantcontact'])) ? $_POST['_ansh_optin_form_constantcontact'] : '';
			update_option( '_ansh_optin_enabled_forms', $optin_enabled_forms );

			$message = esc_html__( 'Your settings have been saved.', 'ansh-optin-forms' );
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( $message ) . '</strong></p></div>';

		}
	}
	$constantcontact_settings = get_option( '_ansh_constantcontact_settings' );
	$constantcontact_settings['constantcontact_api_key'] = ( isset($constantcontact_settings['constantcontact_api_key'])) ? $constantcontact_settings['constantcontact_api_key'] : '';
	
	$constantcontact_settings['constantcontact_access_token'] = ( isset($constantcontact_settings['constantcontact_access_token'])) ? $constantcontact_settings['constantcontact_access_token'] : '';
	?>
	<form id="" action="" method="post">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th><label for="ansh-optin-constantcontact-enabled"><?php esc_html_e( 'Enable/Disable', 'ansh-optin-forms' );?></label></th>
					<td>
						<label for="ansh-optin-constantcontact-enabled" class="ansh-optin-switch">
							<input type="checkbox" id="ansh-optin-constantcontact-enabled" name="_ansh_optin_form_constantcontact" value="1" <?php checked( $constantcontact_settings['constantcontact_enabled'], '1' );?> />
							<span class="slider round"></span>
						</label>
						<label for="ansh-optin-constantcontact-enabled">&nbsp; <?php esc_html_e( 'Enable Constant Contact', 'ansh-optin-forms' );?></label>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-constantcontact-api-key">
							<?php esc_html_e( 'Constant Contact API Key', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_constantcontact_api_key" id="optin-constantcontact-api-key" class="input-text regular-input" placeholder="API Key" value="<?php echo esc_attr($constantcontact_settings['constantcontact_api_key']);?>"/>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="optin-constantcontact-access-token">
							<?php esc_html_e( 'Constant Contact Access Token', 'ansh-optin-forms' );?>
						</label>
					</th>
					<td>
						<input type="text" name="_ansh_optin_form_constantcontact_access_token"  id="optin-constantcontact-access-token" class="input-text regular-input" placeholder="Access Token" value="<?php echo esc_attr($constantcontact_settings['constantcontact_access_token']);?>"/>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="description"><?php echo '<a href="https://community.constantcontact.com/t5/Product-News/How-to-generate-an-API-Key-and-Access-Token/ba-p/293856" target="_blank">click Here</a> to find Constant Contact API Key & Access Token.'; ?></p>
		<p class="submit">

			<button name="save" class="button-primary optin-setting-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'ansh-optin-forms' ); ?>"><?php esc_html_e( 'Save changes', 'ansh-optin-forms' ); ?></button>
			<?php wp_nonce_field( 'constantcontact-forms-settings' ); ?>
		</p>
	</form>

	<?php if ( isset($constantcontact_settings['constantcontact_enabled']) && $constantcontact_settings['constantcontact_enabled'] !=''): ?>
		<div class="constantcontact-lists-overview">
			<table class="ansh_optin_form_tbl widefat">
				<thead>
					<tr>
						<td><?php esc_html_e( 'List Name', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'ID', 'ansh-optin-forms' );?></td>
						<td><?php esc_html_e( 'Subscribers', 'ansh-optin-forms' );?></td>
					</tr>
				</thead>
				<tbody>
				<?php

				if ( isset($constantcontact_settings['constantcontact_api_key']) && $constantcontact_settings['constantcontact_api_key'] !='') {
					$constantcontact_access_token = $constantcontact_settings['constantcontact_access_token'];
					$constantcontact_api_key = $constantcontact_settings['constantcontact_api_key'];
					$args = array(
								'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
								'headers'     => array('Authorization' => 'Bearer ' . sanitize_text_field( $constantcontact_access_token ),),
							);

					$response = wp_remote_get('https://api.constantcontact.com/v2/lists?api_key='. $constantcontact_api_key, $args);
					$get_lists = json_decode( wp_remote_retrieve_body( $response ) );
					foreach($get_lists as $list){
						?>
						<tr>
							<td><?php echo esc_html($list->name);?></td>
							<td><code><?php echo esc_html($list->id);?></code></td>
							<td><?php echo esc_html($list->contact_count);?></td>
						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>
	<?php
	endif;
}

/*
 * Subscribe Constant Contact Email Provider
 *
 * @since 1.0.0
 */
function ansh_optin_forms_constantcontact_subscribe ( $signup_data ) {



	$constantcontact_settings = get_option( '_ansh_constantcontact_settings' );

	$api_key = $constantcontact_settings['constantcontact_api_key'];
	$access_token = $constantcontact_settings['constantcontact_access_token'];
	$list_id = $signup_data['list_id'];

	$post_data = array(
						'lists' => array(array('id'=>$list_id)),
						'email_addresses'	=> array(array('email_address' => $signup_data['email'] ) ),
						'first_name' => $signup_data['first_name'],
						'last_name' => $signup_data['last_name'],
					);
	$args = array(
				'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
				'headers'     => array('Authorization' => 'Bearer ' . sanitize_text_field( $access_token ),'Content-Type'=> 'application/json'),
				'cookies'     => array(),
				'body'		=> wp_json_encode($post_data)

			);


	$api_response = wp_remote_post('https://api.constantcontact.com/v2/contacts?api_key='.$api_key, $args);
	$api_response_body = json_decode( wp_remote_retrieve_body( $api_response ) );

	if ( is_array($api_response_body) && isset($api_response_body[0]) && $api_response_body[0]->error_message != '') {
		$response = array( 'error'	=> $api_response_body[0]->error_message );
	} else {
		$response = array( 'message'  => esc_html__("Successfully Subscribed.", 'ansh-optin-forms' ));
	}

	return $response;
}