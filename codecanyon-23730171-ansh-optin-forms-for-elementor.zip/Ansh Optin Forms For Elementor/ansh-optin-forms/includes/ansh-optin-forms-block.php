<?php
/**
 * Ansh Optin Forms Block Class
 *
 * @since 1.6.0
 * @todo  - Add Block
 */

defined( 'ABSPATH' ) || exit;

/**
 * Ansh Optin Forms Block Class
 */
class Ansh_Optin_Forms_Block {

    /**
	 * Contruction
	 */
	public function __construct() {

        add_action( 'init', array( $this, 'ansh_block_editor_style_script' ) );

        add_action( 'enqueue_block_editor_assets', array($this, 'ansh_block_editor_scripts') );
    }


    function ansh_block_editor_scripts() {        
        wp_enqueue_style( 'ansh-optin-forms-css', ANSH_OPTIN_FORMS_URL . 'css/ansh-optin-forms.css');

        wp_enqueue_script( 'ansh-optin-forms-js', ANSH_OPTIN_FORMS_URL . 'js/ansh-optin-forms.js', array('jquery'), '', true );

        $locale_settings = [
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'elementor-pro-frontend' ),
            ];


        $locale_settings = apply_filters( 'ansh_optin_forms_localize_settings', $locale_settings );

        wp_localize_script(
            'ansh-optin-forms-js',
            'AnshOptinFormsConfig',
            $locale_settings
        );
    }

    /**
	 * Regester Block Scripts
	 *
	 * @return void
	 */
	public function ansh_block_editor_style_script() {
        wp_enqueue_style( 'ansh-block-fontawesome', ANSH_OPTIN_FORMS_URL.'css/font-awesome.css' );

        wp_register_script( 'ansh-block-script', plugin_dir_url( dirname( __FILE__ ) ) . 'build/index.js', array( 'jquery', 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-components', 'wp-data', 'wp-editor') );


        $active_email_provider = ansh_optin_forms_active_email_provider();
        $provider_lists = array();

        foreach ($active_email_provider as $key=>$value) {

            $email_provider_settings = get_option( '_ansh_' . $key . '_settings' );

            if( isset($email_provider_settings[ $key . '_lists']) && ! empty( $email_provider_settings[ $key . '_lists'] ) ) {
                
                $email_provider_lists = $email_provider_settings[ $key . '_lists'];
                
                foreach( $email_provider_lists as $email_provider_list ) {

                    $provider_lists[$key][] = array(
                            'label' => $email_provider_list['name'],
                            'value' => $email_provider_list['id'],
                        );
                }
            }
        }

        $locale_settings = array(
            'provider_lists' => $provider_lists,
            'optin_form_id' => uniqid('ansh_ontin_form_'),
            'ansh_ontin_form_nonce' => wp_create_nonce( 'ansh_ontin_form' ),
            'ansh_ontin_form_referer_field' => wp_unslash( $_SERVER['REQUEST_URI'] ),
        );

        wp_localize_script(
            'ansh-block-script',
            'AnshOptinFormsBlockConfig',
            $locale_settings
        );


        if ( function_exists( 'register_block_type' ) ) {
			register_block_type(
				'ansh/ansh-block',
				array(
					'attributes'    => $this->ansh_block_attribute(),
					'editor_script' => 'ansh-block-script',
				)
			);
        }        
    }

    /**
     * Block Attributes
     */
    public function ansh_block_attribute() {

        $fontawesome_icons = require_once ANSH_OPTIN_FORMS_PATH . 'includes/fontawesome-icon.php';

        $attribute = array(
            'optin_form_id' => array(
                'type' => 'string',
                'default' => '',
            ),
            'ansh_ontin_form_nonce' => array(
                'type' => 'string',
                'default' => '',
            ),
            'ansh_ontin_form_referer_field' => array(
                'type' => 'string',
                'default' => '',
            ),
            'optin_forms_layout_id' => array(
                'type' => 'string',
                'default' => 'ansh-optin-form-default',
            ),
            'form_title_tag_id' => array(
                'type' => 'string',
                'default' => 'h2',
            ),                
            'form_subtitle_tag_id' => array(
                'type' => 'string',
                'default' => 'h4',
            ),
            'text_alignment_id' => array(
                'type' => 'string',
                'default' => 'left',
            ),
            'optin_forms_layout' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__( 'Default', 'ansh-optin-forms' ),
                        'value' => 'ansh-optin-form-default',
                    ),
                    array(
                        'label' => esc_html__( 'Inline input box with button', 'ansh-optin-forms' ),
                        'value' => 'ansh-optin-form-inline',
                    ),
                    array(
                        'label' => esc_html__( 'Button inside input box', 'ansh-optin-forms' ),
                        'value' => 'ansh-optin-form-inline-inside-button',
                    ),
                )
            ),
            'form_title' => array(
                'type' => 'string',
                'default' => esc_html__( 'Type newslatter title here', 'ansh-optin-forms' ),
            ),
            'form_title_tag' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => 'H1',
                        'value' => 'h1',
                    ),
                    array(
                        'label' => 'H2',
                        'value' => 'h2',
                    ),
                    array(
                        'label' => 'H3',
                        'value' => 'h3',
                    ),
                    array(
                        'label' => 'H4',
                        'value' => 'h4',
                    ),                    
                    array(
                        'label' => 'H5',
                        'value' => 'h5',
                    ),                    
                    array(
                        'label' => 'H6',
                        'value' => 'h6',
                    ),
                    array(
                        'label' => 'DIV',
                        'value' => 'div',
                    ),                    
                    array(
                        'label' => 'SPAN',
                        'value' => 'span',
                    ),
                    array(
                        'label' => 'P',
                        'value' => 'p',
                    ),
                )
            ),
            'colors' => array(
                'type' => 'array',
                'default' => array(
                    array(
                        'name' => esc_html__( 'Black', 'ansh-optin-forms' ),
                        'slug' => 'black',
                        'color' => '#000000'
                    ),
                    array(
                        'name' => esc_html__( 'White', 'ansh-optin-forms' ),
                        'slug' => 'white',
                        'color' => '#ffffff'
                    ),
                    array(
                        'name' => esc_html__( 'Blue', 'ansh-optin-forms' ),
                        'slug' => 'blue',
                        'color' => '#0073aa'
                    ),
                ),
            ),
            'form_title_color' => array(
                'type' => 'string',
                'default' => 'black',
            ),
            
            'form_subtitle' => array(
                'type' => 'string',
                'default' => esc_html__( 'Type newslatter subtitle here', 'ansh-optin-forms' ),
            ),
            'form_subtitle_tag' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => 'H1',
                        'value' => 'h1',
                    ),
                    array(
                        'label' => 'H2',
                        'value' => 'h2',
                    ),
                    array(
                        'label' => 'H3',
                        'value' => 'h3',
                    ),
                    array(
                        'label' => 'H4',
                        'value' => 'h4',
                    ),                    
                    array(
                        'label' => 'H5',
                        'value' => 'h5',
                    ),                    
                    array(
                        'label' => 'H6',
                        'value' => 'h6',
                    ),
                    array(
                        'label' => 'DIV',
                        'value' => 'div',
                    ),                    
                    array(
                        'label' => 'SPAN',
                        'value' => 'span',
                    ),
                    array(
                        'label' => 'P',
                        'value' => 'p',
                    ),
                )
            ),
            'form_subtitle_color' => array(
                'type' => 'string',
                'default' => 'black',
            ),
            'form_description' => array(
                'type'  => 'string',
                'value' => ''
            ),
            'form_description_color' => array(
                'type' => 'string',
                'default' => 'black',
            ),
            'text_alignment' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__( 'Left', 'ansh-optin-forms' ),
                        'value' => 'left',
                    ),
                    array(
                        'label' => esc_html__( 'Center', 'ansh-optin-forms' ),
                        'value' => 'center',
                    ),
                    array(
                        'label' => esc_html__( 'Right', 'ansh-optin-forms' ),
                        'value' => 'right',
                    ),
                )
            ),
            'form_bg_type' => array(
                'type' => 'string',
                'default' => '',
            ),
            'form_bg_color' => array(
                'type' => 'string',
                'default' => '',
            ),
            'form_bg_media_id' => array(
                'type' => 'string',
                'default' => '',
            ),
            'form_bg_media_url' => array(
                'type' => 'string',
                'default' => '',
            ),
            'form_padding' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'form_border_type' => array(
                'type' => 'string',
                'default' => '',
            ),
            'form_border_color' => array(
                'type' => 'string',
                'default' => '',
            ),
            'form_border_radius' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'form_border_width' => array(
                'type' => 'string',
                'default' => 0,
            ),

            'newslatter_provider' => array(
                'type'    => 'array',
                'default' => $this->newslatter_provider_list()
            ),       
            'newslatter_provider_id' => array(
                'type' => 'string',
                'default' => '',
            ),
            'is_list_id' => array(
                'type' => 'boolean',
                'default' => false,
            ), 
            'email_text' => array(
                'type' => 'string',
                'default' => esc_html__( 'Enter your email', 'ansh-optin-forms' ),
            ),
            'display_first_name' => array(
                'type' => 'boolean',
                'default' => true,
            ),       
            'first_name_text' => array(
                'type' => 'string',
                'default' => esc_html__( 'Enter your first name.', 'ansh-optin-forms' ),
            ),
            'display_last_name' => array(
                'type' => 'boolean',
                'default' => true,
            ),
            'last_name_text' => array(
                'type' => 'string',
                'default' => esc_html__( 'Enter your last name.', 'ansh-optin-forms' ),
            ),    
            'input_text_alignment_id' => array(
                'type' => 'string',
                'default' => 'left',
            ),
            'input_text_alignment' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__( 'Left', 'ansh-optin-forms' ),
                        'value' => 'left',
                    ),
                    array(
                        'label' => esc_html__( 'Center', 'ansh-optin-forms' ),
                        'value' => 'center',
                    ),
                    array(
                        'label' => esc_html__( 'Right', 'ansh-optin-forms' ),
                        'value' => 'right',
                    ),
                )
            ),
            'input_text_color' => array(
                'type' => 'string',
                'default' => '',
            ),
            'input_text_bg_color' => array(
                'type' => 'string',
                'default' => '',
            ),
            'input_text_border_type' => array(
                'type' => 'string',
                'default' => '',
            ),
            'input_text_border_color' => array(
                'type' => 'string',
                'default' => '',
            ),
            'input_text_border_radius' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'input_text_border_width' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'input_text_height' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'input_text_width' => array(
                'type' => 'string',
                'default' => 0,
            ),

            'button_text' => array(
                'type' => 'string',
                'default' => esc_html__( 'SUBSCRIBE!', 'ansh-optin-forms' ),
            ),
            'show_button_icon' => array(
                'type' => 'boolean',
                'default' => true,
            ),
            'button_icon' => array(
                'type'    => 'array',
                'default' => $fontawesome_icons,
            ),
            'button_icon_id' => array(
                'type' => 'string',
                'default' => 'fa-star',
            ),
            'button_icon_position' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__('Before', 'ansh-optin-forms'),
                        'value' => 'left',
                    ),
                    array(
                        'label' => esc_html__('After', 'ansh-optin-forms'),
                        'value' => 'right',
                    ),
                )
            ),
            'button_icon_position_id' => array(
                'type' => 'string',
                'default' => 'right',
            ),
            'button_alignment_id' => array(
                'type' => 'string',
                'default' => 'left',
            ),
            'button_alignment' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__( 'Left', 'ansh-optin-forms' ),
                        'value' => 'left',
                    ),
                    array(
                        'label' => esc_html__( 'Center', 'ansh-optin-forms' ),
                        'value' => 'center',
                    ),
                    array(
                        'label' => esc_html__( 'Right', 'ansh-optin-forms' ),
                        'value' => 'right',
                    ),
                )
            ),
            'form_button_color' => array(
                'type' => 'string',
                'default' => 'white',
            ),
            'form_button_bg_color' => array(
                'type' => 'string',
                'default' => 'blue',
            ),
            'button_border_type' => array(
                'type' => 'string',
                'default' => '',
            ),
            'button_border_color' => array(
                'type' => 'string',
                'default' => '',
            ),
            'button_border_radius' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'button_border_width' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'button_height' => array(
                'type' => 'string',
                'default' => 0,
            ),
            'button_width' => array(
                'type' => 'string',
                'default' => 0,
            ),
            
            'optin_form_custom_message' => array(
                'type' => 'boolean',
                'default' => true,
            ),
            'optin_form_link' => array(
                'type' => 'string',
                'default' => '',
            ),
            'optin_form_success_message' => array(
                'type' => 'string',
                'default' => esc_html__( 'Successfully Subscribed. Please check confirmation email.', 'ansh-optin-forms' ),
            ),
            'optin_form_email_error_message' => array(
                'type' => 'string',
                'default' => esc_html__( 'Please, Enter your email address.', 'ansh-optin-forms'),
            ),
            'optin_form_first_name_error_message' => array(
                'type' => 'string',
                'default' => esc_html__( 'Please, Enter your first name.', 'ansh-optin-forms'),
            ),
            'optin_form_last_name_error_message' => array(
                'type' => 'string',
                'default' => esc_html__( 'Please, Enter your last name.', 'ansh-optin-forms'),
            ),
            'optin_form_email_provider_message' => array(
                'type' => 'string',
                'default' => esc_html__( 'Please, Select email service provider', 'ansh-optin-forms'),
            ),
            'optin_form_email_provider_list_message' => array(
                'type' => 'string',
                'default' => esc_html__( 'Please, Select email list id', 'ansh-optin-forms'),
            ),
            'is_provider_lists' => array(
                'type' => 'boolean',
                'default' => false,
            ),
            'provider_list_id_selected' => array(
                'type' => 'string',
                'default' => '',
            ),

            'border_type' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__( 'None', 'ansh-optin-forms' ),
                        'value' => '',
                    ),
                    array(
                        'label' => esc_html__( 'Solid', 'ansh-optin-forms' ),
                        'value' => 'solid',
                    ),
                    array(
                        'label' => esc_html__( 'Double', 'ansh-optin-forms' ),
                        'value' => 'double',
                    ),
                    array(
                        'label' => esc_html__( 'Dashed', 'ansh-optin-forms' ),
                        'value' => 'dashed',
                    ),
                    array(
                        'label' => esc_html__( 'Groove', 'ansh-optin-forms' ),
                        'value' => 'groove',
                    ),
                )
            ),
            'bg_type' => array(
                'type'    => 'array',
                'default' => array(
                    array(
                        'label' => esc_html__( 'None', 'ansh-optin-forms' ),
                        'value' => '',
                    ),
                    array(
                        'label' => esc_html__( 'Color', 'ansh-optin-forms' ),
                        'value' => 'color',
                    ),
                    array(
                        'label' => esc_html__( 'Inage', 'ansh-optin-forms' ),
                        'value' => 'image',
                    ),
                )
            ),
        );

        $active_email_provider = ansh_optin_forms_active_email_provider();

        foreach ($active_email_provider as $key=>$value) {

            $email_provider_settings = get_option( '_ansh_' . $key . '_settings' );

            if( isset($email_provider_settings[ $key . '_lists']) && ! empty( $email_provider_settings[ $key . '_lists'] ) ) {
                $attribute['is_provider_lists'] = array(
                    'type' => 'boolean',
                    'default' => true,
                );

                $email_provider_lists = $email_provider_settings[ $key . '_lists'];
                
                $attribute['_provider_lists'][$key][$key . '_list_id_selected'] = array(
                    'type' => 'string',
                    'default' => '',
                );

                $attribute['list_id_selected_'. $key] = array(
                    'type' => 'string',
                    'default' => '',
                );
                $attribute['list_id_'. $key]['type'] = 'array';

                foreach( $email_provider_lists as $email_provider_list ) {

                    $attribute['_provider_lists'][$key][$key . '_list_id'][] = array(
                            'label' => $email_provider_list['name'],
                            'value' => $email_provider_list['id'],
                        );
                        $attribute['list_id_'. $key]['default'][] = array(
                            'label' => $email_provider_list['name'],
                            'value' => $email_provider_list['id'],
                        );
                }
            }
        }
        return $attribute;

    }

    function newslatter_provider_list() {

        $newslatter_provider_list = array();

        $email_provider_lists = ansh_optin_form_provider_lists();
        $optin_enabled_forms = get_option( '_ansh_optin_enabled_forms' );

        $newslatter_provider_list[] = array(
            'label' => esc_html__('Store Local Database', 'ansh-optin-forms'),
            'value' => 'local_db',
        );

        foreach( $email_provider_lists as $key=>$value) {
            if ( isset($optin_enabled_forms[$key]) && $optin_enabled_forms[$key] == 1 ) {
                $newslatter_provider_list[] = array(
                    'label' => $value,
                    'value' => $key,
                );
            }
        }

        return $newslatter_provider_list;

    }

}

new Ansh_Optin_Forms_Block();