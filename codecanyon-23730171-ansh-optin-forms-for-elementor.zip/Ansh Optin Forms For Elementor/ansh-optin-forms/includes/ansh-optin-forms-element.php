<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class Ansh_Optin_Forms_Widget extends Widget_Base {
	public function get_name() {
		return 'ansh_optin_forms_widget';
	}

	public function get_title() {
		return esc_html__('Optin Forms', 'ansh-optin-forms' );
	}

	public function get_icon() {
		return 'eicon-mail';
	}

	public function get_categories() {
		return [ 'ansh-elementor-elements' ];
	}
	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'optin_forms_layout',
			[
				'label' 		=> esc_html__( 'Layout', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT,
				'options' 		=> [
									'ansh-optin-form-default' 				=> esc_html__( 'Default', 'ansh-optin-forms' ),
									'ansh-optin-form-inline' 				=> esc_html__( 'Inline input box with button', 'ansh-optin-forms' ),
									'ansh-optin-form-inline-inside-button'	=> esc_html__( 'Button inside input box', 'ansh-optin-forms' ),
								],
				'default' 		=> 'ansh-optin-form-default',
			]
		);
		$this->add_control(
			'title',
			[
				'label' 		=> esc_html__( 'Title', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'placeholder' 	=> esc_html__( 'Type your title here', 'ansh-optin-forms' ),
				'default' 		=> esc_html__( 'Type newslatter title here', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'			=> esc_html__( 'Title HTML Tag', 'ansh-optin-forms' ),
				'type'			=> \Elementor\Controls_Manager::SELECT,
				'default'		=> 'h2',
				'options'       => [
									'h1'    => 'H1',
									'h2'    => 'H2',
									'h3'    => 'H3',
									'h4'    => 'H4',
									'h5'    => 'H5',
									'h6'    => 'H6',
									'div'   => 'DIV',
									'span'  => 'span',
									'p'     => 'p',
								],
				'label_block'	=> false,
			]
		);

		$this->add_control(
			'sub-title',
			[
				'label' 		=> esc_html__( 'Sub Title', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'placeholder' 	=> esc_html__( 'Type your title here', 'ansh-optin-forms' ),
				'default' 		=> esc_html__( 'Type newslatter title here', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'sub_title_tag',
			[
				'label'			=> esc_html__( 'Sub Title HTML Tag', 'ansh-optin-forms' ),
				'type'			=> \Elementor\Controls_Manager::SELECT,
				'default'		=> 'h4',
				'options'       => [
									'h1'    => 'H1',
									'h2'    => 'H2',
									'h3'    => 'H3',
									'h4'    => 'H4',
									'h5'    => 'H5',
									'h6'    => 'H6',
									'div'   => 'DIV',
									'span'  => 'span',
									'p'     => 'p',
								],
				'label_block'	=> false,
			]
		);

		$this->add_control(
			'description',
			[
				'label' 		=> esc_html__( 'Description', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' 	=> esc_html__( 'Type your description here', 'ansh-optin-forms' ),
				'placeholder' 	=> esc_html__( 'Type your newslatter description here', 'ansh-optin-forms' ),
			]
		);

		$this->add_responsive_control(
			'text_alignment',
			[
				'label'         => esc_html__( 'Alignment', 'ansh-optin-forms' ),
				'type'          => \Elementor\Controls_Manager::CHOOSE,
				'options'       => [
									'left'	=> [
												'title'=> esc_html__( 'Left', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-left',
											],
									'center'=> [
												'title'=> esc_html__( 'Center', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-center',
											],
									'right' => [
												'title'=> esc_html__( 'Right', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-right',
											],
									],
				'default'       => 'left',
				'selectors'     => [
									'{{WRAPPER}} .ansh-optin-form-title, {{WRAPPER}} .ansh-optin-form-sub-title, {{WRAPPER}} .ansh-optin-form-description' => 'text-align: {{VALUE}};',
								],
			]
        );
		$this->end_controls_section();

		/* Form Integration */
		$this->start_controls_section(
			'section_form_integration',
			[
				'label' 		=> esc_html__( 'Form Integration', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'newslatter_provider',
			[
				'label' 		=> esc_html__( 'Select Email Provider', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT,
				'options' 		=> ansh_optin_forms_active_email_provider(),
				//'default' 		=> [ 'mailchimp'],
			]
		);

		$active_email_provider = ansh_optin_forms_active_email_provider();

		foreach ($active_email_provider as $key=>$value) {

			$email_provider_settings = get_option( '_ansh_' . $key . '_settings' );
			if ( !empty($email_provider_settings[ $key . '_lists']) ) {
				$this->add_control(
					$key . '_list_id',
					[
						'label' 		=> 'Select ' . $value. ' Email List',
						'type' 			=> \Elementor\Controls_Manager::SELECT,
						'label_block'	=> true,
						'condition'		=> [ 'newslatter_provider' => $key ],
						'options' 		=> ansh_optin_forms_email_provider_lists( $key ),
					]
				);
			}

		}

		$this->add_control(
			'form_integration_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'email_text',
			[
				'label' 		=> esc_html__( 'Email Text', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Enter your email.', 'ansh-optin-forms' ),
			]
		);
		$this->add_control(
			'form_first_name_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'display_first_name',
			[
				'label' 		=> esc_html__( 'Display First Name', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SWITCHER,
				'default' 		=> 'yes',
				'label_on' 		=> esc_html__( 'Show', 'ansh-optin-forms' ),
				'label_off' 	=> esc_html__( 'Hide', 'ansh-optin-forms' ),
			]
		);
		$this->add_control(
			'first_name_text',
			[
				'label' 		=> esc_html__( 'First Name Text', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Enter your first name.', 'ansh-optin-forms' ),
				'condition' 	=> [ 'display_first_name' => 'yes' ],
			]
		);
		$this->add_control(
			'form_last_name_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'display_last_name',
			[
				'label' 		=> esc_html__( 'Display Last Name', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SWITCHER,
				'default' 		=> 'yes',
				'label_on' 		=> esc_html__( 'Show', 'ansh-optin-forms' ),
				'label_off' 	=> esc_html__( 'Hide', 'ansh-optin-forms' ),
			]
		);
		$this->add_control(
			'last_name_text',
			[
				'label' 		=> esc_html__( 'Last Name Text', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Enter your last name.', 'ansh-optin-forms' ),
				'condition' 	=> [ 'display_last_name' => 'yes' ],
			]
		);

		$this->add_responsive_control(
			'input_text_alignment',
			[
				'label'         => esc_html__( 'Alignment', 'ansh-optin-forms' ),
				'type'          => \Elementor\Controls_Manager::CHOOSE,
				'options'       => [
									'left'	=> [
												'title'=> esc_html__( 'Left', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-left',
											],
									'center'=> [
												'title'=> esc_html__( 'Center', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-center',
											],
									'right' => [
												'title'=> esc_html__( 'Right', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-right',
											],
									],
				'default'       => 'left',
				'condition'		=>	[ 'optin_forms_layout' => 'ansh-optin-form-default' ],
				'selectors'     => [
									'{{WRAPPER}} .ansh_optin_form_input_wrap.ansh-optin-form-default .input-area' => 'text-align: {{VALUE}};',
								],
			]
        );

		$this->end_controls_section();

		/* Button Section */
		$this->start_controls_section(
			'optin_forms_button_section',
			[
				'label' => esc_html__( 'Button', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' 		=> esc_html__( 'Button Text', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'SUBSCRIBE!', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'show_button_icon',
			[
				'label' 		=> esc_html__( 'Show Icon', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'ansh-optin-forms' ),
				'label_off' 	=> esc_html__( 'Hide', 'ansh-optin-forms' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label' 		=> esc_html__( 'Icon', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::ICON,
				'default' 		=> 'fa fa-star',
				'condition'		=> [ 'show_button_icon' => 'yes' ]
			]
		);


		$this->add_control(
			'button_icon_position',
			[
				'label' 		=> esc_html__( 'Icon Position', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT,
				'default'		=> 'left',
				'options'       => [
									'left'	=> esc_html__('Before', 'ansh-optin-forms'),
									'right'   	=> esc_html__('After', 'ansh-optin-forms'),
								],
				'condition'		=>	[ 'show_button_icon' => 'yes'],
			]
		);
		$this->add_responsive_control(
			'button_icon_spacing',
			[
				'label' 		=> esc_html__( 'Icon Spacing', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'range' 		=> [
									'px' => [
										'max' => 50,
									],
								],
				'condition'		=>	[ 'show_button_icon' => 'yes'],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit .elementor-align-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit .elementor-align-icon-left' => 'margin-right: {{SIZE}}{{UNIT}};',
								],
			]
		);
		$this->add_responsive_control(
			'button_alignment',
			[
				'label'         => esc_html__( 'Alignment', 'ansh-optin-forms' ),
				'type'          => \Elementor\Controls_Manager::CHOOSE,
				'options'       => [
									'left'	=> [
												'title'=> esc_html__( 'Left', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-left',
											],
									'center'=> [
												'title'=> esc_html__( 'Center', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-center',
											],
									'right' => [
												'title'=> esc_html__( 'Right', 'ansh-optin-forms' ),
												'icon' => 'fa fa-align-right',
											],
									],
				'default'       => 'left',
				'condition'		=>	[ 'optin_forms_layout' => 'ansh-optin-form-default'],
				'selectors'     => [
									'{{WRAPPER}} .ansh_optin_form_input_wrap.ansh-optin-form-default .button-area' => 'text-align: {{VALUE}};',
								],
			]
        );
		$this->end_controls_section();
		/*  Optin Forms Button Section */

		/* Button Section */
		$this->start_controls_section(
			'optin_forms_additional_settings_section',
			[
				'label' => esc_html__( 'Additional Settings', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'optin_form_custom_message',
			[
				'label' 		=> esc_html__( 'Custom Success Messages', 'ansh-optin-forms' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> 'yes',
				'return_value' 	=> 'yes',
			]
		);
		$this->add_control(
			'optin_form_link',
			[
				'label' 		=> esc_html__( 'Redirect Link', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::URL,
				'placeholder' 	=> 'https://your-link.com',
				'show_external' => true,
				'default' 		=> [
									'url' => '',
									'is_external' => false,
									'nofollow' => false,
								],
				'condition' 	=> [
									'optin_form_custom_message' => '',
								],
			]
		);
		$this->add_control(
			'optin_form_success_message',
			[
				'label' 		=> __( 'Success Message', 'elementor-pro' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> 'Successfully Subscribed. Please check confirmation email.',
				'label_block' 	=> true,
				'condition' 	=> [
									'optin_form_custom_message!' => '',
								],
			]
		);
		$this->add_control(
			'optin_form_email_error_message',
			[
				'label' 		=> __( 'Email error message', 'elementor-pro' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Please, Enter your email address.', 'ansh-optin-forms'),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'optin_form_first_name_error_message',
			[
				'label' 		=> __( 'First name error message', 'elementor-pro' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Please, Enter your first name.', 'ansh-optin-forms'),
				'label_block' 	=> true,
				'condition' 	=> [ 'display_first_name' => 'yes' ],
			]
		);
		$this->add_control(
			'optin_form_last_name_error_message',
			[
				'label' 		=> __( 'Last name error message', 'elementor-pro' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Please, Enter your last name.', 'ansh-optin-forms'),
				'label_block' 	=> true,
				'condition' 	=> [ 'display_last_name' => 'yes' ],
			]
		);
		$this->add_control(
			'optin_form_email_provider_message',
			[
				'label' 		=> __( 'Email provider error message', 'elementor-pro' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Please, Select email service provider', 'ansh-optin-forms'),
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'optin_form_email_provider_list_message',
			[
				'label' 		=> __( 'Email list# error message', 'elementor-pro' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> esc_html__( 'Please, Select email list id', 'ansh-optin-forms'),
				'label_block' 	=> true,
			]
		);

		$this->end_controls_section();

		/* Optin Forms Style Design */
		$this->start_controls_section(
			'section_style_optin_forms_content',
			[
				'label' 		=> esc_html__( 'Content', 'ansh-optin-forms' ),
				'tab' 			=> \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		/* Title Style */
		$this->add_control(
			'title_color',
			[
				'label' 		=> esc_html__( 'Title Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'scheme' 		=> [
									'type' => Scheme_Color::get_type(),
									'value' => Scheme_Color::COLOR_1,
								],
				'selectors'		=> [
									'{{WRAPPER}} .ansh-optin-form-title' => 'color: {{VALUE}};',
								],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'title_typography',
				'scheme' 		=> Scheme_Typography::TYPOGRAPHY_1,
				'selector' 		=> '{{WRAPPER}} .ansh-optin-form-title',
			]
		);

		/* Sub Title Style */
		$this->add_control(
			'sub_title_color',
			[
				'label' 		=> esc_html__( 'Sub Title Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'scheme' 		=> [
									'type' => Scheme_Color::get_type(),
									'value' => Scheme_Color::COLOR_2,
								],
				'separator' 	=> 'before',
				'selectors'		=> [
									'{{WRAPPER}} .ansh-optin-form-sub-title' => 'color: {{VALUE}};',
								],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'sub_title_typography',
				'scheme' 		=> Scheme_Typography::TYPOGRAPHY_2,
				'selector' 		=> '{{WRAPPER}} .ansh-optin-form-sub-title',
			]
		);
		/* Description Style */
		$this->add_control(
			'description_color',
			[
				'label' 		=> esc_html__( 'Description Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'scheme' 		=> [
									'type' => Scheme_Color::get_type(),
									'value' => Scheme_Color::COLOR_3,
								],
				'separator' 	=> 'before',
				'selectors'		=> [
									'{{WRAPPER}} .ansh-optin-form-description' => 'color: {{VALUE}};',
								],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'description_typography',
				'scheme' 		=> Scheme_Typography::TYPOGRAPHY_3,
				'selector' 		=> '{{WRAPPER}} .ansh-optin-form-description',
			]
		);

		$this->end_controls_section();

		/* Optin Form Style */
		$this->start_controls_section(
			'section_style_optin_form',
			[
				'label' 		=> esc_html__( 'Optin Form', 'ansh-optin-forms' ),
				'tab'   		=> \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' 			=> 'optin_form_background',
				'label' 		=> esc_html__( 'Background', 'ansh-optin-forms' ),
				'types' 		=> [ 'classic', 'gradient', 'video' ],
				'selector' 		=> '{{WRAPPER}} .ansh-optin-form-wrapper .ansh-optin-forms',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'optin_form_border',
				'placeholder' 	=> '1px',
				'default'		=> '1px',
				'selector' 		=> '{{WRAPPER}} .ansh-optin-form-wrapper .ansh-optin-forms',
				'separator' 	=> 'before',
			]
		);

		$this->add_control(
			'optin_form_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-form-wrapper .ansh-optin-forms' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 			=> 'optin_form_shadow',
				'selector' 		=> '{{WRAPPER}} .ansh-optin-form-wrapper .ansh-optin-forms',
			]
		);
		$this->add_responsive_control(
			'optin_form_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', 'em', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-form-wrapper .ansh-optin-forms' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
				'separator' 	=> 'before',
			]
		);
		$this->add_responsive_control(
			'optin_form_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', 'em', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-form-wrapper .ansh-optin-forms' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
				'separator' 	=> 'before',
			]
		);

		$this->end_controls_section();


		/* Input Text Style */
		$this->start_controls_section(
			'section_style_optin_forms_input_text',
			[
				'label' 		=> esc_html__( 'Input Text', 'ansh-optin-forms' ),
				'tab' 			=> \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'optin_forms_input_text_Color',
			[
				'label' 		=> esc_html__( 'Input Text Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'default' 		=> '',
				'selectors' 	=> [
								'{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text, {{WRAPPER}} .ansh-optin-forms .input-area::after, {{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text::placeholder' => 'color: {{VALUE}};',
							],
			]
		);
		$this->add_control(
			'optin_forms_input_backgroud_color',
			[
				'label' 		=> esc_html__( 'Input Background Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'default' 		=> '',
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text' => 'background-color: {{VALUE}};',
								],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'optin_forms_input_text_typography',
				'scheme' 		=> Scheme_Typography::TYPOGRAPHY_3,
				'selector' 		=> '{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text',
			]
		);


		/* Input Border  */
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'optin_forms_input_border',
				'placeholder' 	=> '1px',
				'default' 		=> '1px',
				'selector' 		=> '{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text',
				'separator' 	=> 'before',
			]
		);
		/* Input Box radius*/
		$this->add_control(
			'optin_forms_input_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
			]
		);
		/*Input Box Shadow*/
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
                [
                    'label'         => esc_html__('Shadow','ansh-optin-forms'),
                    'name'          => 'business_item_shadow',
                    'selector'      => '{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text',
					'separator' 	=> 'before',
                ]
		);
		$this->add_responsive_control(
			'optin_forms_input_width',
			[
				'label' 		=> esc_html__( 'Width', 'ansh-optin-forms' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' 		=> [
									'px' => [
										'min' => 0,
										'max' => 1000,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text' => 'width: {{SIZE}}{{UNIT}};',
								],
				'condition'		=>	[ 'optin_forms_layout' => 'ansh-optin-form-default' ],
				'separator' 	=> 'before',
			]
		);
		$this->add_responsive_control(
			'optin_forms_input_height',
			[
				'label' 		=> esc_html__( 'Height', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', ],
				'range' 		=> [
									'px' => [
										'min' => 50,
										'max' => 100,
										'step' => 5,
									],
								],
				'default' 		=> [
									'unit' => 'px',
									'size' => 50,
								],
				'selectors' 	=> [
									'{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text' => 'height: {{SIZE}}{{UNIT}};',
									'{{WRAPPER}} .ansh-optin-forms .input-area::after' => 'line-height: {{SIZE}}{{UNIT}};',
								],
				'separator' 	=> 'before',
			]
		);

		/* Input Box Item Margin*/
        $this->add_responsive_control(
			'optin_forms_input_margin',
			[
				'label'         => esc_html__('Margin', 'ansh-optin-forms'),
				'type'          => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'    => ['px', 'em', '%'],
				'selectors'     => [
									'{{WRAPPER}} .ansh-optin-forms .input-area .ansh-optin-fom-input-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
								],
				'separator' 	=> 'before',
			]
		);

		$this->end_controls_section();
		/* End Input Text Style */

		/* Button Style */
		$this->start_controls_section(
			'section_style_optin_form_button',
			[
				'label' 		=> esc_html__( 'Button', 'ansh-optin-forms' ),
				'tab'   		=> \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'button_typography',
				'scheme' 		=> Scheme_Typography::TYPOGRAPHY_4,
				'selector' 		=> '{{WRAPPER}} .elementor-button.ansh-optin-form-submit',
			]
		);
		$this->start_controls_tabs( 'tabs_button_style' );
		/* Normal Button Style */
		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' 		=> esc_html__( 'Normal', 'ansh-optin-forms' ),
			]
		);
		$this->add_control(
			'button_text_color',
			[
				'label' 		=> esc_html__( 'Text Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'default' 		=> '',
				'selectors'		 => [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'color: {{VALUE}};',
								],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' 		=> esc_html__( 'Background Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'scheme' 		=> [
									'type' => Scheme_Color::get_type(),
									'value' => Scheme_Color::COLOR_4,
								],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'background-color: {{VALUE}};',
								],
			]
		);

		$this->end_controls_tab();
		/* Normal Button Style End */

		/* Hover Button Style Start */
		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => esc_html__( 'Hover', 'ansh-optin-forms' ),
			]
		);

		$this->add_control(
			'hover_color',
			[
				'label' 		=> esc_html__( 'Text Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit:hover' => 'color: {{VALUE}};',
								],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label' 		=> esc_html__( 'Background Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit:hover' => 'background-color: {{VALUE}};',
								],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' 		=> esc_html__( 'Border Color', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::COLOR,
				'condition' 	=> [
									'button_border_border!' => '',
								],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit:hover' => 'border-color: {{VALUE}};',
								],
			]
		);

		$this->add_control(
			'button_hover_animation',
			[
				'label' 		=> esc_html__( 'Hover Animation', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();
		/* Hover Button Style End*/

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 			=> 'button_border',
				'placeholder' 	=> '1px',
				'default'		=> '1px',
				'selector' 		=> '{{WRAPPER}} .elementor-button',
				'separator' 	=> 'before',
			]
		);

		$this->add_control(
			'button_border_radius',
			[
				'label' 		=> esc_html__( 'Border Radius', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 			=> 'button_box_shadow',
				'selector' 		=> '{{WRAPPER}} .elementor-button',
			]
		);

		$this->add_responsive_control(
			'buton_box_width',
			[
				'label' 		=> esc_html__( 'Width', 'ansh-optin-forms' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' 		=> [
									'px' => [
										'min' => 0,
										'max' => 1000,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'width: {{SIZE}}{{UNIT}};',
								],
				'condition'		=>	[ 'optin_forms_layout' => 'ansh-optin-form-default' ],
				'separator' 	=> 'before',
			]
		);
		$this->add_responsive_control(
			'buton_box_height',
			[
				'label' 		=> esc_html__( 'Height', 'ansh-optin-forms' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px', '%' ],
				'range' 		=> [
									'px' => [
										'min' => 0,
										'max' => 1000,
										'step' => 5,
									],
									'%' => [
										'min' => 0,
										'max' => 100,
									],
								],
				'default' 		=> [
									'unit' => 'px',
									'size' => 50,
								],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'height: {{SIZE}}{{UNIT}};',
								],
				'separator' 	=> 'before',
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> esc_html__( 'Padding', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', 'em', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
				'separator' 	=> 'before',
			]
		);
		$this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> esc_html__( 'Margin', 'ansh-optin-forms' ),
				'type' 			=> \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', 'em', '%' ],
				'selectors' 	=> [
									'{{WRAPPER}} .elementor-button.ansh-optin-form-submit' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
								],
				'separator' 	=> 'before',
			]
		);
		$this->end_controls_section();

		/* Style Section End */
	}
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'ansh-optin-form-wrapper', 'class', 'ansh-optin-form-wrapper' );

		$this->add_inline_editing_attributes( 'title');
		$this->add_render_attribute( 'title', 'class', 'ansh-optin-form-title' );

		$this->add_inline_editing_attributes( 'sub-title');
		$this->add_render_attribute( 'sub-title', 'class', 'ansh-optin-form-sub-title' );

		$this->add_inline_editing_attributes( 'description');
		$this->add_render_attribute( 'description', 'class', 'ansh-optin-form-description' );


		$button_hover_animation = '';
		if ( isset($settings['button_hover_animation']) && $settings['button_hover_animation'] ) {
			$button_hover_animation = 'elementor-animation-' . $settings['button_hover_animation'];
		}

		$optin_form_id    = uniqid('ansh_ontin_form_');
		$optin_form_id_nonce = uniqid('ansh_ontin_form_');

		$email_provider_list_id = '';
		if ( isset($settings['newslatter_provider']) && $settings['newslatter_provider'] != '' ) {
			$email_provider_list_id = $settings[ $settings['newslatter_provider'] . '_list_id'];
		}

		if ( ! empty( $settings['button_icon'] ) ) {
			$icon = $settings['button_icon'];
			$this->add_render_attribute( 'icon', 'class', $icon );
			$this->add_render_attribute( 'icon', 'aria-hidden', 'true' );
		}


		$optin_form_messages['optin_form_email_error_message'] = ( isset($settings['optin_form_email_error_message']) ) ? htmlentities($settings['optin_form_email_error_message']) : '';
		$optin_form_messages['optin_form_email_provider_message'] = ( isset($settings['optin_form_email_provider_message']) ) ? htmlentities($settings['optin_form_email_provider_message']) : '';
		$optin_form_messages['optin_form_email_provider_list_message'] = ( isset($settings['optin_form_email_provider_list_message']) ) ? htmlentities($settings['optin_form_email_provider_list_message']) : '';
		$optin_form_messages['optin_form_first_name_error_message'] = ( isset($settings['optin_form_first_name_error_message']) ) ? htmlentities($settings['optin_form_first_name_error_message']) : '';
		$optin_form_messages['optin_form_last_name_error_message'] = ( isset($settings['optin_form_last_name_error_message']) ) ? htmlentities($settings['optin_form_last_name_error_message']) : '';
		if ( isset($settings['optin_form_custom_message']) && $settings['optin_form_custom_message'] == 'yes' ) {
			$optin_form_messages['optin_form_success_message'] = ( isset($settings['optin_form_success_message']) ) ? htmlentities($settings['optin_form_success_message']) : '';
		} else {
			$optin_form_messages['optin_form_link'] = ( isset($settings['optin_form_link']) ) ? $settings['optin_form_link'] : '';
		}		
		$this->add_render_attribute( 'optin-form-messages', 'value', wp_json_encode( $optin_form_messages ) );
		?>
		<div <?php echo $this->get_render_attribute_string( 'ansh-optin-form-wrapper' ); ?> >
			<?php
			/* Optin Form Title */
			if ( $settings['title'] != '' ) {
				$title_tag = $settings['title_tag'];
				$title = $settings['title'];
				echo "<{$title_tag} " . $this->get_render_attribute_string( 'title' ) . "> {$title} </$title_tag>";
			}
			/* Optin Form Sub Title */
			if ( $settings['sub-title'] != '' ) {
				$sub_title_tag = $settings['sub_title_tag'];
				$sub_title = $settings['sub-title'];
				echo "<{$sub_title_tag} " . $this->get_render_attribute_string( 'sub-title' ) . "> {$sub_title}</$sub_title_tag>";
			}
			/* Optin Form Description */
			if ( $settings['description'] ) {
				echo "<p " . $this->get_render_attribute_string( 'description' ) . ">" . $settings['description'] . "</p>";
			}
			?>
			<div class="ansh-optin-forms">
				<form class="ansh-optin-form" id="<?php echo esc_attr($optin_form_id)?>" action="" method="post">
					<div class="hidden">
						<input type="hidden" class="ansh-email-provider" name="ansh_email_provider" value="<?php echo esc_attr($settings['newslatter_provider'])?>" />
						<input type="hidden" class="ansh-email-provider-list-id" name="ansh_email_provider_list_id" value="<?php echo esc_attr($email_provider_list_id)?>" />

						<input type="hidden" class="ansh-email-error-messages" name="ansh_email_error_message" <?php echo $this->get_render_attribute_string( 'optin-form-messages' ); ?> />
					</div>
					<div class="ansh_optin_form_input_wrap <?php echo esc_attr($settings['optin_forms_layout']);?>">

						<?php if ( isset($settings['display_first_name']) && $settings['display_first_name'] == 'yes') :?>
						<div class="input-area input-first-name">
							<input type="text" class="placeholder ansh-optin-fom-input-text ansh-optin-form-first-name" name="ansh_optin_form_first_name" placeholder="<?php echo esc_attr($settings['first_name_text']);?>" required>
						</div>
						<?php endif;?>

						<?php if ( isset($settings['display_last_name']) && $settings['display_last_name'] == 'yes' ) :?>
						<div class="input-area input-last-name">
							<input type="text" class="placeholder ansh-optin-fom-input-text ansh-optin-form-last-name" name="ansh_optin_form_last_name" placeholder="<?php echo esc_attr($settings['last_name_text']);?>" required>
						</div>
						<?php endif;?>
						<div class="input-area input-email">
							<input type="email" class="placeholder ansh-optin-fom-input-text ansh-optin-form-email" name="ansh_optin_form_email" placeholder="<?php echo esc_attr($settings['email_text']);?>" required >
						</div>

						<div class="button-area">
							<button class="btn btn-icon elementor-button submit ansh-optin-form-submit <?php echo esc_attr($button_hover_animation);?>" type="submit" data-form-id="<?php echo esc_attr($optin_form_id)?>" data-nonce-id="<?php echo esc_attr($optin_form_id_nonce);?>">
								<?php echo esc_html($settings['button_text']);?>

								<?php if ( $settings['show_button_icon'] == 'yes' ) : ?>
								<span class="elementor-button-icon elementor-align-icon-<?php echo esc_html($settings['button_icon_position']); ?>">
									<i <?php echo $this->get_render_attribute_string( 'icon' ); ?>></i>
								</span>
								<?php endif; ?>

								<span class="ansh-spinning-icon ansh-spining-<?php echo esc_attr($optin_form_id)?>"></span>
							</button>
						</div>
					</div>
					<p class="ansh-optin-form-msg"></p>
					<?php wp_nonce_field( 'ansh_ontin_form', 'ansh_ontin_form' ); ?>
				</form>
			</div>

		</div>

		<?php

	}

}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Ansh_Optin_Forms_Widget() );