<?php
/**
 * Fontawesome Icon array
 *
 * @since 1.6.0
 */

$fontawesome_icons = array(
    array(
        'value' => "fa-500px",
        'label' => "500px"
    ),
    array(
        'value' => "fa-address-book",
        'label' => "address-book"
    ),
    array(
        'value' => "fa-address-book-o",
        'label' => "address-book-o"
    ),
    array(
        'value' => "fa-address-card",
        'label' => "address-card"
    ),
    array(
        'value' => "fa-address-card-o",
        'label' => "address-card-o"
    ),
    array(
        'value' => "fa-adjust",
        'label' => "adjust"
    ),
    array(
        'value' => "fa-adn",
        'label' => "adn"
    ),
    array(
        'value' => "fa-align-center",
        'label' => "align-center"
    ),
    array(
        'value' => "fa-align-justify",
        'label' => "align-justify"
    ),
    array(
        'value' => "fa-align-left",
        'label' => "align-left"
    ),
    array(
        'value' => "fa-align-right",
        'label' => "align-right"
    ),
    array(
        'value' => "fa-amazon",
        'label' => "amazon"
    ),
    array(
        'value' => "fa-ambulance",
        'label' => "ambulance"
    ),
    array(
        'value' => "fa-american-sign-language-interpreting",
        'label' => "american-sign-language-interpreting"
    ),
    array(
        'value' => "fa-anchor",
        'label' => "anchor"
    ),
    array(
        'value' => "fa-android",
        'label' => "android"
    ),
    array(
        'value' => "fa-angellist",
        'label' => "angellist"
    ),
    array(
        'value' => "fa-angle-double-down",
        'label' => "angle-double-down"
    ),
    array(
        'value' => "fa-angle-double-left",
        'label' => "angle-double-left"
    ),
    array(
        'value' => "fa-angle-double-right",
        'label' => "angle-double-right"
    ),
    array(
        'value' => "fa-angle-double-up",
        'label' => "angle-double-up"
    ),
    array(
        'value' => "fa-angle-down",
        'label' => "angle-down"
    ),
    array(
        'value' => "fa-angle-left",
        'label' => "angle-left"
    ),
    array(
        'value' => "fa-angle-right",
        'label' => "angle-right"
    ),
    array(
        'value' => "fa-angle-up",
        'label' => "angle-up"
    ),
    array(
        'value' => "fa-apple",
        'label' => "apple"
    ),
    array(
        'value' => "fa-archive",
        'label' => "archive"
    ),
    array(
        'value' => "fa-area-chart",
        'label' => "area-chart"
    ),
    array(
        'value' => "fa-arrow-circle-down",
        'label' => "arrow-circle-down"
    ),
    array(
        'value' => "fa-arrow-circle-left",
        'label' => "arrow-circle-left"
    ),
    array(
        'value' => "fa-arrow-circle-o-down",
        'label' => "arrow-circle-o-down"
    ),
    array(
        'value' => "fa-arrow-circle-o-left",
        'label' => "arrow-circle-o-left"
    ),
    array(
        'value' => "fa-arrow-circle-o-right",
        'label' => "arrow-circle-o-right"
    ),
    array(
        'value' => "fa-arrow-circle-o-up",
        'label' => "arrow-circle-o-up"
    ),
    array(
        'value' => "fa-arrow-circle-right",
        'label' => "arrow-circle-right"
    ),
    array(
        'value' => "fa-arrow-circle-up",
        'label' => "arrow-circle-up"
    ),
    array(
        'value' => "fa-arrow-down",
        'label' => "arrow-down"
    ),
    array(
        'value' => "fa-arrow-left",
        'label' => "arrow-left"
    ),
    array(
        'value' => "fa-arrow-right",
        'label' => "arrow-right"
    ),
    array(
        'value' => "fa-arrow-up",
        'label' => "arrow-up"
    ),
    array(
        'value' => "fa-arrows",
        'label' => "arrows"
    ),
    array(
        'value' => "fa-arrows-alt",
        'label' => "arrows-alt"
    ),
    array(
        'value' => "fa-arrows-h",
        'label' => "arrows-h"
    ),
    array(
        'value' => "fa-arrows-v",
        'label' => "arrows-v"
    ),
    array(
        'value' => "fa-asl-interpreting",
        'label' => "asl-interpreting"
    ),
    array(
        'value' => "fa-assistive-listening-systems",
        'label' => "assistive-listening-systems"
    ),
    array(
        'value' => "fa-asterisk",
        'label' => "asterisk"
    ),
    array(
        'value' => "fa-at",
        'label' => "at"
    ),
    array(
        'value' => "fa-audio-description",
        'label' => "audio-description"
    ),
    array(
        'value' => "fa-automobile",
        'label' => "automobile"
    ),
    array(
        'value' => "fa-backward",
        'label' => "backward"
    ),
    array(
        'value' => "fa-balance-scale",
        'label' => "balance-scale"
    ),
    array(
        'value' => "fa-ban",
        'label' => "ban"
    ),
    array(
        'value' => "fa-bandcamp",
        'label' => "bandcamp"
    ),
    array(
        'value' => "fa-bank",
        'label' => "bank"
    ),
    array(
        'value' => "fa-bar-chart",
        'label' => "bar-chart"
    ),
    array(
        'value' => "fa-bar-chart-o",
        'label' => "bar-chart-o"
    ),
    array(
        'value' => "fa-barcode",
        'label' => "barcode"
    ),
    array(
        'value' => "fa-bars",
        'label' => "bars"
    ),
    array(
        'value' => "fa-bath",
        'label' => "bath"
    ),
    array(
        'value' => "fa-bathtub",
        'label' => "bathtub"
    ),
    array(
        'value' => "fa-battery",
        'label' => "battery"
    ),
    array(
        'value' => "fa-battery-0",
        'label' => "battery-0"
    ),
    array(
        'value' => "fa-battery-1",
        'label' => "battery-1"
    ),
    array(
        'value' => "fa-battery-2",
        'label' => "battery-2"
    ),
    array(
        'value' => "fa-battery-3",
        'label' => "battery-3"
    ),
    array(
        'value' => "fa-battery-4",
        'label' => "battery-4"
    ),
    array(
        'value' => "fa-battery-empty",
        'label' => "battery-empty"
    ),
    array(
        'value' => "fa-battery-full",
        'label' => "battery-full"
    ),
    array(
        'value' => "fa-battery-half",
        'label' => "battery-half"
    ),
    array(
        'value' => "fa-battery-quarter",
        'label' => "battery-quarter"
    ),
    array(
        'value' => "fa-battery-three-quarters",
        'label' => "battery-three-quarters"
    ),
    array(
        'value' => "fa-bed",
        'label' => "bed"
    ),
    array(
        'value' => "fa-beer",
        'label' => "beer"
    ),
    array(
        'value' => "fa-behance",
        'label' => "behance"
    ),
    array(
        'value' => "fa-behance-square",
        'label' => "behance-square"
    ),
    array(
        'value' => "fa-bell",
        'label' => "bell"
    ),
    array(
        'value' => "fa-bell-o",
        'label' => "bell-o"
    ),
    array(
        'value' => "fa-bell-slash",
        'label' => "bell-slash"
    ),
    array(
        'value' => "fa-bell-slash-o",
        'label' => "bell-slash-o"
    ),
    array(
        'value' => "fa-bicycle",
        'label' => "bicycle"
    ),
    array(
        'value' => "fa-binoculars",
        'label' => "binoculars"
    ),
    array(
        'value' => "fa-birthday-cake",
        'label' => "birthday-cake"
    ),
    array(
        'value' => "fa-bitbucket",
        'label' => "bitbucket"
    ),
    array(
        'value' => "fa-bitbucket-square",
        'label' => "bitbucket-square"
    ),
    array(
        'value' => "fa-bitcoin",
        'label' => "bitcoin"
    ),
    array(
        'value' => "fa-black-tie",
        'label' => "black-tie"
    ),
    array(
        'value' => "fa-blind",
        'label' => "blind"
    ),
    array(
        'value' => "fa-bluetooth",
        'label' => "bluetooth"
    ),
    array(
        'value' => "fa-bluetooth-b",
        'label' => "bluetooth-b"
    ),
    array(
        'value' => "fa-bold",
        'label' => "bold"
    ),
    array(
        'value' => "fa-bolt",
        'label' => "bolt"
    ),
    array(
        'value' => "fa-bomb",
        'label' => "bomb"
    ),
    array(
        'value' => "fa-book",
        'label' => "book"
    ),
    array(
        'value' => "fa-bookmark",
        'label' => "bookmark"
    ),
    array(
        'value' => "fa-bookmark-o",
        'label' => "bookmark-o"
    ),
    array(
        'value' => "fa-braille",
        'label' => "braille"
    ),
    array(
        'value' => "fa-briefcase",
        'label' => "briefcase"
    ),
    array(
        'value' => "fa-btc",
        'label' => "btc"
    ),
    array(
        'value' => "fa-bug",
        'label' => "bug"
    ),
    array(
        'value' => "fa-building",
        'label' => "building"
    ),
    array(
        'value' => "fa-building-o",
        'label' => "building-o"
    ),
    array(
        'value' => "fa-bullhorn",
        'label' => "bullhorn"
    ),
    array(
        'value' => "fa-bullseye",
        'label' => "bullseye"
    ),
    array(
        'value' => "fa-bus",
        'label' => "bus"
    ),
    array(
        'value' => "fa-buysellads",
        'label' => "buysellads"
    ),
    array(
        'value' => "fa-cab",
        'label' => "cab"
    ),
    array(
        'value' => "fa-calculator",
        'label' => "calculator"
    ),
    array(
        'value' => "fa-calendar",
        'label' => "calendar"
    ),
    array(
        'value' => "fa-calendar-check-o",
        'label' => "calendar-check-o"
    ),
    array(
        'value' => "fa-calendar-minus-o",
        'label' => "calendar-minus-o"
    ),
    array(
        'value' => "fa-calendar-o",
        'label' => "calendar-o"
    ),
    array(
        'value' => "fa-calendar-plus-o",
        'label' => "calendar-plus-o"
    ),
    array(
        'value' => "fa-calendar-times-o",
        'label' => "calendar-times-o"
    ),
    array(
        'value' => "fa-camera",
        'label' => "camera"
    ),
    array(
        'value' => "fa-camera-retro",
        'label' => "camera-retro"
    ),
    array(
        'value' => "fa-car",
        'label' => "car"
    ),
    array(
        'value' => "fa-caret-down",
        'label' => "caret-down"
    ),
    array(
        'value' => "fa-caret-left",
        'label' => "caret-left"
    ),
    array(
        'value' => "fa-caret-right",
        'label' => "caret-right"
    ),
    array(
        'value' => "fa-caret-square-o-down",
        'label' => "caret-square-o-down"
    ),
    array(
        'value' => "fa-caret-square-o-left",
        'label' => "caret-square-o-left"
    ),
    array(
        'value' => "fa-caret-square-o-right",
        'label' => "caret-square-o-right"
    ),
    array(
        'value' => "fa-caret-square-o-up",
        'label' => "caret-square-o-up"
    ),
    array(
        'value' => "fa-caret-up",
        'label' => "caret-up"
    ),
    array(
        'value' => "fa-cart-arrow-down",
        'label' => "cart-arrow-down"
    ),
    array(
        'value' => "fa-cart-plus",
        'label' => "cart-plus"
    ),
    array(
        'value' => "fa-cc",
        'label' => "cc"
    ),
    array(
        'value' => "fa-cc-amex",
        'label' => "cc-amex"
    ),
    array(
        'value' => "fa-cc-diners-club",
        'label' => "cc-diners-club"
    ),
    array(
        'value' => "fa-cc-discover",
        'label' => "cc-discover"
    ),
    array(
        'value' => "fa-cc-jcb",
        'label' => "cc-jcb"
    ),
    array(
        'value' => "fa-cc-mastercard",
        'label' => "cc-mastercard"
    ),
    array(
        'value' => "fa-cc-paypal",
        'label' => "cc-paypal"
    ),
    array(
        'value' => "fa-cc-stripe",
        'label' => "cc-stripe"
    ),
    array(
        'value' => "fa-cc-visa",
        'label' => "cc-visa"
    ),
    array(
        'value' => "fa-certificate",
        'label' => "certificate"
    ),
    array(
        'value' => "fa-chain",
        'label' => "chain"
    ),
    array(
        'value' => "fa-chain-broken",
        'label' => "chain-broken"
    ),
    array(
        'value' => "fa-check",
        'label' => "check"
    ),
    array(
        'value' => "fa-check-circle",
        'label' => "check-circle"
    ),
    array(
        'value' => "fa-check-circle-o",
        'label' => "check-circle-o"
    ),
    array(
        'value' => "fa-check-square",
        'label' => "check-square"
    ),
    array(
        'value' => "fa-check-square-o",
        'label' => "check-square-o"
    ),
    array(
        'value' => "fa-chevron-circle-down",
        'label' => "chevron-circle-down"
    ),
    array(
        'value' => "fa-chevron-circle-left",
        'label' => "chevron-circle-left"
    ),
    array(
        'value' => "fa-chevron-circle-right",
        'label' => "chevron-circle-right"
    ),
    array(
        'value' => "fa-chevron-circle-up",
        'label' => "chevron-circle-up"
    ),
    array(
        'value' => "fa-chevron-down",
        'label' => "chevron-down"
    ),
    array(
        'value' => "fa-chevron-left",
        'label' => "chevron-left"
    ),
    array(
        'value' => "fa-chevron-right",
        'label' => "chevron-right"
    ),
    array(
        'value' => "fa-chevron-up",
        'label' => "chevron-up"
    ),
    array(
        'value' => "fa-child",
        'label' => "child"
    ),
    array(
        'value' => "fa-chrome",
        'label' => "chrome"
    ),
    array(
        'value' => "fa-circle",
        'label' => "circle"
    ),
    array(
        'value' => "fa-circle-o",
        'label' => "circle-o"
    ),
    array(
        'value' => "fa-circle-o-notch",
        'label' => "circle-o-notch"
    ),
    array(
        'value' => "fa-circle-thin",
        'label' => "circle-thin"
    ),
    array(
        'value' => "fa-clipboard",
        'label' => "clipboard"
    ),
    array(
        'value' => "fa-clock-o",
        'label' => "clock-o"
    ),
    array(
        'value' => "fa-clone",
        'label' => "clone"
    ),
    array(
        'value' => "fa-close",
        'label' => "close"
    ),
    array(
        'value' => "fa-cloud",
        'label' => "cloud"
    ),
    array(
        'value' => "fa-cloud-download",
        'label' => "cloud-download"
    ),
    array(
        'value' => "fa-cloud-upload",
        'label' => "cloud-upload"
    ),
    array(
        'value' => "fa-cny",
        'label' => "cny"
    ),
    array(
        'value' => "fa-code",
        'label' => "code"
    ),
    array(
        'value' => "fa-code-fork",
        'label' => "code-fork"
    ),
    array(
        'value' => "fa-codepen",
        'label' => "codepen"
    ),
    array(
        'value' => "fa-codiepie",
        'label' => "codiepie"
    ),
    array(
        'value' => "fa-coffee",
        'label' => "coffee"
    ),
    array(
        'value' => "fa-cog",
        'label' => "cog"
    ),
    array(
        'value' => "fa-cogs",
        'label' => "cogs"
    ),
    array(
        'value' => "fa-columns",
        'label' => "columns"
    ),
    array(
        'value' => "fa-comment",
        'label' => "comment"
    ),
    array(
        'value' => "fa-comment-o",
        'label' => "comment-o"
    ),
    array(
        'value' => "fa-commenting",
        'label' => "commenting"
    ),
    array(
        'value' => "fa-commenting-o",
        'label' => "commenting-o"
    ),
    array(
        'value' => "fa-comments",
        'label' => "comments"
    ),
    array(
        'value' => "fa-comments-o",
        'label' => "comments-o"
    ),
    array(
        'value' => "fa-compass",
        'label' => "compass"
    ),
    array(
        'value' => "fa-compress",
        'label' => "compress"
    ),
    array(
        'value' => "fa-connectdevelop",
        'label' => "connectdevelop"
    ),
    array(
        'value' => "fa-contao",
        'label' => "contao"
    ),
    array(
        'value' => "fa-copy",
        'label' => "copy"
    ),
    array(
        'value' => "fa-copyright",
        'label' => "copyright"
    ),
    array(
        'value' => "fa-creative-commons",
        'label' => "creative-commons"
    ),
    array(
        'value' => "fa-credit-card",
        'label' => "credit-card"
    ),
    array(
        'value' => "fa-credit-card-alt",
        'label' => "credit-card-alt"
    ),
    array(
        'value' => "fa-crop",
        'label' => "crop"
    ),
    array(
        'value' => "fa-crosshairs",
        'label' => "crosshairs"
    ),
    array(
        'value' => "fa-css3",
        'label' => "css3"
    ),
    array(
        'value' => "fa-cube",
        'label' => "cube"
    ),
    array(
        'value' => "fa-cubes",
        'label' => "cubes"
    ),
    array(
        'value' => "fa-cut",
        'label' => "cut"
    ),
    array(
        'value' => "fa-cutlery",
        'label' => "cutlery"
    ),
    array(
        'value' => "fa-dashboard",
        'label' => "dashboard"
    ),
    array(
        'value' => "fa-dashcube",
        'label' => "dashcube"
    ),
    array(
        'value' => "fa-database",
        'label' => "database"
    ),
    array(
        'value' => "fa-deaf",
        'label' => "deaf"
    ),
    array(
        'value' => "fa-deafness",
        'label' => "deafness"
    ),
    array(
        'value' => "fa-dedent",
        'label' => "dedent"
    ),
    array(
        'value' => "fa-delicious",
        'label' => "delicious"
    ),
    array(
        'value' => "fa-desktop",
        'label' => "desktop"
    ),
    array(
        'value' => "fa-deviantart",
        'label' => "deviantart"
    ),
    array(
        'value' => "fa-diamond",
        'label' => "diamond"
    ),
    array(
        'value' => "fa-digg",
        'label' => "digg"
    ),
    array(
        'value' => "fa-dollar",
        'label' => "dollar"
    ),
    array(
        'value' => "fa-dot-circle-o",
        'label' => "dot-circle-o"
    ),
    array(
        'value' => "fa-download",
        'label' => "download"
    ),
    array(
        'value' => "fa-dribbble",
        'label' => "dribbble"
    ),
    array(
        'value' => "fa-drivers-license",
        'label' => "drivers-license"
    ),
    array(
        'value' => "fa-drivers-license-o",
        'label' => "drivers-license-o"
    ),
    array(
        'value' => "fa-dropbox",
        'label' => "dropbox"
    ),
    array(
        'value' => "fa-drupal",
        'label' => "drupal"
    ),
    array(
        'value' => "fa-edge",
        'label' => "edge"
    ),
    array(
        'value' => "fa-edit",
        'label' => "edit"
    ),
    array(
        'value' => "fa-eercast",
        'label' => "eercast"
    ),
    array(
        'value' => "fa-eject",
        'label' => "eject"
    ),
    array(
        'value' => "fa-ellipsis-h",
        'label' => "ellipsis-h"
    ),
    array(
        'value' => "fa-ellipsis-v",
        'label' => "ellipsis-v"
    ),
    array(
        'value' => "fa-empire",
        'label' => "empire"
    ),
    array(
        'value' => "fa-envelope",
        'label' => "envelope"
    ),
    array(
        'value' => "fa-envelope-o",
        'label' => "envelope-o"
    ),
    array(
        'value' => "fa-envelope-open",
        'label' => "envelope-open"
    ),
    array(
        'value' => "fa-envelope-open-o",
        'label' => "envelope-open-o"
    ),
    array(
        'value' => "fa-envelope-square",
        'label' => "envelope-square"
    ),
    array(
        'value' => "fa-envira",
        'label' => "envira"
    ),
    array(
        'value' => "fa-eraser",
        'label' => "eraser"
    ),
    array(
        'value' => "fa-etsy",
        'label' => "etsy"
    ),
    array(
        'value' => "fa-eur",
        'label' => "eur"
    ),
    array(
        'value' => "fa-euro",
        'label' => "euro"
    ),
    array(
        'value' => "fa-exchange",
        'label' => "exchange"
    ),
    array(
        'value' => "fa-exclamation",
        'label' => "exclamation"
    ),
    array(
        'value' => "fa-exclamation-circle",
        'label' => "exclamation-circle"
    ),
    array(
        'value' => "fa-exclamation-triangle",
        'label' => "exclamation-triangle"
    ),
    array(
        'value' => "fa-expand",
        'label' => "expand"
    ),
    array(
        'value' => "fa-expeditedssl",
        'label' => "expeditedssl"
    ),
    array(
        'value' => "fa-external-link",
        'label' => "external-link"
    ),
    array(
        'value' => "fa-external-link-square",
        'label' => "external-link-square"
    ),
    array(
        'value' => "fa-eye",
        'label' => "eye"
    ),
    array(
        'value' => "fa-eye-slash",
        'label' => "eye-slash"
    ),
    array(
        'value' => "fa-eyedropper",
        'label' => "eyedropper"
    ),
    array(
        'value' => "fa-fa",
        'label' => "fa"
    ),
    array(
        'value' => "fa-facebook",
        'label' => "facebook"
    ),
    array(
        'value' => "fa-facebook-f",
        'label' => "facebook-f"
    ),
    array(
        'value' => "fa-facebook-official",
        'label' => "facebook-official"
    ),
    array(
        'value' => "fa-facebook-square",
        'label' => "facebook-square"
    ),
    array(
        'value' => "fa-fast-backward",
        'label' => "fast-backward"
    ),
    array(
        'value' => "fa-fast-forward",
        'label' => "fast-forward"
    ),
    array(
        'value' => "fa-fax",
        'label' => "fax"
    ),
    array(
        'value' => "fa-feed",
        'label' => "feed"
    ),
    array(
        'value' => "fa-female",
        'label' => "female"
    ),
    array(
        'value' => "fa-fighter-jet",
        'label' => "fighter-jet"
    ),
    array(
        'value' => "fa-file",
        'label' => "file"
    ),
    array(
        'value' => "fa-file-archive-o",
        'label' => "file-archive-o"
    ),
    array(
        'value' => "fa-file-audio-o",
        'label' => "file-audio-o"
    ),
    array(
        'value' => "fa-file-code-o",
        'label' => "file-code-o"
    ),
    array(
        'value' => "fa-file-excel-o",
        'label' => "file-excel-o"
    ),
    array(
        'value' => "fa-file-image-o",
        'label' => "file-image-o"
    ),
    array(
        'value' => "fa-file-movie-o",
        'label' => "file-movie-o"
    ),
    array(
        'value' => "fa-file-o",
        'label' => "file-o"
    ),
    array(
        'value' => "fa-file-pdf-o",
        'label' => "file-pdf-o"
    ),
    array(
        'value' => "fa-file-photo-o",
        'label' => "file-photo-o"
    ),
    array(
        'value' => "fa-file-picture-o",
        'label' => "file-picture-o"
    ),
    array(
        'value' => "fa-file-powerpoint-o",
        'label' => "file-powerpoint-o"
    ),
    array(
        'value' => "fa-file-sound-o",
        'label' => "file-sound-o"
    ),
    array(
        'value' => "fa-file-text",
        'label' => "file-text"
    ),
    array(
        'value' => "fa-file-text-o",
        'label' => "file-text-o"
    ),
    array(
        'value' => "fa-file-video-o",
        'label' => "file-video-o"
    ),
    array(
        'value' => "fa-file-word-o",
        'label' => "file-word-o"
    ),
    array(
        'value' => "fa-file-zip-o",
        'label' => "file-zip-o"
    ),
    array(
        'value' => "fa-files-o",
        'label' => "files-o"
    ),
    array(
        'value' => "fa-film",
        'label' => "film"
    ),
    array(
        'value' => "fa-filter",
        'label' => "filter"
    ),
    array(
        'value' => "fa-fire",
        'label' => "fire"
    ),
    array(
        'value' => "fa-fire-extinguisher",
        'label' => "fire-extinguisher"
    ),
    array(
        'value' => "fa-firefox",
        'label' => "firefox"
    ),
    array(
        'value' => "fa-first-order",
        'label' => "first-order"
    ),
    array(
        'value' => "fa-flag",
        'label' => "flag"
    ),
    array(
        'value' => "fa-flag-checkered",
        'label' => "flag-checkered"
    ),
    array(
        'value' => "fa-flag-o",
        'label' => "flag-o"
    ),
    array(
        'value' => "fa-flash",
        'label' => "flash"
    ),
    array(
        'value' => "fa-flask",
        'label' => "flask"
    ),
    array(
        'value' => "fa-flickr",
        'label' => "flickr"
    ),
    array(
        'value' => "fa-floppy-o",
        'label' => "floppy-o"
    ),
    array(
        'value' => "fa-folder",
        'label' => "folder"
    ),
    array(
        'value' => "fa-folder-o",
        'label' => "folder-o"
    ),
    array(
        'value' => "fa-folder-open",
        'label' => "folder-open"
    ),
    array(
        'value' => "fa-folder-open-o",
        'label' => "folder-open-o"
    ),
    array(
        'value' => "fa-font",
        'label' => "font"
    ),
    array(
        'value' => "fa-font-awesome",
        'label' => "font-awesome"
    ),
    array(
        'value' => "fa-fonticons",
        'label' => "fonticons"
    ),
    array(
        'value' => "fa-fort-awesome",
        'label' => "fort-awesome"
    ),
    array(
        'value' => "fa-forumbee",
        'label' => "forumbee"
    ),
    array(
        'value' => "fa-forward",
        'label' => "forward"
    ),
    array(
        'value' => "fa-foursquare",
        'label' => "foursquare"
    ),
    array(
        'value' => "fa-free-code-camp",
        'label' => "free-code-camp"
    ),
    array(
        'value' => "fa-frown-o",
        'label' => "frown-o"
    ),
    array(
        'value' => "fa-futbol-o",
        'label' => "futbol-o"
    ),
    array(
        'value' => "fa-gamepad",
        'label' => "gamepad"
    ),
    array(
        'value' => "fa-gavel",
        'label' => "gavel"
    ),
    array(
        'value' => "fa-gbp",
        'label' => "gbp"
    ),
    array(
        'value' => "fa-ge",
        'label' => "ge"
    ),
    array(
        'value' => "fa-gear",
        'label' => "gear"
    ),
    array(
        'value' => "fa-gears",
        'label' => "gears"
    ),
    array(
        'value' => "fa-genderless",
        'label' => "genderless"
    ),
    array(
        'value' => "fa-get-pocket",
        'label' => "get-pocket"
    ),
    array(
        'value' => "fa-gg",
        'label' => "gg"
    ),
    array(
        'value' => "fa-gg-circle",
        'label' => "gg-circle"
    ),
    array(
        'value' => "fa-gift",
        'label' => "gift"
    ),
    array(
        'value' => "fa-git",
        'label' => "git"
    ),
    array(
        'value' => "fa-git-square",
        'label' => "git-square"
    ),
    array(
        'value' => "fa-github",
        'label' => "github"
    ),
    array(
        'value' => "fa-github-alt",
        'label' => "github-alt"
    ),
    array(
        'value' => "fa-github-square",
        'label' => "github-square"
    ),
    array(
        'value' => "fa-gitlab",
        'label' => "gitlab"
    ),
    array(
        'value' => "fa-gittip",
        'label' => "gittip"
    ),
    array(
        'value' => "fa-glass",
        'label' => "glass"
    ),
    array(
        'value' => "fa-glide",
        'label' => "glide"
    ),
    array(
        'value' => "fa-glide-g",
        'label' => "glide-g"
    ),
    array(
        'value' => "fa-globe",
        'label' => "globe"
    ),
    array(
        'value' => "fa-google",
        'label' => "google"
    ),
    array(
        'value' => "fa-google-plus",
        'label' => "google-plus"
    ),
    array(
        'value' => "fa-google-plus-circle",
        'label' => "google-plus-circle"
    ),
    array(
        'value' => "fa-google-plus-official",
        'label' => "google-plus-official"
    ),
    array(
        'value' => "fa-google-plus-square",
        'label' => "google-plus-square"
    ),
    array(
        'value' => "fa-google-wallet",
        'label' => "google-wallet"
    ),
    array(
        'value' => "fa-graduation-cap",
        'label' => "graduation-cap"
    ),
    array(
        'value' => "fa-gratipay",
        'label' => "gratipay"
    ),
    array(
        'value' => "fa-grav",
        'label' => "grav"
    ),
    array(
        'value' => "fa-group",
        'label' => "group"
    ),
    array(
        'value' => "fa-h-square",
        'label' => "h-square"
    ),
    array(
        'value' => "fa-hacker-news",
        'label' => "hacker-news"
    ),
    array(
        'value' => "fa-hand-grab-o",
        'label' => "hand-grab-o"
    ),
    array(
        'value' => "fa-hand-lizard-o",
        'label' => "hand-lizard-o"
    ),
    array(
        'value' => "fa-hand-o-down",
        'label' => "hand-o-down"
    ),
    array(
        'value' => "fa-hand-o-left",
        'label' => "hand-o-left"
    ),
    array(
        'value' => "fa-hand-o-right",
        'label' => "hand-o-right"
    ),
    array(
        'value' => "fa-hand-o-up",
        'label' => "hand-o-up"
    ),
    array(
        'value' => "fa-hand-paper-o",
        'label' => "hand-paper-o"
    ),
    array(
        'value' => "fa-hand-peace-o",
        'label' => "hand-peace-o"
    ),
    array(
        'value' => "fa-hand-pointer-o",
        'label' => "hand-pointer-o"
    ),
    array(
        'value' => "fa-hand-rock-o",
        'label' => "hand-rock-o"
    ),
    array(
        'value' => "fa-hand-scissors-o",
        'label' => "hand-scissors-o"
    ),
    array(
        'value' => "fa-hand-spock-o",
        'label' => "hand-spock-o"
    ),
    array(
        'value' => "fa-hand-stop-o",
        'label' => "hand-stop-o"
    ),
    array(
        'value' => "fa-handshake-o",
        'label' => "handshake-o"
    ),
    array(
        'value' => "fa-hard-of-hearing",
        'label' => "hard-of-hearing"
    ),
    array(
        'value' => "fa-hashtag",
        'label' => "hashtag"
    ),
    array(
        'value' => "fa-hdd-o",
        'label' => "hdd-o"
    ),
    array(
        'value' => "fa-header",
        'label' => "header"
    ),
    array(
        'value' => "fa-headphones",
        'label' => "headphones"
    ),
    array(
        'value' => "fa-heart",
        'label' => "heart"
    ),
    array(
        'value' => "fa-heart-o",
        'label' => "heart-o"
    ),
    array(
        'value' => "fa-heartbeat",
        'label' => "heartbeat"
    ),
    array(
        'value' => "fa-history",
        'label' => "history"
    ),
    array(
        'value' => "fa-home",
        'label' => "home"
    ),
    array(
        'value' => "fa-hospital-o",
        'label' => "hospital-o"
    ),
    array(
        'value' => "fa-hotel",
        'label' => "hotel"
    ),
    array(
        'value' => "fa-hourglass",
        'label' => "hourglass"
    ),
    array(
        'value' => "fa-hourglass-1",
        'label' => "hourglass-1"
    ),
    array(
        'value' => "fa-hourglass-2",
        'label' => "hourglass-2"
    ),
    array(
        'value' => "fa-hourglass-3",
        'label' => "hourglass-3"
    ),
    array(
        'value' => "fa-hourglass-end",
        'label' => "hourglass-end"
    ),
    array(
        'value' => "fa-hourglass-half",
        'label' => "hourglass-half"
    ),
    array(
        'value' => "fa-hourglass-o",
        'label' => "hourglass-o"
    ),
    array(
        'value' => "fa-hourglass-start",
        'label' => "hourglass-start"
    ),
    array(
        'value' => "fa-houzz",
        'label' => "houzz"
    ),
    array(
        'value' => "fa-html5",
        'label' => "html5"
    ),
    array(
        'value' => "fa-i-cursor",
        'label' => "i-cursor"
    ),
    array(
        'value' => "fa-id-badge",
        'label' => "id-badge"
    ),
    array(
        'value' => "fa-id-card",
        'label' => "id-card"
    ),
    array(
        'value' => "fa-id-card-o",
        'label' => "id-card-o"
    ),
    array(
        'value' => "fa-ils",
        'label' => "ils"
    ),
    array(
        'value' => "fa-image",
        'label' => "image"
    ),
    array(
        'value' => "fa-imdb",
        'label' => "imdb"
    ),
    array(
        'value' => "fa-inbox",
        'label' => "inbox"
    ),
    array(
        'value' => "fa-indent",
        'label' => "indent"
    ),
    array(
        'value' => "fa-industry",
        'label' => "industry"
    ),
    array(
        'value' => "fa-info",
        'label' => "info"
    ),
    array(
        'value' => "fa-info-circle",
        'label' => "info-circle"
    ),
    array(
        'value' => "fa-inr",
        'label' => "inr"
    ),
    array(
        'value' => "fa-instagram",
        'label' => "instagram"
    ),
    array(
        'value' => "fa-institution",
        'label' => "institution"
    ),
    array(
        'value' => "fa-internet-explorer",
        'label' => "internet-explorer"
    ),
    array(
        'value' => "fa-intersex",
        'label' => "intersex"
    ),
    array(
        'value' => "fa-ioxhost",
        'label' => "ioxhost"
    ),
    array(
        'value' => "fa-italic",
        'label' => "italic"
    ),
    array(
        'value' => "fa-joomla",
        'label' => "joomla"
    ),
    array(
        'value' => "fa-jpy",
        'label' => "jpy"
    ),
    array(
        'value' => "fa-jsfiddle",
        'label' => "jsfiddle"
    ),
    array(
        'value' => "fa-key",
        'label' => "key"
    ),
    array(
        'value' => "fa-keyboard-o",
        'label' => "keyboard-o"
    ),
    array(
        'value' => "fa-krw",
        'label' => "krw"
    ),
    array(
        'value' => "fa-language",
        'label' => "language"
    ),
    array(
        'value' => "fa-laptop",
        'label' => "laptop"
    ),
    array(
        'value' => "fa-lastfm",
        'label' => "lastfm"
    ),
    array(
        'value' => "fa-lastfm-square",
        'label' => "lastfm-square"
    ),
    array(
        'value' => "fa-leaf",
        'label' => "leaf"
    ),
    array(
        'value' => "fa-leanpub",
        'label' => "leanpub"
    ),
    array(
        'value' => "fa-legal",
        'label' => "legal"
    ),
    array(
        'value' => "fa-lemon-o",
        'label' => "lemon-o"
    ),
    array(
        'value' => "fa-level-down",
        'label' => "level-down"
    ),
    array(
        'value' => "fa-level-up",
        'label' => "level-up"
    ),
    array(
        'value' => "fa-life-bouy",
        'label' => "life-bouy"
    ),
    array(
        'value' => "fa-life-buoy",
        'label' => "life-buoy"
    ),
    array(
        'value' => "fa-life-ring",
        'label' => "life-ring"
    ),
    array(
        'value' => "fa-life-saver",
        'label' => "life-saver"
    ),
    array(
        'value' => "fa-lightbulb-o",
        'label' => "lightbulb-o"
    ),
    array(
        'value' => "fa-line-chart",
        'label' => "line-chart"
    ),
    array(
        'value' => "fa-link",
        'label' => "link"
    ),
    array(
        'value' => "fa-linkedin",
        'label' => "linkedin"
    ),
    array(
        'value' => "fa-linkedin-square",
        'label' => "linkedin-square"
    ),
    array(
        'value' => "fa-linode",
        'label' => "linode"
    ),
    array(
        'value' => "fa-linux",
        'label' => "linux"
    ),
    array(
        'value' => "fa-list",
        'label' => "list"
    ),
    array(
        'value' => "fa-list-alt",
        'label' => "list-alt"
    ),
    array(
        'value' => "fa-list-ol",
        'label' => "list-ol"
    ),
    array(
        'value' => "fa-list-ul",
        'label' => "list-ul"
    ),
    array(
        'value' => "fa-location-arrow",
        'label' => "location-arrow"
    ),
    array(
        'value' => "fa-lock",
        'label' => "lock"
    ),
    array(
        'value' => "fa-long-arrow-down",
        'label' => "long-arrow-down"
    ),
    array(
        'value' => "fa-long-arrow-left",
        'label' => "long-arrow-left"
    ),
    array(
        'value' => "fa-long-arrow-right",
        'label' => "long-arrow-right"
    ),
    array(
        'value' => "fa-long-arrow-up",
        'label' => "long-arrow-up"
    ),
    array(
        'value' => "fa-low-vision",
        'label' => "low-vision"
    ),
    array(
        'value' => "fa-magic",
        'label' => "magic"
    ),
    array(
        'value' => "fa-magnet",
        'label' => "magnet"
    ),
    array(
        'value' => "fa-mail-forward",
        'label' => "mail-forward"
    ),
    array(
        'value' => "fa-mail-reply",
        'label' => "mail-reply"
    ),
    array(
        'value' => "fa-mail-reply-all",
        'label' => "mail-reply-all"
    ),
    array(
        'value' => "fa-male",
        'label' => "male"
    ),
    array(
        'value' => "fa-map",
        'label' => "map"
    ),
    array(
        'value' => "fa-map-marker",
        'label' => "map-marker"
    ),
    array(
        'value' => "fa-map-o",
        'label' => "map-o"
    ),
    array(
        'value' => "fa-map-pin",
        'label' => "map-pin"
    ),
    array(
        'value' => "fa-map-signs",
        'label' => "map-signs"
    ),
    array(
        'value' => "fa-mars",
        'label' => "mars"
    ),
    array(
        'value' => "fa-mars-double",
        'label' => "mars-double"
    ),
    array(
        'value' => "fa-mars-stroke",
        'label' => "mars-stroke"
    ),
    array(
        'value' => "fa-mars-stroke-h",
        'label' => "mars-stroke-h"
    ),
    array(
        'value' => "fa-mars-stroke-v",
        'label' => "mars-stroke-v"
    ),
    array(
        'value' => "fa-maxcdn",
        'label' => "maxcdn"
    ),
    array(
        'value' => "fa-meanpath",
        'label' => "meanpath"
    ),
    array(
        'value' => "fa-medium",
        'label' => "medium"
    ),
    array(
        'value' => "fa-medkit",
        'label' => "medkit"
    ),
    array(
        'value' => "fa-meetup",
        'label' => "meetup"
    ),
    array(
        'value' => "fa-meh-o",
        'label' => "meh-o"
    ),
    array(
        'value' => "fa-mercury",
        'label' => "mercury"
    ),
    array(
        'value' => "fa-microchip",
        'label' => "microchip"
    ),
    array(
        'value' => "fa-microphone",
        'label' => "microphone"
    ),
    array(
        'value' => "fa-microphone-slash",
        'label' => "microphone-slash"
    ),
    array(
        'value' => "fa-minus",
        'label' => "minus"
    ),
    array(
        'value' => "fa-minus-circle",
        'label' => "minus-circle"
    ),
    array(
        'value' => "fa-minus-square",
        'label' => "minus-square"
    ),
    array(
        'value' => "fa-minus-square-o",
        'label' => "minus-square-o"
    ),
    array(
        'value' => "fa-mixcloud",
        'label' => "mixcloud"
    ),
    array(
        'value' => "fa-mobile",
        'label' => "mobile"
    ),
    array(
        'value' => "fa-mobile-phone",
        'label' => "mobile-phone"
    ),
    array(
        'value' => "fa-modx",
        'label' => "modx"
    ),
    array(
        'value' => "fa-money",
        'label' => "money"
    ),
    array(
        'value' => "fa-moon-o",
        'label' => "moon-o"
    ),
    array(
        'value' => "fa-mortar-board",
        'label' => "mortar-board"
    ),
    array(
        'value' => "fa-motorcycle",
        'label' => "motorcycle"
    ),
    array(
        'value' => "fa-mouse-pointer",
        'label' => "mouse-pointer"
    ),
    array(
        'value' => "fa-music",
        'label' => "music"
    ),
    array(
        'value' => "fa-navicon",
        'label' => "navicon"
    ),
    array(
        'value' => "fa-neuter",
        'label' => "neuter"
    ),
    array(
        'value' => "fa-newspaper-o",
        'label' => "newspaper-o"
    ),
    array(
        'value' => "fa-object-group",
        'label' => "object-group"
    ),
    array(
        'value' => "fa-object-ungroup",
        'label' => "object-ungroup"
    ),
    array(
        'value' => "fa-odnoklassniki",
        'label' => "odnoklassniki"
    ),
    array(
        'value' => "fa-odnoklassniki-square",
        'label' => "odnoklassniki-square"
    ),
    array(
        'value' => "fa-opencart",
        'label' => "opencart"
    ),
    array(
        'value' => "fa-openid",
        'label' => "openid"
    ),
    array(
        'value' => "fa-opera",
        'label' => "opera"
    ),
    array(
        'value' => "fa-optin-monster",
        'label' => "optin-monster"
    ),
    array(
        'value' => "fa-outdent",
        'label' => "outdent"
    ),
    array(
        'value' => "fa-pagelines",
        'label' => "pagelines"
    ),
    array(
        'value' => "fa-paint-brush",
        'label' => "paint-brush"
    ),
    array(
        'value' => "fa-paper-plane",
        'label' => "paper-plane"
    ),
    array(
        'value' => "fa-paper-plane-o",
        'label' => "paper-plane-o"
    ),
    array(
        'value' => "fa-paperclip",
        'label' => "paperclip"
    ),
    array(
        'value' => "fa-paragraph",
        'label' => "paragraph"
    ),
    array(
        'value' => "fa-paste",
        'label' => "paste"
    ),
    array(
        'value' => "fa-pause",
        'label' => "pause"
    ),
    array(
        'value' => "fa-pause-circle",
        'label' => "pause-circle"
    ),
    array(
        'value' => "fa-pause-circle-o",
        'label' => "pause-circle-o"
    ),
    array(
        'value' => "fa-paw",
        'label' => "paw"
    ),
    array(
        'value' => "fa-paypal",
        'label' => "paypal"
    ),
    array(
        'value' => "fa-pencil",
        'label' => "pencil"
    ),
    array(
        'value' => "fa-pencil-square",
        'label' => "pencil-square"
    ),
    array(
        'value' => "fa-pencil-square-o",
        'label' => "pencil-square-o"
    ),
    array(
        'value' => "fa-percent",
        'label' => "percent"
    ),
    array(
        'value' => "fa-phone",
        'label' => "phone"
    ),
    array(
        'value' => "fa-phone-square",
        'label' => "phone-square"
    ),
    array(
        'value' => "fa-photo",
        'label' => "photo"
    ),
    array(
        'value' => "fa-picture-o",
        'label' => "picture-o"
    ),
    array(
        'value' => "fa-pie-chart",
        'label' => "pie-chart"
    ),
    array(
        'value' => "fa-pied-piper",
        'label' => "pied-piper"
    ),
    array(
        'value' => "fa-pied-piper-alt",
        'label' => "pied-piper-alt"
    ),
    array(
        'value' => "fa-pied-piper-pp",
        'label' => "pied-piper-pp"
    ),
    array(
        'value' => "fa-pinterest",
        'label' => "pinterest"
    ),
    array(
        'value' => "fa-pinterest-p",
        'label' => "pinterest-p"
    ),
    array(
        'value' => "fa-pinterest-square",
        'label' => "pinterest-square"
    ),
    array(
        'value' => "fa-plane",
        'label' => "plane"
    ),
    array(
        'value' => "fa-play",
        'label' => "play"
    ),
    array(
        'value' => "fa-play-circle",
        'label' => "play-circle"
    ),
    array(
        'value' => "fa-play-circle-o",
        'label' => "play-circle-o"
    ),
    array(
        'value' => "fa-plug",
        'label' => "plug"
    ),
    array(
        'value' => "fa-plus",
        'label' => "plus"
    ),
    array(
        'value' => "fa-plus-circle",
        'label' => "plus-circle"
    ),
    array(
        'value' => "fa-plus-square",
        'label' => "plus-square"
    ),
    array(
        'value' => "fa-plus-square-o",
        'label' => "plus-square-o"
    ),
    array(
        'value' => "fa-podcast",
        'label' => "podcast"
    ),
    array(
        'value' => "fa-power-off",
        'label' => "power-off"
    ),
    array(
        'value' => "fa-print",
        'label' => "print"
    ),
    array(
        'value' => "fa-product-hunt",
        'label' => "product-hunt"
    ),
    array(
        'value' => "fa-puzzle-piece",
        'label' => "puzzle-piece"
    ),
    array(
        'value' => "fa-qq",
        'label' => "qq"
    ),
    array(
        'value' => "fa-qrcode",
        'label' => "qrcode"
    ),
    array(
        'value' => "fa-question",
        'label' => "question"
    ),
    array(
        'value' => "fa-question-circle",
        'label' => "question-circle"
    ),
    array(
        'value' => "fa-question-circle-o",
        'label' => "question-circle-o"
    ),
    array(
        'value' => "fa-quora",
        'label' => "quora"
    ),
    array(
        'value' => "fa-quote-left",
        'label' => "quote-left"
    ),
    array(
        'value' => "fa-quote-right",
        'label' => "quote-right"
    ),
    array(
        'value' => "fa-ra",
        'label' => "ra"
    ),
    array(
        'value' => "fa-random",
        'label' => "random"
    ),
    array(
        'value' => "fa-ravelry",
        'label' => "ravelry"
    ),
    array(
        'value' => "fa-rebel",
        'label' => "rebel"
    ),
    array(
        'value' => "fa-recycle",
        'label' => "recycle"
    ),
    array(
        'value' => "fa-reddit",
        'label' => "reddit"
    ),
    array(
        'value' => "fa-reddit-alien",
        'label' => "reddit-alien"
    ),
    array(
        'value' => "fa-reddit-square",
        'label' => "reddit-square"
    ),
    array(
        'value' => "fa-refresh",
        'label' => "refresh"
    ),
    array(
        'value' => "fa-registered",
        'label' => "registered"
    ),
    array(
        'value' => "fa-remove",
        'label' => "remove"
    ),
    array(
        'value' => "fa-renren",
        'label' => "renren"
    ),
    array(
        'value' => "fa-reorder",
        'label' => "reorder"
    ),
    array(
        'value' => "fa-repeat",
        'label' => "repeat"
    ),
    array(
        'value' => "fa-reply",
        'label' => "reply"
    ),
    array(
        'value' => "fa-reply-all",
        'label' => "reply-all"
    ),
    array(
        'value' => "fa-resistance",
        'label' => "resistance"
    ),
    array(
        'value' => "fa-retweet",
        'label' => "retweet"
    ),
    array(
        'value' => "fa-rmb",
        'label' => "rmb"
    ),
    array(
        'value' => "fa-road",
        'label' => "road"
    ),
    array(
        'value' => "fa-rocket",
        'label' => "rocket"
    ),
    array(
        'value' => "fa-rotate-left",
        'label' => "rotate-left"
    ),
    array(
        'value' => "fa-rotate-right",
        'label' => "rotate-right"
    ),
    array(
        'value' => "fa-rouble",
        'label' => "rouble"
    ),
    array(
        'value' => "fa-rss",
        'label' => "rss"
    ),
    array(
        'value' => "fa-rss-square",
        'label' => "rss-square"
    ),
    array(
        'value' => "fa-rub",
        'label' => "rub"
    ),
    array(
        'value' => "fa-ruble",
        'label' => "ruble"
    ),
    array(
        'value' => "fa-rupee",
        'label' => "rupee"
    ),
    array(
        'value' => "fa-s15",
        'label' => "s15"
    ),
    array(
        'value' => "fa-safari",
        'label' => "safari"
    ),
    array(
        'value' => "fa-save",
        'label' => "save"
    ),
    array(
        'value' => "fa-scissors",
        'label' => "scissors"
    ),
    array(
        'value' => "fa-scribd",
        'label' => "scribd"
    ),
    array(
        'value' => "fa-search",
        'label' => "search"
    ),
    array(
        'value' => "fa-search-minus",
        'label' => "search-minus"
    ),
    array(
        'value' => "fa-search-plus",
        'label' => "search-plus"
    ),
    array(
        'value' => "fa-sellsy",
        'label' => "sellsy"
    ),
    array(
        'value' => "fa-send",
        'label' => "send"
    ),
    array(
        'value' => "fa-send-o",
        'label' => "send-o"
    ),
    array(
        'value' => "fa-server",
        'label' => "server"
    ),
    array(
        'value' => "fa-share",
        'label' => "share"
    ),
    array(
        'value' => "fa-share-alt",
        'label' => "share-alt"
    ),
    array(
        'value' => "fa-share-alt-square",
        'label' => "share-alt-square"
    ),
    array(
        'value' => "fa-share-square",
        'label' => "share-square"
    ),
    array(
        'value' => "fa-share-square-o",
        'label' => "share-square-o"
    ),
    array(
        'value' => "fa-shekel",
        'label' => "shekel"
    ),
    array(
        'value' => "fa-sheqel",
        'label' => "sheqel"
    ),
    array(
        'value' => "fa-shield",
        'label' => "shield"
    ),
    array(
        'value' => "fa-ship",
        'label' => "ship"
    ),
    array(
        'value' => "fa-shirtsinbulk",
        'label' => "shirtsinbulk"
    ),
    array(
        'value' => "fa-shopping-bag",
        'label' => "shopping-bag"
    ),
    array(
        'value' => "fa-shopping-basket",
        'label' => "shopping-basket"
    ),
    array(
        'value' => "fa-shopping-cart",
        'label' => "shopping-cart"
    ),
    array(
        'value' => "fa-shower",
        'label' => "shower"
    ),
    array(
        'value' => "fa-sign-in",
        'label' => "sign-in"
    ),
    array(
        'value' => "fa-sign-language",
        'label' => "sign-language"
    ),
    array(
        'value' => "fa-sign-out",
        'label' => "sign-out"
    ),
    array(
        'value' => "fa-signal",
        'label' => "signal"
    ),
    array(
        'value' => "fa-signing",
        'label' => "signing"
    ),
    array(
        'value' => "fa-simplybuilt",
        'label' => "simplybuilt"
    ),
    array(
        'value' => "fa-sitemap",
        'label' => "sitemap"
    ),
    array(
        'value' => "fa-skyatlas",
        'label' => "skyatlas"
    ),
    array(
        'value' => "fa-skype",
        'label' => "skype"
    ),
    array(
        'value' => "fa-slack",
        'label' => "slack"
    ),
    array(
        'value' => "fa-sliders",
        'label' => "sliders"
    ),
    array(
        'value' => "fa-slideshare",
        'label' => "slideshare"
    ),
    array(
        'value' => "fa-smile-o",
        'label' => "smile-o"
    ),
    array(
        'value' => "fa-snapchat",
        'label' => "snapchat"
    ),
    array(
        'value' => "fa-snapchat-ghost",
        'label' => "snapchat-ghost"
    ),
    array(
        'value' => "fa-snapchat-square",
        'label' => "snapchat-square"
    ),
    array(
        'value' => "fa-snowflake-o",
        'label' => "snowflake-o"
    ),
    array(
        'value' => "fa-soccer-ball-o",
        'label' => "soccer-ball-o"
    ),
    array(
        'value' => "fa-sort",
        'label' => "sort"
    ),
    array(
        'value' => "fa-sort-alpha-asc",
        'label' => "sort-alpha-asc"
    ),
    array(
        'value' => "fa-sort-alpha-desc",
        'label' => "sort-alpha-desc"
    ),
    array(
        'value' => "fa-sort-amount-asc",
        'label' => "sort-amount-asc"
    ),
    array(
        'value' => "fa-sort-amount-desc",
        'label' => "sort-amount-desc"
    ),
    array(
        'value' => "fa-sort-asc",
        'label' => "sort-asc"
    ),
    array(
        'value' => "fa-sort-desc",
        'label' => "sort-desc"
    ),
    array(
        'value' => "fa-sort-down",
        'label' => "sort-down"
    ),
    array(
        'value' => "fa-sort-numeric-asc",
        'label' => "sort-numeric-asc"
    ),
    array(
        'value' => "fa-sort-numeric-desc",
        'label' => "sort-numeric-desc"
    ),
    array(
        'value' => "fa-sort-up",
        'label' => "sort-up"
    ),
    array(
        'value' => "fa-soundcloud",
        'label' => "soundcloud"
    ),
    array(
        'value' => "fa-space-shuttle",
        'label' => "space-shuttle"
    ),
    array(
        'value' => "fa-spinner",
        'label' => "spinner"
    ),
    array(
        'value' => "fa-spoon",
        'label' => "spoon"
    ),
    array(
        'value' => "fa-spotify",
        'label' => "spotify"
    ),
    array(
        'value' => "fa-square",
        'label' => "square"
    ),
    array(
        'value' => "fa-square-o",
        'label' => "square-o"
    ),
    array(
        'value' => "fa-stack-exchange",
        'label' => "stack-exchange"
    ),
    array(
        'value' => "fa-stack-overflow",
        'label' => "stack-overflow"
    ),
    array(
        'value' => "fa-star",
        'label' => "star"
    ),
    array(
        'value' => "fa-star-half",
        'label' => "star-half"
    ),
    array(
        'value' => "fa-star-half-empty",
        'label' => "star-half-empty"
    ),
    array(
        'value' => "fa-star-half-full",
        'label' => "star-half-full"
    ),
    array(
        'value' => "fa-star-half-o",
        'label' => "star-half-o"
    ),
    array(
        'value' => "fa-star-o",
        'label' => "star-o"
    ),
    array(
        'value' => "fa-steam",
        'label' => "steam"
    ),
    array(
        'value' => "fa-steam-square",
        'label' => "steam-square"
    ),
    array(
        'value' => "fa-step-backward",
        'label' => "step-backward"
    ),
    array(
        'value' => "fa-step-forward",
        'label' => "step-forward"
    ),
    array(
        'value' => "fa-stethoscope",
        'label' => "stethoscope"
    ),
    array(
        'value' => "fa-sticky-note",
        'label' => "sticky-note"
    ),
    array(
        'value' => "fa-sticky-note-o",
        'label' => "sticky-note-o"
    ),
    array(
        'value' => "fa-stop",
        'label' => "stop"
    ),
    array(
        'value' => "fa-stop-circle",
        'label' => "stop-circle"
    ),
    array(
        'value' => "fa-stop-circle-o",
        'label' => "stop-circle-o"
    ),
    array(
        'value' => "fa-street-view",
        'label' => "street-view"
    ),
    array(
        'value' => "fa-strikethrough",
        'label' => "strikethrough"
    ),
    array(
        'value' => "fa-stumbleupon",
        'label' => "stumbleupon"
    ),
    array(
        'value' => "fa-stumbleupon-circle",
        'label' => "stumbleupon-circle"
    ),
    array(
        'value' => "fa-subscript",
        'label' => "subscript"
    ),
    array(
        'value' => "fa-subway",
        'label' => "subway"
    ),
    array(
        'value' => "fa-suitcase",
        'label' => "suitcase"
    ),
    array(
        'value' => "fa-sun-o",
        'label' => "sun-o"
    ),
    array(
        'value' => "fa-superpowers",
        'label' => "superpowers"
    ),
    array(
        'value' => "fa-superscript",
        'label' => "superscript"
    ),
    array(
        'value' => "fa-support",
        'label' => "support"
    ),
    array(
        'value' => "fa-table",
        'label' => "table"
    ),
    array(
        'value' => "fa-tablet",
        'label' => "tablet"
    ),
    array(
        'value' => "fa-tachometer",
        'label' => "tachometer"
    ),
    array(
        'value' => "fa-tag",
        'label' => "tag"
    ),
    array(
        'value' => "fa-tags",
        'label' => "tags"
    ),
    array(
        'value' => "fa-tasks",
        'label' => "tasks"
    ),
    array(
        'value' => "fa-taxi",
        'label' => "taxi"
    ),
    array(
        'value' => "fa-telegram",
        'label' => "telegram"
    ),
    array(
        'value' => "fa-television",
        'label' => "television"
    ),
    array(
        'value' => "fa-tencent-weibo",
        'label' => "tencent-weibo"
    ),
    array(
        'value' => "fa-terminal",
        'label' => "terminal"
    ),
    array(
        'value' => "fa-text-height",
        'label' => "text-height"
    ),
    array(
        'value' => "fa-text-width",
        'label' => "text-width"
    ),
    array(
        'value' => "fa-th",
        'label' => "th"
    ),
    array(
        'value' => "fa-th-large",
        'label' => "th-large"
    ),
    array(
        'value' => "fa-th-list",
        'label' => "th-list"
    ),
    array(
        'value' => "fa-themeisle",
        'label' => "themeisle"
    ),
    array(
        'value' => "fa-thermometer",
        'label' => "thermometer"
    ),
    array(
        'value' => "fa-thermometer-0",
        'label' => "thermometer-0"
    ),
    array(
        'value' => "fa-thermometer-1",
        'label' => "thermometer-1"
    ),
    array(
        'value' => "fa-thermometer-2",
        'label' => "thermometer-2"
    ),
    array(
        'value' => "fa-thermometer-3",
        'label' => "thermometer-3"
    ),
    array(
        'value' => "fa-thermometer-4",
        'label' => "thermometer-4"
    ),
    array(
        'value' => "fa-thermometer-empty",
        'label' => "thermometer-empty"
    ),
    array(
        'value' => "fa-thermometer-full",
        'label' => "thermometer-full"
    ),
    array(
        'value' => "fa-thermometer-half",
        'label' => "thermometer-half"
    ),
    array(
        'value' => "fa-thermometer-quarter",
        'label' => "thermometer-quarter"
    ),
    array(
        'value' => "fa-thermometer-three-quarters",
        'label' => "thermometer-three-quarters"
    ),
    array(
        'value' => "fa-thumb-tack",
        'label' => "thumb-tack"
    ),
    array(
        'value' => "fa-thumbs-down",
        'label' => "thumbs-down"
    ),
    array(
        'value' => "fa-thumbs-o-down",
        'label' => "thumbs-o-down"
    ),
    array(
        'value' => "fa-thumbs-o-up",
        'label' => "thumbs-o-up"
    ),
    array(
        'value' => "fa-thumbs-up",
        'label' => "thumbs-up"
    ),
    array(
        'value' => "fa-ticket",
        'label' => "ticket"
    ),
    array(
        'value' => "fa-times",
        'label' => "times"
    ),
    array(
        'value' => "fa-times-circle",
        'label' => "times-circle"
    ),
    array(
        'value' => "fa-times-circle-o",
        'label' => "times-circle-o"
    ),
    array(
        'value' => "fa-times-rectangle",
        'label' => "times-rectangle"
    ),
    array(
        'value' => "fa-times-rectangle-o",
        'label' => "times-rectangle-o"
    ),
    array(
        'value' => "fa-tint",
        'label' => "tint"
    ),
    array(
        'value' => "fa-toggle-down",
        'label' => "toggle-down"
    ),
    array(
        'value' => "fa-toggle-left",
        'label' => "toggle-left"
    ),
    array(
        'value' => "fa-toggle-off",
        'label' => "toggle-off"
    ),
    array(
        'value' => "fa-toggle-on",
        'label' => "toggle-on"
    ),
    array(
        'value' => "fa-toggle-right",
        'label' => "toggle-right"
    ),
    array(
        'value' => "fa-toggle-up",
        'label' => "toggle-up"
    ),
    array(
        'value' => "fa-trademark",
        'label' => "trademark"
    ),
    array(
        'value' => "fa-train",
        'label' => "train"
    ),
    array(
        'value' => "fa-transgender",
        'label' => "transgender"
    ),
    array(
        'value' => "fa-transgender-alt",
        'label' => "transgender-alt"
    ),
    array(
        'value' => "fa-trash",
        'label' => "trash"
    ),
    array(
        'value' => "fa-trash-o",
        'label' => "trash-o"
    ),
    array(
        'value' => "fa-tree",
        'label' => "tree"
    ),
    array(
        'value' => "fa-trello",
        'label' => "trello"
    ),
    array(
        'value' => "fa-tripadvisor",
        'label' => "tripadvisor"
    ),
    array(
        'value' => "fa-trophy",
        'label' => "trophy"
    ),
    array(
        'value' => "fa-truck",
        'label' => "truck"
    ),
    array(
        'value' => "fa-try",
        'label' => "try"
    ),
    array(
        'value' => "fa-tty",
        'label' => "tty"
    ),
    array(
        'value' => "fa-tumblr",
        'label' => "tumblr"
    ),
    array(
        'value' => "fa-tumblr-square",
        'label' => "tumblr-square"
    ),
    array(
        'value' => "fa-turkish-lira",
        'label' => "turkish-lira"
    ),
    array(
        'value' => "fa-tv",
        'label' => "tv"
    ),
    array(
        'value' => "fa-twitch",
        'label' => "twitch"
    ),
    array(
        'value' => "fa-twitter",
        'label' => "twitter"
    ),
    array(
        'value' => "fa-twitter-square",
        'label' => "twitter-square"
    ),
    array(
        'value' => "fa-umbrella",
        'label' => "umbrella"
    ),
    array(
        'value' => "fa-underline",
        'label' => "underline"
    ),
    array(
        'value' => "fa-undo",
        'label' => "undo"
    ),
    array(
        'value' => "fa-universal-access",
        'label' => "universal-access"
    ),
    array(
        'value' => "fa-university",
        'label' => "university"
    ),
    array(
        'value' => "fa-unlink",
        'label' => "unlink"
    ),
    array(
        'value' => "fa-unlock",
        'label' => "unlock"
    ),
    array(
        'value' => "fa-unlock-alt",
        'label' => "unlock-alt"
    ),
    array(
        'value' => "fa-unsorted",
        'label' => "unsorted"
    ),
    array(
        'value' => "fa-upload",
        'label' => "upload"
    ),
    array(
        'value' => "fa-usb",
        'label' => "usb"
    ),
    array(
        'value' => "fa-usd",
        'label' => "usd"
    ),
    array(
        'value' => "fa-user",
        'label' => "user"
    ),
    array(
        'value' => "fa-user-circle",
        'label' => "user-circle"
    ),
    array(
        'value' => "fa-user-circle-o",
        'label' => "user-circle-o"
    ),
    array(
        'value' => "fa-user-md",
        'label' => "user-md"
    ),
    array(
        'value' => "fa-user-o",
        'label' => "user-o"
    ),
    array(
        'value' => "fa-user-plus",
        'label' => "user-plus"
    ),
    array(
        'value' => "fa-user-secret",
        'label' => "user-secret"
    ),
    array(
        'value' => "fa-user-times",
        'label' => "user-times"
    ),
    array(
        'value' => "fa-users",
        'label' => "users"
    ),
    array(
        'value' => "fa-vcard",
        'label' => "vcard"
    ),
    array(
        'value' => "fa-vcard-o",
        'label' => "vcard-o"
    ),
    array(
        'value' => "fa-venus",
        'label' => "venus"
    ),
    array(
        'value' => "fa-venus-double",
        'label' => "venus-double"
    ),
    array(
        'value' => "fa-venus-mars",
        'label' => "venus-mars"
    ),
    array(
        'value' => "fa-viacoin",
        'label' => "viacoin"
    ),
    array(
        'value' => "fa-viadeo",
        'label' => "viadeo"
    ),
    array(
        'value' => "fa-viadeo-square",
        'label' => "viadeo-square"
    ),
    array(
        'value' => "fa-video-camera",
        'label' => "video-camera"
    ),
    array(
        'value' => "fa-vimeo",
        'label' => "vimeo"
    ),
    array(
        'value' => "fa-vimeo-square",
        'label' => "vimeo-square"
    ),
    array(
        'value' => "fa-vine",
        'label' => "vine"
    ),
    array(
        'value' => "fa-vk",
        'label' => "vk"
    ),
    array(
        'value' => "fa-volume-control-phone",
        'label' => "volume-control-phone"
    ),
    array(
        'value' => "fa-volume-down",
        'label' => "volume-down"
    ),
    array(
        'value' => "fa-volume-off",
        'label' => "volume-off"
    ),
    array(
        'value' => "fa-volume-up",
        'label' => "volume-up"
    ),
    array(
        'value' => "fa-warning",
        'label' => "warning"
    ),
    array(
        'value' => "fa-wechat",
        'label' => "wechat"
    ),
    array(
        'value' => "fa-weibo",
        'label' => "weibo"
    ),
    array(
        'value' => "fa-weixin",
        'label' => "weixin"
    ),
    array(
        'value' => "fa-whatsapp",
        'label' => "whatsapp"
    ),
    array(
        'value' => "fa-wheelchair",
        'label' => "wheelchair"
    ),
    array(
        'value' => "fa-wheelchair-alt",
        'label' => "wheelchair-alt"
    ),
    array(
        'value' => "fa-wifi",
        'label' => "wifi"
    ),
    array(
        'value' => "fa-wikipedia-w",
        'label' => "wikipedia-w"
    ),
    array(
        'value' => "fa-window-close",
        'label' => "window-close"
    ),
    array(
        'value' => "fa-window-close-o",
        'label' => "window-close-o"
    ),
    array(
        'value' => "fa-window-maximize",
        'label' => "window-maximize"
    ),
    array(
        'value' => "fa-window-minimize",
        'label' => "window-minimize"
    ),
    array(
        'value' => "fa-window-restore",
        'label' => "window-restore"
    ),
    array(
        'value' => "fa-windows",
        'label' => "windows"
    ),
    array(
        'value' => "fa-won",
        'label' => "won"
    ),
    array(
        'value' => "fa-wordpress",
        'label' => "wordpress"
    ),
    array(
        'value' => "fa-wpbeginner",
        'label' => "wpbeginner"
    ),
    array(
        'value' => "fa-wpexplorer",
        'label' => "wpexplorer"
    ),
    array(
        'value' => "fa-wpforms",
        'label' => "wpforms"
    ),
    array(
        'value' => "fa-wrench",
        'label' => "wrench"
    ),
    array(
        'value' => "fa-xing",
        'label' => "xing"
    ),
    array(
        'value' => "fa-xing-square",
        'label' => "xing-square"
    ),
    array(
        'value' => "fa-y-combinator",
        'label' => "y-combinator"
    ),
    array(
        'value' => "fa-y-combinator-square",
        'label' => "y-combinator-square"
    ),
    array(
        'value' => "fa-yahoo",
        'label' => "yahoo"
    ),
    array(
        'value' => "fa-yc",
        'label' => "yc"
    ),
    array(
        'value' => "fa-yc-square",
        'label' => "yc-square"
    ),
    array(
        'value' => "fa-yelp",
        'label' => "yelp"
    ),
    array(
        'value' => "fa-yen",
        'label' => "yen"
    ),
    array(
        'value' => "fa-yoast",
        'label' => "yoast"
    ),
    array(
        'value' => "fa-youtube",
        'label' => "youtube"
    ),
    array(
        'value' => "fa-youtube-play",
        'label' => "youtube-play"
    ),
    array(
        'value' => "fa-youtube-square",
        'label' => "youtube-square"
    ),
);

return $fontawesome_icons;