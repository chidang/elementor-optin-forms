( function( $ ) {
	"use strict";
	var ansh_optin_forms_widget = function ( panel, model, view ) {
		panel.find(".ansh-optin-form-submit").on( "click", function(){

			var $this = jQuery(this);
		
			ansh_optin_form_submit( $this );
		});
	}
	/* Elementor init Script call */ 
	$( window ).on( 'elementor/frontend/init', function() {
		/* Optin Form*/
		elementorFrontend.hooks.addAction( 'frontend/element_ready/ansh_optin_forms_widget.default', ansh_optin_forms_widget );
	});
	
	$(document).ready(function() {
		$(".ansh-optin-form-enabled-lists").on( "click", function(){
			var email_provider  = $(this).data( 'email-provider' );
			var input_name  = $(this).attr( 'name' );			
			var email_provider_value  = $('input[name="'+ input_name +'"]:checked').val();
			console.log(email_provider +" = "+input_name +" = "+email_provider_value);
			jQuery.ajax({
				url: AnshOptinFormsConfig.ajaxurl,
				type:'post',				
				data : {
						'action' : 'ansh_optin_forms_enabled_lists', 
						'email_provider' : email_provider,
						'email_provider_value' : ( typeof email_provider_value !== 'undefined' ) ? email_provider_value: '',
					},
				dataType: 'json',
				beforeSend: function() {					
				},
				success: function( data ){
					
				},				
			});
			
		});
	});	

	$(document).on('click', '.ansh-optin-form-submit', function(e){

		e.preventDefault();

		var $this = jQuery(this);
		
		ansh_optin_form_submit( $this );
		
	});

})( jQuery );

function ansh_optin_form_submit($this) {
	var form_id  = $this.attr( 'data-form-id' );
	var nonce_id = $this.attr( 'data-nonce-id' );

	var asdsad = jQuery('form#'+ form_id).serialize();

	console.log({asdsad:asdsad});
	
	jQuery.ajax({
		url: AnshOptinFormsConfig.ajaxurl,
		type:'post',
		data: 'action=ansh_optin_form_singup&' + jQuery('form#'+ form_id).serialize(),
		dataType: 'json',
		beforeSend: function() {
			jQuery('.ansh-spining-'+form_id).html('<i class="fa fa-refresh fa-spin"></i>');
		},
		success: function( data ){
			var msg;

			console.log({data:data});

			if ( typeof data.message !== 'undefined'  ) {
				msg = data.message;
				jQuery('form#' + form_id + ' .ansh-optin-form-msg').removeClass('error_msg');
				jQuery('form#' + form_id + ' .ansh-optin-form-msg').addClass('success_msg');
				
				if (typeof data.redirect_link !== 'undefined' && data.redirect_link !== '' ) {
					window.location = data.redirect_link;
				}
			} else {
				msg = data.error;
				jQuery('form#' + form_id + ' .ansh-optin-form-msg').addClass('error_msg');
			}
			jQuery('form#' + form_id + ' .ansh-optin-form-msg').show();
			jQuery('form#' + form_id + ' .ansh-optin-form-msg').html(msg);
			setTimeout(function() {
				jQuery('form#' + form_id + ' .ansh-optin-form-msg').slideUp("slow");
			}, 5000);

			jQuery('form#' + form_id + ' .ansh-newsletter-email').val('');
			jQuery('.ansh-spining-' + form_id ).html('');
		},
		error: function(msg){

			jQuery('form#' + form_id + ' .ansh-optin-form-msg').addClass('error_msg');
			jQuery('form#' + form_id + ' .ansh-optin-form-msg').html(msg);
			jQuery('form#' + form_id + ' .ansh-optin-form-msg').show();
			jQuery('.ansh-spining-' + form_id ).html('');
			setTimeout(function() {
				jQuery('form#' + form_id + ' .ansh-optin-form-msg').slideUp("slow");
			}, 5000);

		}
	});
	
	return false;
}