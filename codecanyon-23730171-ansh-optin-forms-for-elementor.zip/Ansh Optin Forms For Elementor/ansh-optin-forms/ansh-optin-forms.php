<?php
/**
 * Plugin Name: Ansh Optin Forms For Elementor
 * Description: Generate leads with the Ansh Opt in forms for newsletter signup on your website. Create standard and attractive opt-ins to grow your mailing list now.
 * Plugin URI: https://dishantpatel.me
 * Author: Dishant Patel
 * Version: 2.0.0
 * Author URI: https://dishantpatel.me
 *
 * Text Domain: ansh-optin-forms
 */
 
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

define('ANSH_OPTIN_FORMS_URL', plugins_url('/', __FILE__));  // Define Plugin URL
define('ANSH_OPTIN_FORMS_PATH', plugin_dir_path(__FILE__));  // Define Plugin Directory Path


/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_load_plugin_textdomain() {
	load_plugin_textdomain( 'ansh-optin-forms', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	
	/* Check Elementor loaded action call */
	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'ansh_optin_forms_admin_notices' );		
	} else {
		require_once ANSH_OPTIN_FORMS_PATH . 'includes/import-blocks-templates/ansh-optin_forms-import-blocks-data.php';
	}
}
add_action( 'plugins_loaded', 'ansh_optin_forms_load_plugin_textdomain' );

/**
 * Import Pre define blocks on plugin activation process.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_plugin_activate(){
	
	global $ansh_optin_forms_blocks, $wpdb;
	
	require_once ANSH_OPTIN_FORMS_PATH . 'includes/import-blocks-templates/ansh-optin-forms-blocks-templates.php';
	
	$library_data = get_option( 'elementor_remote_info_library' );
	
	$categories_flg = false;
	foreach( $library_data['types_data']['block']['categories'] as $key=>$value){
		if ($value == 'Ansh Optin Forms' ) {
			$categories_flg = true;
		}
	}

	if ( !$categories_flg ) {
		$library_data['types_data']['block']['categories'][] = 'Ansh Optin Forms';
	}
	
	foreach( $ansh_optin_forms_blocks as $key=>$value) {	
		if ( !in_array( $key, $library_data['templates'])) {
			$library_data['templates'][$key] = $value;
		}
	}
	/* Update Elementor remote library info */
	update_option( 'elementor_remote_info_library', $library_data );	
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	$charset_collate = $wpdb->get_charset_collate();

	$ansh_optin_contact_lists = $wpdb->prefix . 'ansh_optin_contact_lists';
	if($wpdb->get_var("show tables like '$ansh_optin_contact_lists'") != $ansh_optin_contact_lists) {

		$ansh_optin_contact_lists_sql = "CREATE TABLE $ansh_optin_contact_lists (
			ID mediumint(9) NOT NULL AUTO_INCREMENT,
			first_name text NULL,
			last_name text NULL,
			email text NOT NULL,
			created_date datetime NOT NULL default CURRENT_TIMESTAMP,
			UNIQUE KEY ID (ID)
		) $charset_collate;";
		dbDelta( $ansh_optin_contact_lists_sql );

	}

}

register_activation_hook( __FILE__, 'ansh_optin_forms_plugin_activate' );

/**
 * Redirect to plugin setting page after activate the plugin.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_activation_redirect( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        wp_redirect( admin_url( 'admin.php?page=ansh_optin_forms_integration' ) ) ;
		exit;
    }
}
add_action( 'activated_plugin', 'ansh_optin_forms_activation_redirect' );


/**
 * Delete Pre define blocks on plugin deactivation process.
 *
 * @since 1.0.0
 */
function ansh_optin_forms_plugin_deactivation() {
	global $ansh_optin_forms_blocks;
	
	require_once ANSH_OPTIN_FORMS_PATH . 'includes/import-blocks-templates/ansh-optin-forms-blocks-templates.php';
	
	$library_data = get_option( 'elementor_remote_info_library' );
	
	
	foreach( $library_data['types_data']['block']['categories'] as $key=>$value){
		if ($value == 'Ansh Optin Forms' ) {
			unset($library_data['types_data']['block']['categories'][$key]);
		}
	}
	
	$search_array = array();
	foreach( $library_data['templates'] as $key=>$value){
		$search_array[] =$key;
		
	}
	
	
	/* Unset Ansh Optin Forms Template Blocks */
	foreach( $ansh_optin_forms_blocks as $key=>$value) {		
		if ( in_array( $key, $search_array)) {			
			unset($library_data['templates'][$key]);
		}
	}
	/* Update Elementor remote library info */
	update_option( 'elementor_remote_info_library', $library_data );
}
register_deactivation_hook( __FILE__, 'ansh_optin_forms_plugin_deactivation' );

/**
 * Check Elementor plugin installed or not
 *
 * @since 1.0.0  
 */
function ansh_optin_forms_admin_notices(){
	
	$plugin = 'elementor/elementor.php';
	$installed_plugins = get_plugins();	
	
	/* Check Plugin Install but not activate */
	if ( isset($installed_plugins[$plugin]) && !is_plugin_active($plugin)) {
		
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return; 
		}
		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );
		
		$admin_message = '<p>' . esc_html__( 'Ansh Optin Forms plugin does not work because you need to first activate the Elementor plugin.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate Elementor Now', 'ansh-optin-forms' ) ) . '</p>';
		
	} else {
		
		if ( ! current_user_can( 'install_plugins' ) ) {
			return; 
		}
		
		$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );
		$admin_message = '<p>' . esc_html__( 'Ansh Optin Forms plugin does not work because you need to first install the Elementor plugin.', 'ansh-optin-forms' ) . '</p>';
		$admin_message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__( 'Install Elementor Now', 'ansh-optin-forms' ) ) . '</p>';
	}
	
	echo '<div class="error">' . $admin_message . '</div>';
}


/**
 * Set Plugin Settings Link on plugin action links.
 *
 * @since 1.0.0  
 */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'ansh_optin_forms_action_links' );
function ansh_optin_forms_action_links( $links ){
	$plugin_links = array(
			'<a href="' . admin_url( 'admin.php?page=ansh_optin_forms_integration' ) . '">' . esc_html__( 'Settings', 'ansh-optin-forms' ) . '</a>',
		);
	
	return array_merge( $plugin_links, $links );
}


/**
 * Ansh Elementor Elements Register Categories.
 *
 * @since 1.0.0  
 */
function ansh_optin_forms_categories_registered( $elements_manager  ){

   $elements_manager->add_category(
        'ansh-elementor-elements',
        [
            'title'  => 'Ansh Elements',
            'icon' => 'fa fa-plug'
        ]
    );
}

add_action( 'elementor/elements/categories_registered', 'ansh_optin_forms_categories_registered' );

/**
 * Require files.
 *
 * Ansh Optin Forms Register Elements ( Widgets).
 *
 * @since 1.0.0  
 */

function ansh_optin_forms_widgets_registered() {
	require_once ANSH_OPTIN_FORMS_PATH . 'includes/ansh-optin-forms-element.php';
}

add_action( 'elementor/widgets/widgets_registered', 'ansh_optin_forms_widgets_registered', 15 );

require_once ANSH_OPTIN_FORMS_PATH . 'includes/ansh-optin-forms-integration.php';
require_once ANSH_OPTIN_FORMS_PATH . 'includes/ansh-optin-forms-block.php';



/**  
 * call Elementor Remote Info API Data on set transient action add Ansh Optin Forms Pre-Define Bloks
 *
 * @since 1.2 
 */
add_action( 'init', 'ansh_optin_forms_admin_init', 20);
function ansh_optin_forms_admin_init() {
	global $pagenow, $wpdb;
	$cache_key = 'elementor_remote_info_api_data_' . ELEMENTOR_VERSION;	
	add_action( "set_transient_{$cache_key}", 'ansh_optin_forms_plugin_activate');
	
	
	
	/**  
	 * Create Ansh Optin Contact Lists Table to store email on loca databse
	 *
	 * @since 1.4
	 */
	if (is_admin() && ( $pagenow == 'plugins.php'  || ( isset($_GET['page']) && $_GET['page'] == 'ansh_optin_forms_integration' ) ) ) {
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		$charset_collate = $wpdb->get_charset_collate();
		
		$ansh_optin_contact_lists = $wpdb->prefix . 'ansh_optin_contact_lists';
		if($wpdb->get_var("show tables like '$ansh_optin_contact_lists'") != $ansh_optin_contact_lists) {

			$ansh_optin_contact_lists_sql = "CREATE TABLE $ansh_optin_contact_lists (
				ID mediumint(9) NOT NULL AUTO_INCREMENT,
				first_name text NULL,
				last_name text NULL,
				email text NOT NULL,
				created_date datetime NOT NULL default CURRENT_TIMESTAMP,
				UNIQUE KEY ID (ID)
			) $charset_collate;";
			dbDelta( $ansh_optin_contact_lists_sql );
		}	
	}
}

/**
 * Ansh Review box notice in Dashboard.
 *
 * @since 1.0.0  
 */
function ansh_optin_forms_review_notices() {
	$is_hidden = get_option( 'ansh_optin_forms_hide_review_box' );
	if( $is_hidden !== false ) {
		return;
	}
	$current_count = get_option( 'ansh_optin_forms_show_review_box_after' );
	if( $current_count === false ) {
		//$date = date( "Y-m-d" );
		$date = date("Y-m-d", strtotime("+3 days"));
		update_option( 'ansh_optin_forms_show_review_box_after', $date );
		return;
	}
	$optin_enabled_email_provider = get_option( '_ansh_optin_enabled_forms' );
	$count = 0;
	if ( !empty($optin_enabled_email_provider) ) {
		foreach( $optin_enabled_email_provider as $key => $value ) {
			if( $value == 1 ) {
				$count++;				
			}
		}
	}
	$published = $count;
	
	$date_to_show = get_option( 'ansh_optin_forms_show_review_box_after' );
	if( $date_to_show !== false ) {
		$current_date = date("Y-m-d");
		if( $current_date < $date_to_show ) {
			$is_hidden = get_option( 'ansh_optin_forms_subscriber_add' );
			if ( $published != 0 && $is_hidden === false ) {
				update_option( 'ansh_optin_forms_show_review_box_after', date("Y-m-d") );
				update_option( 'ansh_optin_forms_subscriber_add', true );
			} else {
				return;
			}
		}
	}
	if ( $published == 0) {
		return;
	}
	?>
	<div class="notice notice-info ansh-optin-forms-review-box">
		<h3><?php echo esc_html_e( "Optin Forms by Ansh", 'ansh-optin-forms' ) ?></h3>
		<p>
			<?php echo sprintf( esc_html__( "Hey, I've noticed you've enable %d Email Provider with Ansh optin forms - That's awesome! if you like our plugin & support then could you please do me a BIG favor in return and give your honest rate & review with a 5-star rating ★★★★★ on codeCanyon? Your detailed review in comments will add more value to our services! Thanks in Advance Anticipation!", 'ansh-optin-forms' ) , $published  );?>
			<a href="javascript:void(0);" class="dismiss-btn ansh-optin-forms-review-dismiss-btn"><span class="dashicons dashicons-no-alt"></span></a>
		</p>
		<div class="ansh-optin-forms-btn-wrap">
			<a class="button ansh-optin-forms-review-box-hide-btn" href="https://codecanyon.net/downloads" data-days="-1" target="_blank"><?php esc_html_e( '★ Ok, you deserve it', 'sonaar-music' );?></a>
			<a class="button ansh-optin-forms-review-box-hide-btn" data-days="-1" href="javascript:void(0);"><?php esc_html_e( 'I already did', 'ansh-optin-forms');?></a>
			<a class="button ansh-optin-forms-review-box-hide-btn" href="javascript:void(0);"><?php esc_html_e( 'Nope, not good enough', 'ansh-optin-forms');?></a>
		</div>
	</div>        
	<script>
	(function( $ ) {
		'use strict';
		$(document).ready(function(){
			$("body").addClass("ansh-optin-forms-has-box");				
			$(document).on("click", ".ansh-optin-forms-review-dismiss-btn, .ansh-optin-forms-review-box-hide-btn", function(){
				var dataDays = $(this).attr("data-days");
				if ( typeof dataDays === 'undefined') {
					dataDays = 10;
				}					
				$(".ansh-optin-forms-review-box").remove();
				$("body").removeClass("ansh-optin-forms-has-box");
				$.ajax({
					url: ajaxurl,
					data: "action=ansh_optin_forms_review_box&days="+dataDays,
					type: "post",
					success: function() {							
						$(".ansh-optin-forms-review-box").remove();
					}
				});
			});
		});
	})( jQuery );
	</script>
	<?php
}

add_action( 'admin_notices', 'ansh_optin_forms_review_notices' );

/**
 * Review box action.
 *
 * @since 1.0.0  
 */
function ansh_optin_forms_review_box() {
	$days = filter_input(INPUT_POST, 'days', FILTER_SANITIZE_STRING);

	if($days == -1) {
		update_option( 'ansh_optin_forms_hide_review_box', '1' );
	} else {
		$count_review_box = get_option('ansh_optin_forms_show_review_box_count');
		if ( $count_review_box == '' ) {
			$count_review_box = 0;
		}
		$count_review_box = $count_review_box+1;			
		
		update_option( 'ansh_optin_forms_show_review_box_count', ( $count_review_box ));
		/* User hide this box third time then need to hide box permantly. */
		if ( $count_review_box == 3 ) {
			update_option( 'ansh_optin_forms_hide_review_box', '1' );
		}
		/* User want to hind second time then hide box for 90 days */
		if ( $count_review_box == 2) {
			$days = 30;
		}
		$date = date("Y-m-d", strtotime("+".$days." days"));
		update_option( 'ansh_optin_forms_show_review_box_after', $date);
	}

	wp_die();
}

add_action( "wp_ajax_ansh_optin_forms_review_box", "ansh_optin_forms_review_box" );