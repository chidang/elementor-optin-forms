(function(wp) {
    const { registerBlockType } = wp.blocks; //Blocks API
    const { createElement, Fragment } = wp.element; //React.createElement
    const { __ } = wp.i18n; //translation functions
    const { InspectorControls, RichText, MediaUpload } = wp.editor; //Block inspector wrapper
    const { PanelBody, SelectControl, TextControl, TextareaControl, ColorPalette, ToggleControl, RangeControl, Button } = wp.components; //WordPress form inputs and server-side renderer

    const ansh_optin_form_id = AnshOptinFormsBlockConfig.optin_form_id;
    const ontin_form_nonce = AnshOptinFormsBlockConfig.ansh_ontin_form_nonce;

    registerBlockType('ansh/ansh-block', {

        title: 'Ansh Optin Forms',
        category: 'embed',

        edit(props) {
            const attributes    = props.attributes;
            const setAttributes = props.setAttributes;

            var ansh_ontin_form_nonce   = attributes.ansh_ontin_form_nonce;
            var optin_form_id           = attributes.optin_form_id;
            
            var optin_forms_layout_id   = attributes.optin_forms_layout_id;
            var form_title_tag_id       = attributes.form_title_tag_id;
            var form_subtitle_tag_id    = attributes.form_subtitle_tag_id;
            var text_alignment_id       = attributes.text_alignment_id;

            var optin_forms_layout  = attributes.optin_forms_layout;
            var form_title          = attributes.form_title;
            var form_title_tag      = attributes.form_title_tag;
            var form_subtitle       = attributes.form_subtitle;
            var form_subtitle_tag   = attributes.form_subtitle_tag;
            var form_description    = attributes.form_description;
            var text_alignment      = attributes.text_alignment;
            var form_bg_type        = attributes.form_bg_type;
            var form_bg_color       = attributes.form_bg_color;
            var form_bg_media_id    = attributes.form_bg_media_id;
            var form_bg_media_url   = attributes.form_bg_media_url;
            var form_padding        = attributes.form_padding;
            var form_border_type    = attributes.form_border_type;
            var form_border_color   = attributes.form_border_color;
            var form_border_radius  = attributes.form_border_radius;
            var form_border_width   = attributes.form_border_width;

            var newslatter_provider_id  = attributes.newslatter_provider_id;
            var newslatter_provider     = attributes.newslatter_provider;

            var is_provider_lists           = attributes.is_provider_lists;
            var provider_list_id_selected   = attributes.provider_list_id_selected;

            var email_text = attributes.email_text;

            var display_first_name  = attributes.display_first_name;
            var first_name_text     = attributes.first_name_text;

            var display_last_name   = attributes.display_last_name;
            var last_name_text      = attributes.last_name_text;

            var input_text_alignment     = attributes.input_text_alignment;
            var input_text_alignment_id  = attributes.input_text_alignment_id;
            var input_text_color         = attributes.input_text_color;
            var input_text_bg_color      = attributes.input_text_bg_color;
            var input_text_border_type   = attributes.input_text_border_type;
            var input_text_border_color  = attributes.input_text_border_color;
            var input_text_border_radius = attributes.input_text_border_radius;
            var input_text_border_width  = attributes.input_text_border_width;
            var input_text_height        = attributes.input_text_height;
            var input_text_width         = attributes.input_text_width;

            var button_text             = attributes.button_text;
            var show_button_icon        = attributes.show_button_icon;
            var button_icon             = attributes.button_icon;
            var button_icon_id          = attributes.button_icon_id;
            var button_icon_position    = attributes.button_icon_position;
            var button_icon_position_id = attributes.button_icon_position_id;
            var button_alignment        = attributes.button_alignment;
            var button_alignment_id     = attributes.button_alignment_id;
            var button_border_type      = attributes.button_border_type;
            var button_border_radius    = attributes.button_border_radius;
            var button_border_width     = attributes.button_border_width;
            var button_height           = attributes.button_height;
            var button_width            = attributes.button_width;

            var temp_input_text_height  = ( input_text_height > 0 ) ? input_text_height +'px' : 'auto';
            var temp_input_text_width   = ( input_text_width > 0 ) ? input_text_width +'%' : 'auto';
            var temp_button_height      = ( button_height > 0 ) ? button_height +'px' : 'auto';
            var temp_button_width       = ( button_width > 0 ) ? button_width +'%' : 'auto';

            var optin_form_custom_message               = attributes.optin_form_custom_message;
            var optin_form_link                         = attributes.optin_form_link;
            var optin_form_success_message              = attributes.optin_form_success_message;
            var optin_form_email_error_message          = attributes.optin_form_email_error_message;
            var optin_form_first_name_error_message     = attributes.optin_form_first_name_error_message;
            var optin_form_last_name_error_message      = attributes.optin_form_last_name_error_message;
            var optin_form_email_provider_message       = attributes.optin_form_email_provider_message;
            var optin_form_email_provider_list_message  = attributes.optin_form_email_provider_list_message;

            var colors                  = attributes.colors;
            var border_type             = attributes.border_type;
            var bg_type                 = attributes.bg_type;
            var form_title_color        = attributes.form_title_color;
            var form_subtitle_color     = attributes.form_subtitle_color;
            var form_description_color  = attributes.form_description_color;
            var form_button_color       = attributes.form_button_color;
            var form_button_bg_color    = attributes.form_button_bg_color;
            var button_border_color     = attributes.button_border_color;

            var form_background = 'none';

            if(form_bg_type == 'color') {
                form_background = form_bg_color;
            }
            if(form_bg_type == 'image') {
                form_background = 'url("'+ form_bg_media_url +'")'
            }

            var formlistarr = {};

            if(newslatter_provider_id in AnshOptinFormsBlockConfig.provider_lists){
                formlistarr = AnshOptinFormsBlockConfig.provider_lists[newslatter_provider_id];
                setAttributes({ is_provider_lists: true });
            } else {
                setAttributes({ is_provider_lists: false });
            }

            setAttributes({ optin_form_id: ansh_optin_form_id});
            setAttributes({ ansh_ontin_form_nonce: ontin_form_nonce});

            //Display block preview and UI
            return [
                createElement( InspectorControls, {
                    key: 'inspector'
                    }, 
                    createElement(PanelBody, {
                            title: __('Content','ansh-optin-forms'),
                            initialOpen: false
                        },
                        createElement(SelectControl, {
                            label: __( 'Form Layout', 'ansh-optin-forms' ),
                            options: optin_forms_layout,
                            value: optin_forms_layout_id,
                            onChange: value => {
                                setAttributes( { optin_forms_layout_id: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( TextControl, {
                            label: __( 'Form Title', 'ansh-optin-forms' ),
                            value: form_title,
                            onChange: value => {
                                setAttributes( { form_title: value } );
                            }
                        }),
                        createElement(SelectControl, {
                            label: __( 'Title HTML Tag', 'ansh-optin-forms' ),
                            options: form_title_tag,
                            value: form_title_tag_id,
                            onChange: value => {
                                setAttributes( { form_title_tag_id: value } );
                            }
                        }),
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Title Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Select Title Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_title_color,
                            onChange: value => {
                                setAttributes( { form_title_color: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( TextControl, {
                            label: __( 'Form Subtitle', 'ansh-optin-forms' ),
                            value: form_subtitle,
                            onChange: value => {
                                setAttributes( { form_subtitle: value } );
                            }
                        }),
                        createElement(SelectControl, {
                            label: __( 'Subtitle HTML Tag', 'ansh-optin-forms' ),
                            options: form_subtitle_tag,
                            value: form_subtitle_tag_id,
                            onChange: value => {
                                setAttributes( { form_subtitle_tag_id: value } );
                            }
                        }),
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Subtitle Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Select Subtitle Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_subtitle_color,
                            onChange: value => {
                                setAttributes( { form_subtitle_color: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement(TextareaControl, {
                            label: __( 'Description', 'ansh-optin-forms' ),
                            help: __( 'Type your newslatter description here.', 'ansh-optin-forms' ),
                            value: form_description,
                            onChange: value => {
                                setAttributes({ form_description: value })
                            }
                        }),
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Description Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Select Description Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_description_color,
                            onChange: value => {
                                setAttributes( { form_description_color: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement(SelectControl, {
                            label: __( 'Alignment', 'ansh-optin-forms' ),
                            options: text_alignment,
                            value: text_alignment_id,
                            onChange: value => {
                                setAttributes( { text_alignment_id: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RangeControl, {
                            label: __( 'Padding (px)', 'ansh-optin-forms' ),
                            value: form_padding,
                            min: 0,
                            max: 100,
                            onChange: value => {
                                setAttributes( { form_padding: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement(SelectControl, {
                            label: __( 'Background Type', 'ansh-optin-forms' ),
                            options: bg_type,
                            value: form_bg_type,
                            onChange: value => {
                                setAttributes( { form_bg_type: value } );
                            }
                        }),
                        form_bg_type == 'color' && createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Background Color', 'ansh-optin-forms' ),
                        }),
                        form_bg_type == 'color' && createElement( ColorPalette, {
                            label: __( 'Select Background Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_bg_color,
                            onChange: value => {
                                setAttributes( { form_bg_color: value } );
                            }
                        }),
                        form_bg_type == 'image' && createElement(
                            MediaUpload, {
                                key: 'mediaupload',
                                onSelect: function(media) {
                                    return setAttributes({
                                        form_bg_media_url: media.url,
                                        form_bg_media_id: media.id
                                    });
                                },
                                type: "image",
                                value: form_bg_media_id,
                                render: function(e) {
                                    var r = e.open;
                                    return createElement(Fragment, null, createElement(Button, {
                                        className: 'button-link ansh-button-link',
                                        onClick: r
                                    }, form_bg_media_id ? createElement('img', {
                                        src: form_bg_media_url
                                    }) : 'Set background image'))
                                }
                            }
                        ),
                        form_bg_type == 'image' && form_bg_media_id && createElement(
                            Fragment,
                            null,
                            createElement('p', {
                                className: 'editor-post-featured-image__howto',
                                },
                                'Click the image to edit or update'
                            ),
                            createElement(Button, {
                                    className: 'button-link',
                                    onClick: function() {
                                        return setAttributes({
                                            form_bg_media_url: void 0,
                                            form_bg_media_id: void 0
                                        });
                                    }
                                },
                                'Remove background image'
                            )
                        ),
                        createElement( 'hr', {}) ,
                        createElement(SelectControl, {
                            label: __( 'Border Type', 'ansh-optin-forms' ),
                            options: border_type,
                            value: form_border_type,
                            onChange: value => {
                                setAttributes( { form_border_type: value } );
                            }
                        }),
                        form_border_type && createElement( RangeControl, {
                            label: __( 'Border Width (px)', 'ansh-optin-forms' ),
                            value: form_border_width,
                            min: 0,
                            max: 50,
                            onChange: value => {
                                setAttributes( { form_border_width: value } );
                            }
                        }),
                        form_border_type && createElement( RangeControl, {
                            label: __( 'Border Radius (px)', 'ansh-optin-forms' ),
                            value: form_border_radius,
                            min: 0,
                            max: 100,
                            onChange: value => {
                                setAttributes( { form_border_radius: value } );
                            }
                        }),
                        form_border_type && createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Border Color', 'ansh-optin-forms' ),
                        }),
                        form_border_type && createElement( ColorPalette, {
                            label: __( 'Select Border Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_border_color,
                            onChange: value => {
                                setAttributes( { form_border_color: value } );
                            }
                        }),
                    ),
                     
                    createElement(PanelBody, {
                            title: __('Form Integration','ansh-optin-forms'),
                            initialOpen: false
                        },
                        createElement(SelectControl, {
                            label: __( 'Select Email Provider', 'ansh-optin-forms' ),
                            options: newslatter_provider,
                            value: newslatter_provider_id,
                            onChange: value => {
                                setAttributes( { newslatter_provider_id: value } );
                            }
                        }),
                        is_provider_lists && createElement( 'hr', {}) ,
                        is_provider_lists && createElement(SelectControl, {
                            label: __( 'Select Email List', 'ansh-optin-forms' ),
                            options: formlistarr,
                            value: provider_list_id_selected,
                            onChange: value => {
                                setAttributes( { provider_list_id_selected: value } );
                            }
                        }),                        
                        createElement( 'hr', {}) ,
                        createElement( TextControl, {
                            label: __( 'Email Text', 'ansh-optin-forms' ),
                            value: email_text,
                            onChange: value => {
                                setAttributes( { email_text: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( ToggleControl, {
                            label: __( 'Display First Name', 'ansh-optin-forms' ),
                            checked: display_first_name,
                            onChange: display_fname => {
                                setAttributes( { display_first_name: display_fname } );
                            }
                        }),
                        display_first_name && createElement( TextControl, {
                            label: __( 'First Name Text', 'ansh-optin-forms' ),
                            value: first_name_text,
                            onChange: value => {
                                setAttributes( { first_name_text: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( ToggleControl, {
                            label: __( 'Display Last Name', 'ansh-optin-forms' ),
                            checked: display_last_name,
                            onChange: display_lname => {
                                setAttributes( { display_last_name: display_lname } );
                            }
                        }),
                        display_last_name && createElement( TextControl, {
                            label: __( 'Last Name Text', 'ansh-optin-forms' ),
                            value: last_name_text,
                            onChange: value => {
                                setAttributes( { last_name_text: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RangeControl, {
                            label: __( 'Width (%)', 'ansh-optin-forms' ),
                            value: input_text_width,
                            min: 0,
                            max: 100,
                            onChange: value => {
                                setAttributes( { input_text_width: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RangeControl, {
                            label: __( 'Height (px)', 'ansh-optin-forms' ),
                            value: input_text_height,
                            min: 0,
                            max: 500,
                            onChange: value => {
                                setAttributes( { input_text_height: value } );
                            }
                        }),
                        optin_forms_layout_id == 'ansh-optin-form-default' && createElement( 'hr', {}) ,
                        optin_forms_layout_id == 'ansh-optin-form-default' && createElement(SelectControl, {
                            label: __( 'Alignment', 'ansh-optin-forms' ),
                            options: input_text_alignment,
                            value: input_text_alignment_id,
                            onChange: value => {
                                setAttributes( { input_text_alignment_id: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Text Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Text Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: input_text_color,
                            onChange: value => {
                                setAttributes( { input_text_color: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Background Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Select Background Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: input_text_bg_color,
                            onChange: value => {
                                setAttributes( { input_text_bg_color: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement(SelectControl, {
                            label: __( 'Border Type', 'ansh-optin-forms' ),
                            options: border_type,
                            value: input_text_border_type,
                            onChange: value => {
                                setAttributes( { input_text_border_type: value } );
                            }
                        }),
                        input_text_border_type && createElement( RangeControl, {
                            label: __( 'Border Width (px)', 'ansh-optin-forms' ),
                            value: input_text_border_width,
                            min: 0,
                            max: 50,
                            onChange: value => {
                                setAttributes( { input_text_border_width: value } );
                            }
                        }),
                        input_text_border_type && createElement( RangeControl, {
                            label: __( 'Border Radius (px)', 'ansh-optin-forms' ),
                            value: input_text_border_radius,
                            min: 0,
                            max: 100,
                            onChange: value => {
                                setAttributes( { input_text_border_radius: value } );
                            }
                        }),
                        input_text_border_type && createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Border Color', 'ansh-optin-forms' ),
                        }),
                        input_text_border_type && createElement( ColorPalette, {
                            label: __( 'Select Border Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: input_text_border_color,
                            onChange: value => {
                                setAttributes( { input_text_border_color: value } );
                            }
                        }),
                    ),
                    createElement(PanelBody, {
                            title: __('Button','ansh-optin-forms'),
                            initialOpen: false
                        },
                        createElement( TextControl, {
                            label: __( 'Button Text', 'ansh-optin-forms' ),
                            value: button_text,
                            onChange: value => {
                                setAttributes( { button_text: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RangeControl, {
                            label: __( 'Width (%)', 'ansh-optin-forms' ),
                            value: button_width,
                            min: 0,
                            max: 100,
                            onChange: value => {
                                setAttributes( { button_width: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RangeControl, {
                            label: __( 'Height (px)', 'ansh-optin-forms' ),
                            value: button_height,
                            min: 0,
                            max: 500,
                            onChange: value => {
                                setAttributes( { button_height: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( ToggleControl, {
                            label: __( 'Show Icon', 'ansh-optin-forms' ),
                            checked: show_button_icon,
                            onChange: display_btn_icon => {
                                setAttributes( { show_button_icon: display_btn_icon } );
                            }
                        }),
                        show_button_icon && createElement(SelectControl, {
                            label: __( 'Icon', 'ansh-optin-forms' ),
                            options: button_icon,
                            value: button_icon_id,
                            onChange: value => {
                                setAttributes( { button_icon_id: value } );
                            }
                        }),
                        show_button_icon && createElement(SelectControl, {
                            label: __( 'Icon Position', 'ansh-optin-forms' ),
                            options: button_icon_position,
                            value: button_icon_position_id,
                            onChange: value => {
                                setAttributes( { button_icon_position_id: value } );
                            }
                        }),
                        optin_forms_layout_id == 'ansh-optin-form-default' && createElement( 'hr', {}) ,
                        optin_forms_layout_id == 'ansh-optin-form-default' && createElement(SelectControl, {
                            label: __( 'Alignment', 'ansh-optin-forms' ),
                            options: button_alignment,
                            value: button_alignment_id,
                            onChange: value => {
                                setAttributes( { button_alignment_id: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Button Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Select Button Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_button_color,
                            onChange: value => {
                                setAttributes( { form_button_color: value } );
                            }
                        }),
                        createElement( 'hr', {}) ,
                        createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Button Background Color', 'ansh-optin-forms' ),
                        }),
                        createElement( ColorPalette, {
                            label: __( 'Select Button Background Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: form_button_bg_color,
                            onChange: value => {
                                setAttributes( { form_button_bg_color: value } );
                            }
                        }),
                        createElement( 'hr', {}),
                        createElement(SelectControl, {
                            label: __( 'Border Type', 'ansh-optin-forms' ),
                            options: border_type,
                            value: button_border_type,
                            onChange: value => {
                                setAttributes( { button_border_type: value } );
                            }
                        }),
                        button_border_type && createElement( RangeControl, {
                            label: __( 'Border Width (px)', 'ansh-optin-forms' ),
                            value: button_border_width,
                            min: 0,
                            max: 50,
                            onChange: value => {
                                setAttributes( { button_border_width: value } );
                            }
                        }),
                        button_border_type && createElement( RangeControl, {
                            label: __( 'Border Radius (px)', 'ansh-optin-forms' ),
                            value: button_border_radius,
                            min: 0,
                            max: 100,
                            onChange: value => {
                                setAttributes( { button_border_radius: value } );
                            }
                        }),
                        button_border_type && createElement( RichText.Content, {
                            tagName: 'label',
                            className: 'components-base-control__label',
                            value: __( 'Button Border Color', 'ansh-optin-forms' ),
                        }),
                        button_border_type && createElement( ColorPalette, {
                            label: __( 'Select Button Border Color', 'ansh-optin-forms' ),
                            colors: colors,
                            value: button_border_color,
                            onChange: value => {
                                setAttributes( { button_border_color: value } );
                            }
                        }),
                        
                    ),
                    createElement(PanelBody, {
                            title: __('Additional Settings','ansh-optin-forms'),
                            initialOpen: false
                        },
                        createElement( ToggleControl, {
                            label: __( 'Custom Success Messages', 'ansh-optin-forms' ),
                            checked: optin_form_custom_message,
                            onChange: custom_msg => {
                                setAttributes( { optin_form_custom_message: custom_msg } );
                            }
                        }),
                        ! optin_form_custom_message && createElement( TextControl, {
                            label: __( 'Redirect Link', 'ansh-optin-forms' ),
                            value: optin_form_link,
                            placeholder: 'https://your-link.com',
                            onChange: value => {
                                setAttributes( { optin_form_link: value } );
                            }
                        }),
                        optin_form_custom_message && createElement( TextControl, {
                            label: __( 'Success Message', 'ansh-optin-forms' ),
                            value: optin_form_success_message,
                            onChange: value => {
                                setAttributes( { optin_form_success_message: value } );
                            }
                        }),

                        createElement( TextControl, {
                            label: __( 'Email error message', 'ansh-optin-forms' ),
                            value: optin_form_email_error_message,
                            onChange: value => {
                                setAttributes( { optin_form_email_error_message: value } );
                            }
                        }),
                        display_first_name && createElement( TextControl, {
                            label: __( 'First name error message', 'ansh-optin-forms' ),
                            value: optin_form_first_name_error_message,
                            onChange: value => {
                                setAttributes( { optin_form_first_name_error_message: value } );
                            }
                        }),
                        display_last_name && createElement( TextControl, {
                            label: __( 'Last name error message', 'ansh-optin-forms' ),
                            value: optin_form_last_name_error_message,
                            onChange: value => {
                                setAttributes( { optin_form_last_name_error_message: value } );
                            }
                        }),
                        createElement( TextControl, {
                            label: __( 'Email provider error message', 'ansh-optin-forms' ),
                            value: optin_form_email_provider_message,
                            onChange: value => {
                                setAttributes( { optin_form_email_provider_message: value } );
                            }
                        }),
                        createElement( TextControl, {
                            label: __( 'Email list# error message', 'ansh-optin-forms' ),
                            value: optin_form_email_provider_list_message,
                            onChange: value => {
                                setAttributes( { optin_form_email_provider_list_message: value } );
                            }
                        }),
                    )
                ),
                createElement( 'div', {
                        className: 'ansh-optin-form-wrapper gb-ansh-optin-form-wrapper',
                        style: {background: form_background, padding: form_padding +'px', borderStyle: form_border_type, borderColor: form_border_color, borderRadius: form_border_radius +'px', borderWidth: form_border_width + 'px'},
                    },
                    form_title && createElement( RichText.Content, {
                        tagName: form_title_tag_id,
                        className: 'ansh-optin-form-title ansh-optin-' + text_alignment_id,
                        value: form_title,
                        style: {color: form_title_color}
                    }),
                    form_subtitle && createElement( RichText.Content, {
                        tagName: form_subtitle_tag_id,
                        className: 'ansh-optin-form-sub-title ansh-optin-' + text_alignment_id,
                        value: form_subtitle,
                        style: {color: form_subtitle_color}
                    }),
                    form_description && createElement( RichText.Content, {
                        tagName: 'p',
                        className: 'ansh-optin-form-description ansh-optin-' + text_alignment_id,
                        value: form_description,
                        style: {color: form_description_color}
                    }),
                    createElement( 'div', {
                            className: 'ansh-optin-forms',
                        },
                        createElement('form', {
                                className: 'ansh-optin-form',
                                method: 'post',
                                id: optin_form_id
                            },
                            createElement( 'div', {
                                    className: 'hidden'
                                },
                                createElement( 'input', {
                                    type: 'hidden',
                                    className: 'ansh-email-provider',
                                    name: 'ansh_email_provider',
                                    value: newslatter_provider_id
                                }),
                                createElement( 'input', {
                                    type: 'hidden',
                                    className: 'ansh-email-provider-list-id',
                                    name: 'ansh_email_provider_list_id',
                                    value: provider_list_id_selected
                                }),
                                createElement( 'input', {
                                    type: 'hidden',
                                    className: 'ansh-email-error-messages',
                                    name: 'ansh_email_error_message',
                                    value: '{"optin_form_email_error_message": "'+ optin_form_email_error_message +'", "optin_form_email_provider_message": "'+ optin_form_email_provider_message +'", "optin_form_email_provider_list_message": "'+ optin_form_email_provider_list_message +'", "optin_form_first_name_error_message" : "'+ optin_form_first_name_error_message +'", "optin_form_last_name_error_message": "'+ optin_form_last_name_error_message +'", '+ ( optin_form_custom_message ? ' "optin_form_success_message": "'+ optin_form_success_message +'" ' : ' "optin_form_link": "'+ optin_form_link +'"') +' }'
                                })
                            ),
                            createElement('div', {
                                    className: 'ansh_optin_form_input_wrap ' + optin_forms_layout_id,
                                },
                                display_first_name && createElement('div', {
                                        className: 'input-area input-first-name ansh-optin-' + input_text_alignment_id,
                                    },
                                    createElement( 'input', {
                                        type: 'text',
                                        className: 'placeholder ansh-optin-fom-input-text ansh-optin-form-first-name',
                                        name: 'ansh_optin_form_first_name',
                                        placeholder: first_name_text,
                                        required: 'required',
                                        style: {color: input_text_color, background: input_text_bg_color, height: temp_input_text_height, width: temp_input_text_width, borderStyle: input_text_border_type, borderColor: input_text_border_color, borderRadius: input_text_border_radius +'px', borderWidth: input_text_border_width + 'px'},
                                    })
                                ),
                                display_last_name && createElement('div', {
                                        className: 'input-area input-last-name ansh-optin-' + input_text_alignment_id,
                                    },
                                    createElement( 'input', {
                                        type: 'text',
                                        className: 'placeholder ansh-optin-fom-input-text ansh-optin-form-last-name',
                                        name: 'ansh_optin_form_last_name',
                                        placeholder: last_name_text,
                                        required: 'required',
                                        style: {color: input_text_color, background: input_text_bg_color, height: temp_input_text_height, width: temp_input_text_width, borderStyle: input_text_border_type, borderColor: input_text_border_color, borderRadius: input_text_border_radius +'px', borderWidth: input_text_border_width + 'px'},
                                    })
                                ),
                                createElement('div', {
                                        className: 'input-area input-email ansh-optin-' + input_text_alignment_id,
                                    },
                                    createElement( 'input', {
                                        type: 'text',
                                        className: 'placeholder ansh-optin-fom-input-text ansh-optin-form-email',
                                        name: 'ansh_optin_form_email',
                                        placeholder: email_text,
                                        required: 'required',
                                        style: {color: input_text_color, background: input_text_bg_color, height: temp_input_text_height, width: temp_input_text_width, borderStyle: input_text_border_type, borderColor: input_text_border_color, borderRadius: input_text_border_radius +'px', borderWidth: input_text_border_width + 'px'},
                                    })
                                ),
                                createElement('div', {
                                        className: 'button-area ansh-optin-' + button_alignment_id,
                                    },
                                    createElement( 'button', {
                                            type: 'submit',
                                            className: 'btn btn-icon elementor-button submit ansh-optin-form-submit',
                                            style: {color: form_button_color, background: form_button_bg_color, height: temp_button_height, width: temp_button_width, borderStyle: button_border_type, borderColor: button_border_color, borderRadius: button_border_radius +'px', borderWidth: button_border_width + 'px'},
                                            'data-form-id': optin_form_id,
                                            'data-nonce-id': optin_form_id
                                        },
                                        createElement( RichText.Content, {
                                            tagName: '',
                                            value: button_text
                                        }),
                                        show_button_icon && createElement( 'span', {
                                                className: 'elementor-button-icon elementor-align-icon-' + button_icon_position_id
                                            },
                                            createElement( 'i', {
                                                className: 'fa '+ button_icon_id,
                                            })
                                        ),
                                        createElement('span', {
                                            className: 'ansh-spinning-icon ansh-spining-'+ optin_form_id
                                        })
                                    )
                                ),
                                createElement('p', {
                                    className: 'ansh-optin-form-msg'
                                }),
                                createElement('input', {
                                    type: 'hidden',
                                    id: 'ansh_ontin_form',
                                    name: 'ansh_ontin_form',
                                    value: ansh_ontin_form_nonce
                                }),
                            )
                        ),

                    ),
                ),
            ]
        },

        save( props ) {
            
            
            const attributes    =  props.attributes;

            var ansh_ontin_form_nonce           = attributes.ansh_ontin_form_nonce;
            var optin_form_id                   = attributes.optin_form_id;
            
            var optin_forms_layout_id   = attributes.optin_forms_layout_id;
            var form_title_tag_id       = attributes.form_title_tag_id;
            var form_subtitle_tag_id    = attributes.form_subtitle_tag_id;
            var text_alignment_id       = attributes.text_alignment_id;
            var form_bg_type            = attributes.form_bg_type;
            var form_bg_color           = attributes.form_bg_color;
            var form_bg_media_id        = attributes.form_bg_media_id;
            var form_bg_media_url       = attributes.form_bg_media_url;
            var form_padding            = attributes.form_padding;
            var form_border_type        = attributes.form_border_type;
            var form_border_color       = attributes.form_border_color;
            var form_border_radius      = attributes.form_border_radius;
            var form_border_width       = attributes.form_border_width;


            var form_title          = attributes.form_title;
            var form_subtitle       = attributes.form_subtitle;
            var form_description    = attributes.form_description;

            var newslatter_provider_id  = attributes.newslatter_provider_id;

            var provider_list_id_selected   = attributes.provider_list_id_selected;

            var email_text = attributes.email_text;

            var display_first_name  = attributes.display_first_name;
            var first_name_text     = attributes.first_name_text;

            var display_last_name   = attributes.display_last_name;
            var last_name_text      = attributes.last_name_text;

            var input_text_alignment_id = attributes.input_text_alignment_id;
            var input_text_color         = attributes.input_text_color;
            var input_text_bg_color      = attributes.input_text_bg_color;
            var input_text_border_type   = attributes.input_text_border_type;
            var input_text_border_color  = attributes.input_text_border_color;
            var input_text_border_radius = attributes.input_text_border_radius;
            var input_text_border_width  = attributes.input_text_border_width;
            var input_text_height        = attributes.input_text_height;
            var input_text_width         = attributes.input_text_width;

            var button_text             = attributes.button_text;
            var show_button_icon        = attributes.show_button_icon;
            var button_icon_id          = attributes.button_icon_id;
            var button_icon_position_id = attributes.button_icon_position_id;
            var button_alignment_id     = attributes.button_alignment_id;
            var button_border_type      = attributes.button_border_type;
            var button_border_radius    = attributes.button_border_radius;
            var button_border_width     = attributes.button_border_width;
            var button_height           = attributes.button_height;
            var button_width            = attributes.button_width;
            var button_border_color     = attributes.button_border_color;

            var optin_form_custom_message               = attributes.optin_form_custom_message;
            var optin_form_link                         = attributes.optin_form_link;
            var optin_form_success_message              = attributes.optin_form_success_message;
            var optin_form_email_error_message          = attributes.optin_form_email_error_message;
            var optin_form_first_name_error_message     = attributes.optin_form_first_name_error_message;
            var optin_form_last_name_error_message      = attributes.optin_form_last_name_error_message;
            var optin_form_email_provider_message       = attributes.optin_form_email_provider_message;
            var optin_form_email_provider_list_message  = attributes.optin_form_email_provider_list_message;

            var form_title_color        = attributes.form_title_color;
            var form_subtitle_color     = attributes.form_subtitle_color;
            var form_description_color  = attributes.form_description_color;
            var form_button_color       = attributes.form_button_color;
            var form_button_bg_color    = attributes.form_button_bg_color;
            var button_border_color     = attributes.button_border_color;

            var temp_input_text_height  = ( input_text_height > 0 ) ? input_text_height +'px' : 'auto';
            var temp_input_text_width   = ( input_text_width > 0 ) ? input_text_width +'%' : 'auto';
            var temp_button_height      = ( button_height > 0 ) ? button_height +'px' : 'auto';
            var temp_button_width       = ( button_width > 0 ) ? button_width +'%' : 'auto';

            var form_background = 'none';

            if(form_bg_type == 'color') {
                form_background = form_bg_color;
            }
            if(form_bg_type == 'image') {
                form_background = 'url("'+ form_bg_media_url +'")'
            }

            return createElement( 'div', {
                    className: 'ansh-optin-form-wrapper gb-ansh-optin-form-wrapper',
                    style: {background: form_background, padding: form_padding +'px', borderStyle: form_border_type, borderColor: form_border_color, borderRadius: form_border_radius +'px', borderWidth: form_border_width + 'px'},
                },
                form_title && createElement( RichText.Content, {
                    tagName: form_title_tag_id,
                    className: 'ansh-optin-form-title ansh-optin-' + text_alignment_id,
                    value: form_title,
                    style: {color: form_title_color}
                }),
                form_subtitle && createElement( RichText.Content, {
                    tagName: form_subtitle_tag_id,
                    className: 'ansh-optin-form-sub-title ansh-optin-' + text_alignment_id,
                    value: form_subtitle,
                    style: {color: form_subtitle_color}
                }),
                form_description && createElement( RichText.Content, {
                    tagName: 'p',
                    className: 'ansh-optin-form-description ansh-optin-' + text_alignment_id,
                    value: form_description,
                    style: {color: form_description_color}
                }),
                createElement( 'div', {
                        className: 'ansh-optin-forms',
                    },
                    createElement('form', {
                            className: 'ansh-optin-form',
                            method: 'post',
                            id: optin_form_id
                        },
                        createElement( 'div', {
                                className: 'hidden'
                            },
                            createElement( 'input', {
                                type: 'hidden',
                                className: 'ansh-email-provider',
                                name: 'ansh_email_provider',
                                value: newslatter_provider_id
                            }),
                            createElement( 'input', {
                                type: 'hidden',
                                className: 'ansh-email-provider-list-id',
                                name: 'ansh_email_provider_list_id',
                                value: provider_list_id_selected
                            }),
                            createElement( 'input', {
                                type: 'hidden',
                                className: 'ansh-email-error-messages',
                                name: 'ansh_email_error_message',
                                value: '{"optin_form_email_error_message": "'+ optin_form_email_error_message +'", "optin_form_email_provider_message": "'+ optin_form_email_provider_message +'", "optin_form_email_provider_list_message": "'+ optin_form_email_provider_list_message +'", "optin_form_first_name_error_message" : "'+ optin_form_first_name_error_message +'", "optin_form_last_name_error_message": "'+ optin_form_last_name_error_message +'", '+ ( optin_form_custom_message ? ' "optin_form_success_message": "'+ optin_form_success_message +'" ' : ' "optin_form_link": "'+ optin_form_link +'"') +' }'
                            })
                        ),
                        createElement('div', {
                                className: 'ansh_optin_form_input_wrap ' + optin_forms_layout_id,
                            },
                            display_first_name && createElement('div', {
                                    className: 'input-area input-first-name ansh-optin-' + input_text_alignment_id,
                                },
                                createElement( 'input', {
                                    type: 'text',
                                    className: 'placeholder ansh-optin-fom-input-text ansh-optin-form-first-name',
                                    name: 'ansh_optin_form_first_name',
                                    placeholder: first_name_text,
                                    required: 'required',
                                    style: {color: input_text_color, background: input_text_bg_color, height: temp_input_text_height, width: temp_input_text_width, borderStyle: input_text_border_type, borderColor: input_text_border_color, borderRadius: input_text_border_radius +'px', borderWidth: input_text_border_width + 'px'},
                                })
                            ),
                            display_last_name && createElement('div', {
                                    className: 'input-area input-last-name ansh-optin-' + input_text_alignment_id,
                                },
                                createElement( 'input', {
                                    type: 'text',
                                    className: 'placeholder ansh-optin-fom-input-text ansh-optin-form-last-name',
                                    name: 'ansh_optin_form_last_name',
                                    placeholder: last_name_text,
                                    required: 'required',
                                    style: {color: input_text_color, background: input_text_bg_color, height: temp_input_text_height, width: temp_input_text_width, borderStyle: input_text_border_type, borderColor: input_text_border_color, borderRadius: input_text_border_radius +'px', borderWidth: input_text_border_width + 'px'},
                                })
                            ),
                            createElement('div', {
                                    className: 'input-area input-email ansh-optin-' + input_text_alignment_id,
                                },
                                createElement( 'input', {
                                    type: 'text',
                                    className: 'placeholder ansh-optin-fom-input-text ansh-optin-form-email',
                                    name: 'ansh_optin_form_email',
                                    placeholder: email_text,
                                    required: 'required',
                                    style: {color: input_text_color, background: input_text_bg_color, height: temp_input_text_height, width: temp_input_text_width, borderStyle: input_text_border_type, borderColor: input_text_border_color, borderRadius: input_text_border_radius +'px', borderWidth: input_text_border_width + 'px'},
                                })
                            ),
                            createElement('div', {
                                    className: 'button-area ansh-optin-' + button_alignment_id,
                                },
                                createElement( 'button', {
                                        type: 'submit',
                                        className: 'btn btn-icon elementor-button submit ansh-optin-form-submit',
                                        style: {color: form_button_color, background: form_button_bg_color, height: temp_button_height, width: temp_button_width, borderStyle: button_border_type, borderColor: button_border_color, borderRadius: button_border_radius +'px', borderWidth: button_border_width + 'px'},
                                        'data-form-id': optin_form_id,
                                        'data-nonce-id': optin_form_id
                                    },
                                    createElement( RichText.Content, {
                                        tagName: '',
                                        value: button_text
                                    }),
                                    show_button_icon && createElement( 'span', {
                                            className: 'elementor-button-icon elementor-align-icon-' + button_icon_position_id
                                        },
                                        createElement( 'i', {
                                            className: 'fa '+ button_icon_id,
                                        })
                                    ),
                                    createElement('span', {
                                        className: 'ansh-spinning-icon ansh-spining-'+ optin_form_id
                                    })
                                )
                            ),
                            createElement('p', {
                                className: 'ansh-optin-form-msg'
                            }),
                            createElement('input', {
                                type: 'hidden',
                                id: 'ansh_ontin_form',
                                name: 'ansh_ontin_form',
                                value: ansh_ontin_form_nonce
                            }),
                        )
                    ),

                ),
            ); //save has to exist. This all we need
        },
    });
})(
    window.wp
);